Mobile instructions:
1. Create a GitHub repo and upload this project zip (or push files via mobile).
2. In Actions tab, run 'Unity Android Build' workflow (Run workflow).
3. After success, download the artifact 'CardRogue-APK' to your phone.


Note: The build now auto-runs the InitialData importer during AutoBuilder.GenerateSceneAndData and before building, so ScriptableObjects are created automatically in CI.
