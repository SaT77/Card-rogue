# ASSET LICENSES & SOURCES (initial selection)

1. Kenney - Pixel Platformer — CC0. Source: https://kenney.nl/assets/pixel-platformer. citeturn1view0
2. OpenGameArt - Cave Tileset (Beast) — CC0. Source: https://opengameart.org/content/m13-cave-tileset. citeturn4view0
3. Mixkit - Free music & SFX — Mixkit License. Source: https://mixkit.co/free-stock-music/tag/video-game/. citeturn0search14
4. Pixabay - Free SFX — royalty-free. Source: https://pixabay.com/sound-effects/search/game/. citeturn0search3
