#!/usr/bin/env bash
set -e
mkdir -p ci_assets/downloads
cd ci_assets/downloads
echo "Downloading Kenney Pixel Platformer..."
curl -L -o kenney_pixel-platformer.zip "https://kenney.nl/media/pages/assets/pixel-platformer/bef991136c-1696667883/kenney_pixel-platformer.zip" || echo "Kenney download failed"
echo "Downloading OpenGameArt Cave Tileset..."
curl -L -o CaveTileset.zip "https://opengameart.org/sites/default/files/CaveTileset.zip" || echo "OpenGameArt download failed"
mkdir -p ../../Assets/ImportedAssets
for f in *.zip; do
  [ -f "$f" ] || continue
  unzip -o "$f" -d ../../Assets/ImportedAssets || echo "Failed to unzip $f"
done
echo "Done."
