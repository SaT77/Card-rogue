using UnityEditor;
using UnityEngine;
using System.IO;
using System.Net;

public class AssetDownloader
{
    static string[] pages = new string[] {
        "https://kenney.nl/assets/pixel-platformer",
        "https://opengameart.org/content/m13-cave-tileset",
        "https://mixkit.co/free-stock-music/tag/video-game/",
    };

    [MenuItem("Tools/Assets/Print Recommended Sources")]
    public static void PrintSources()
    {
        foreach (var p in pages) Debug.Log(p);
    }

    public static bool TryDownload(string url, string destPath)
    {
        try
        {
            using (var wc = new WebClient())
            {
                wc.DownloadFile(url, destPath);
            }
            AssetDatabase.Refresh();
            Debug.Log("Downloaded: " + url);
            return true;
        }
        catch (System.Exception e)
        {
            Debug.LogWarning("Failed to download " + url + " Exception: " + e.Message);
            return false;
        }
    }
}
