#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Linq;

public class InitialDataImporter
{
    [MenuItem("Tools/InitialData/Import JSON Data")]
    public static void ImportJsonData()
    {
        string path = "Assets/Resources/Data/InitialGameData.json";
        if (!File.Exists(path))
        {
            Debug.LogError("InitialGameData.json not found at Assets/Resources/Data/");
            return;
        }

        var jsonText = File.ReadAllText(path);
        var root = JsonUtility.FromJson<Wrapper>(jsonText);

        // Ensure directories
        string weaponsPath = "Assets/Resources/Data/Weapons";
        string cardsPath = "Assets/Resources/Data/Cards";
        string affixPath = "Assets/Resources/Data/Affixes";
        if (!AssetDatabase.IsValidFolder(weaponsPath)) AssetDatabase.CreateFolder("Assets/Resources/Data","Weapons");
        if (!AssetDatabase.IsValidFolder(cardsPath)) AssetDatabase.CreateFolder("Assets/Resources/Data","Cards");
        if (!AssetDatabase.IsValidFolder(affixPath)) AssetDatabase.CreateFolder("Assets/Resources/Data","Affixes");

        // Create affixes
        foreach(var a in root.affixes)
        {
            var inst = ScriptableObject.CreateInstance<AffixData>();
            inst.affixName = a.affixName;
            inst.effectDescription = a.effectDescription;
            inst.value = a.value;
            string p = Path.Combine(affixPath, a.id + ".asset");
            AssetDatabase.CreateAsset(inst, p);
        }

        // Create weapons
        foreach(var w in root.weapons)
        {
            var inst = ScriptableObject.CreateInstance<WeaponData>();
            inst.weaponName = w.weaponName;
            inst.baseDamage = w.baseDamage;
            inst.attackSpeed = w.attackSpeed;
            // find icon by keyword in ImportedAssets/auto_icons or Resources
            string iconPath = FindSpritePath(w.icon_keyword);
            if (!string.IsNullOrEmpty(iconPath))
            {
                inst.icon = AssetDatabase.LoadAssetAtPath<Sprite>(iconPath);
            }
            string p = Path.Combine(weaponsPath, w.id + ".asset");
            AssetDatabase.CreateAsset(inst, p);
        }

        // Create cards
        foreach(var c in root.cards)
        {
            var inst = ScriptableObject.CreateInstance<CardData>();
            inst.cardName = c.cardName;
            inst.description = c.description;
            inst.rarity = c.rarity;
            // try find icon
            string iconPath = FindSpritePath(c.icon_keyword);
            if (!string.IsNullOrEmpty(iconPath))
            {
                inst.icon = AssetDatabase.LoadAssetAtPath<Sprite>(iconPath);
            }
            string p = Path.Combine(cardsPath, c.id + ".asset");
            AssetDatabase.CreateAsset(inst, p);
        }

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("Initial data imported: weapons=" + root.weapons.Length + " cards=" + root.cards.Length + " affixes=" + root.affixes.Length);
    }

    static string FindSpritePath(string keyword)
    {
        if (string.IsNullOrEmpty(keyword)) return null;
        // search in Assets/ImportedAssets/auto_icons
        var guids = AssetDatabase.FindAssets(keyword + " t:Sprite", new[]{ "Assets/ImportedAssets/auto_icons", "Assets/ImportedAssets" });
        if (guids != null && guids.Length>0)
        {
            return AssetDatabase.GUIDToAssetPath(guids[0]);
        }
        // fallback: search anywhere for sprite by name
        guids = AssetDatabase.FindAssets(keyword + " t:Sprite");
        if (guids != null && guids.Length>0) return AssetDatabase.GUIDToAssetPath(guids[0]);
        return null;
    }

    // Json wrapper types (must match the json structure)
    [System.Serializable]
    public class Wrapper
    {
        public WeaponJson[] weapons;
        public CardJson[] cards;
        public AffixJson[] affixes;
    }
    [System.Serializable]
    public class WeaponJson { public string id; public string weaponName; public int baseDamage; public float attackSpeed; public string icon_keyword; }
    [System.Serializable]
    public class CardJson { public string id; public string cardName; public string description; public int rarity; public string icon_keyword; public string instantAbility; }
    [System.Serializable]
    public class AffixJson { public string id; public string affixName; public string effectDescription; public int value; }
}
#endif
