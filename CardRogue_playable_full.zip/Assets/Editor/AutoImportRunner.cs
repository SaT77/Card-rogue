#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using System.IO;

[InitializeOnLoad]
public class AutoImportRunner
{
    static AutoImportRunner()
    {
        // Do not run automatically in CI unless explicitly called via menu to avoid double work
        // This class exists so you can run "Tools/InitialData/Import JSON Data" from the Editor.
    }
}
#endif
