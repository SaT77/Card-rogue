using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using System.IO;

public class AutoBuilder
{
    const string SCENE_PATH = "Assets/Scenes/GeneratedScene.unity";
    const string BUNDLE_ID = "com.yourcompany.cardrogue";
    const string OUTPUT_APK = "Builds/CardRogue.apk";

    [MenuItem("Tools/AutoBuild/Generate Scene And Data")]
    public static void GenerateSceneAndData()
    {
        if (!Directory.Exists("Assets/Scenes")) Directory.CreateDirectory("Assets/Scenes");
        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

        var bootstrap = new GameObject("Bootstrap");
        var pc = System.Type.GetType("PlayerController");
        if (pc != null)
        {
            bootstrap.AddComponent(pc);
            Debug.Log("Added existing PlayerController to Bootstrap.");
        }
        else
        {
            bootstrap.AddComponent<GameBootstrap>();
            Debug.Log("Added PlaceholderPlayerController to Bootstrap.");
        }

        EditorSceneManager.SaveScene(scene, SCENE_PATH);
        Debug.Log("Saved generated scene: " + SCENE_PATH);

        if (!Directory.Exists("Assets/Data")) Directory.CreateDirectory("Assets/Data");

        CreatePlaceholderSO("Assets/Data/ExampleWeapon.asset", typeof(ScriptableObject));
        CreatePlaceholderSO("Assets/Data/ExampleCard.asset", typeof(ScriptableObject));

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        // Run initial JSON importer to create ScriptableObjects
        var importerType = System.Type.GetType("InitialDataImporter");
        if (importerType != null)
        {
            var mi = importerType.GetMethod("ImportJsonData");
            if (mi != null) mi.Invoke(null, null);
        }

    }

    static void CreatePlaceholderSO(string path, System.Type baseType)
    {
        if (File.Exists(path)) return;
        var obj = ScriptableObject.CreateInstance(baseType);
        AssetDatabase.CreateAsset(obj, path);
        Debug.Log("Created placeholder SO " + path);
    }

    [MenuItem("Tools/AutoBuild/Build APK")]
    public static void BuildAndroidAPK()
    {
        PlayerSettings.applicationIdentifier = BUNDLE_ID;
        PlayerSettings.bundleVersion = "1.0.0";
        EditorUserBuildSettings.buildAppBundle = false;
        string[] scenes = { SCENE_PATH };
        if (!File.Exists(SCENE_PATH))
        {
            Debug.LogWarning("Scene not found — generating scene first.");
            GenerateSceneAndData();
        }
        BuildPlayerOptions opts = new BuildPlayerOptions
        {
            scenes = scenes,
            locationPathName = OUTPUT_APK,
            target = BuildTarget.Android,
            options = BuildOptions.None
        };
        var report = BuildPipeline.BuildPlayer(opts);
        if (report != null && report.summary != null)
            Debug.Log("Build finished: " + report.summary.result.ToString());
        else
            Debug.Log("Build finished (no summary available)");
    }
}

public class PlaceholderPlayerController : MonoBehaviour
{
    void Start()
    {
        Debug.Log("PlaceholderPlayerController active.");
    }
}
