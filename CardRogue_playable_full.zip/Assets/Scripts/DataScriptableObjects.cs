using UnityEngine;

[CreateAssetMenu(fileName = "WeaponData", menuName = "CardRogue/Data/Weapon")]
public class WeaponData : ScriptableObject
{
    public string weaponName;
    public int baseDamage;
    public float attackSpeed;
    public Sprite icon;
    public AffixData[] affixes;
}

[CreateAssetMenu(fileName = "CardData", menuName = "CardRogue/Data/Card")]
public class CardData : ScriptableObject
{
    public string cardName;
    public string description;
    public int rarity; // 0-common,1-rare,2-epic...
    public AudioClip sfx;
    public Sprite icon;
}

[CreateAssetMenu(fileName = "AffixData", menuName = "CardRogue/Data/Affix")]
public class AffixData : ScriptableObject
{
    public string affixName;
    public string effectDescription;
    public int value;
}
