using UnityEngine;
using System.Collections.Generic;
using System;
using System.Linq;

public class CardManager : MonoBehaviour
{
    [Header("Dependencies")]
    [SerializeField] private ActionFluxGenerator actionFluxGenerator;
    [SerializeField] private CombatSystem combatSystem;
    [SerializeField] private WeaponManager weaponManager;
    [SerializeField] private PlayerStats playerStats;
    [SerializeField] private PlayerUI playerUI; // To provide UI updates

    [Header("Card Settings")]
    [SerializeField] private int maxActiveHandSize = 3;
    [SerializeField] private int cardActivationFluxCost = 20; // Default cost

    // Events for other systems to subscribe to
    public static event Action<CardData> OnCardActivated;
    public static event Action<List<CardData>> OnActiveHandChanged;
    public static event Action<CardData> OnSelectedCardChanged;
    public static event Action<List<CardData>> OnDeckChanged; // For weapon manager updates


    // Player's full collection of cards (owned, unlocked)
    private Dictionary<CardData, int> _playerCollectedCards = new Dictionary<CardData, int>(); // CardData -> Upgrade Level

    // The current deck used in the run (subset of collected cards)
    private List<CardData> _activeDeck = new List<CardData>();

    // Cards currently in the player's "hand" and available for activation
    private List<CardData> _activeHand = new List<CardData>();

    // The card currently highlighted/selected for potential activation via input
    private CardData _currentlySelectedCard;


    private void Awake()
    {
        InitializeDependencies();
    }

    private void OnEnable()
    {
        // Subscribe to flux change events from ActionFluxGenerator (if needed for UI updates or re-evaluation)
        ActionFluxGenerator.OnFluxChanged += HandleFluxChanged;
    }

    private void OnDisable()
    {
        ActionFluxGenerator.OnFluxChanged -= HandleFluxChanged;
    }

    private void InitializeDependencies()
    {
        if (actionFluxGenerator == null) Debug.LogError("ActionFluxGenerator not assigned to CardManager.", this);
        if (combatSystem == null) Debug.LogError("CombatSystem not assigned to CardManager.", this);
        if (weaponManager == null) Debug.LogError("WeaponManager not assigned to CardManager.", this);
        if (playerStats == null) Debug.LogError("PlayerStats not assigned to CardManager.", this);
        if (playerUI == null) Debug.LogError("PlayerUI not assigned to CardManager.", this);

        // Dummy initialization for demonstration, will be loaded from save or progression
        if (_activeDeck.Count == 0)
        {
            // Example: Add some initial dummy cards
            CardData dummyCard1 = CreateDummyCard("Fireball", CardRarity.Common, 1,
                ScriptableObject.CreateInstance<DamageEffect>(), 20f, "NewDamageEffect", 30f);
            CardData dummyCard2 = CreateDummyCard("Heal", CardRarity.Common, 1,
                ScriptableObject.CreateInstance<HealingEffect>(), 10f, "NewHealingEffect", 25f);
            CardData dummyCard3 = CreateDummyCard("Dash", CardRarity.Uncommon, 1,
                ScriptableObject.CreateInstance<TeleportEffect>(), 0f, "NewTeleportEffect", Vector2.right, 5f, 0, 0f, 0f); // Dir, dist, obst, dmg, rad
            CardData dummyCard4 = CreateDummyCard("Stone Skin", CardRarity.Rare, 1,
                ScriptableObject.CreateInstance<InvulnerabilityEffect>(), 0f, "NewInvulnerabilityEffect", 2f); // Duration is 2s

            AddCardToCollection(dummyCard1);
            AddCardToCollection(dummyCard2);
            AddCardToCollection(dummyCard3);
            AddCardToCollection(dummyCard4);

            // Populate active deck from collected cards (e.g., initial selection)
            _activeDeck.Add(dummyCard1);
            _activeDeck.Add(dummyCard2);
            _activeDeck.Add(dummyCard3);
        }

        PopulateActiveHand(); // Fill hand for initial use
        weaponManager?.UpdateWeaponModifiers(_activeDeck); // Notify weapon manager about initial deck
        OnDeckChanged?.Invoke(_activeDeck); // Notify others of initial deck state
    }

    // Helper to create dummy cards for testing
    private CardData CreateDummyCard(string cardName, CardRarity rarity, int upgradeLevel, CardEffect effectPrefab, float fluxCost, string effectTypeName, params object[] effectParams)
    {
        CardData card = ScriptableObject.CreateInstance<CardData>();
        card.name = cardName;
        card.CardName = cardName;
        card.Rarity = rarity;
        card.FluxCost = fluxCost;

        CardEffect effectInstance = Instantiate(effectPrefab);
        effectInstance.name = effectTypeName + "_" + cardName;

        if (effectInstance is DamageEffect damageEffect)
        {
            damageEffect.DamageAmount = (float)effectParams[0];
        }
        else if (effectInstance is HealingEffect healingEffect)
        {
            healingEffect.HealAmount = (float)effectParams[0];
        }
        else if (effectInstance is TeleportEffect teleportEffect)
        {
            teleportEffect.Direction = (Vector2)effectParams[0];
            teleportEffect.Distance = (float)effectParams[1];
            teleportEffect.ObstacleLayers = (int)effectParams[2];
            teleportEffect.DamageOnArrival = (float)effectParams[3];
            teleportEffect.DamageRadius = (float)effectParams[4];
            teleportEffect.EnemyLayers = (int)effectParams[5];
        }
        else if (effectInstance is InvulnerabilityEffect invulEffect)
        {
            invulEffect.Duration = (float)effectParams[0];
        }

        card.Effects = new List<CardEffect> { effectInstance };

        // For IWeaponModifierProvider, if applicable
        if (card.CardName == "Fireball")
        {
            AffixData fireAffix = ScriptableObject.CreateInstance<AffixData>();
            fireAffix.name = "Fire Damage Bonus";
            fireAffix.AffixName = "Fire Damage Bonus";
            DamageModifierEffect fireDmgMod = ScriptableObject.CreateInstance<DamageModifierEffect>();
            fireDmgMod.Multiplier = 1.1f; // +10% damage
            fireAffix.Effects = new List<CardEffect> { fireDmgMod };
            card.WeaponAffixToGrant = fireAffix;
        }

        return card;
    }


    /// <summary>
    /// Adds a card to the player's overall collected cards.
    /// If the card already exists, its upgrade level is incremented.
    /// </summary>
    /// <param name="card">The CardData to add.</param>
    public void AddCard(CardData card)
    {
        AddCardToCollection(card);
        // Automatically add to active deck if space allows and it's a new card?
        // Or leave it to ProgressionManager/Player to select deck.
    }

    private void AddCardToCollection(CardData card)
    {
        if (card == null)
        {
            Debug.LogError("Attempted to add a null card to collection.");
            return;
        }

        if (_playerCollectedCards.ContainsKey(card))
        {
            _playerCollectedCards[card]++; // Increment upgrade level
            Debug.Log($"Card {card.CardName} already collected. Upgraded to level {_playerCollectedCards[card]}");
        }
        else
        {
            _playerCollectedCards.Add(card, 1); // Add with level 1
            Debug.Log($"Added new card to collection: {card.CardName}");
        }
    }

    /// <summary>
    /// Removes a card from the player's collection.
    /// Also removes it from active deck and hand if present.
    /// </summary>
    /// <param name="card">The CardData to remove.</param>
    public void RemoveCard(CardData card)
    {
        if (card == null)
        {
            Debug.LogError("Attempted to remove a null card.");
            return;
        }

        if (_playerCollectedCards.Remove(card))
        {
            Debug.Log($"Removed card: {card.CardName} from collection.");
            // Also remove from active deck and hand
            if (_activeDeck.Remove(card))
            {
                weaponManager?.UpdateWeaponModifiers(_activeDeck);
                OnDeckChanged?.Invoke(_activeDeck);
                Debug.Log($"Removed {card.CardName} from active deck.");
            }
            if (_activeHand.Remove(card))
            {
                Debug.Log($"Removed {card.CardName} from active hand.");
                PopulateActiveHand(); // Try to draw a new one
                OnActiveHandChanged?.Invoke(_activeHand);
            }

            // If the removed card was selected, clear selection or select next
            if (_currentlySelectedCard == card)
            {
                TacticalCardSwap(0); // This will select the next valid card or null
            }
        }
        else
        {
            Debug.LogWarning($"Card {card.CardName} not found in collected cards to remove.");
        }
    }

    /// <summary>
    /// Upgrades a specific card, enhancing its effects or stats.
    /// This typically involves modifying the CardData's internal properties based on its current level.
    /// </summary>
    /// <param name="card">The CardData to upgrade.</param>
    public void UpgradeCard(CardData card)
    {
        if (card == null)
        {
            Debug.LogError("Attempted to upgrade a null card.");
            return;
        }

        if (_playerCollectedCards.TryGetValue(card, out int currentLevel))
        {
            // Placeholder: Apply actual upgrade logic based on card type and current level
            // This might modify the card's effects, flux cost, or add new properties.
            // For now, just increment the level.
            _playerCollectedCards[card]++;
            Debug.Log($"Upgraded card: {card.CardName} to level {_playerCollectedCards[card]}");
            // Re-evaluate weapon modifiers if this card is in the active deck
            if (_activeDeck.Contains(card))
            {
                weaponManager?.UpdateWeaponModifiers(_activeDeck);
                OnDeckChanged?.Invoke(_activeDeck);
            }
        }
        else
        {
            Debug.LogWarning($"Card {card.CardName} not found in collection to upgrade.");
        }
    }

    /// <summary>
    /// Activates a specific card, consuming Action Flux and applying its effects.
    /// This method is typically called by player input (e.g., from PlayerController).
    /// </summary>
    /// <param name="card">The CardData to activate.</param>
    public void ActivateCard(CardData card)
    {
        if (card == null)
        {
            Debug.LogError("Attempted to activate a null card.");
            return;
        }

        if (!CanActivateCard(card))
        {
            Debug.Log($"Cannot activate {card.CardName}: Not enough flux ({actionFluxGenerator.GetCurrentFlux()}/{card.FluxCost}) or card not in active hand.");
            return;
        }

        if (actionFluxGenerator.ConsumeFlux((int)card.FluxCost)) // Flux cost is now from CardData
        {
            Debug.Log($"Activating card: {card.CardName}");

            // Apply card effects to the player
            if (playerStats == null || combatSystem == null)
            {
                Debug.LogError("PlayerStats or CombatSystem not assigned, cannot apply card effects.");
                return;
            }

            foreach (CardEffect effect in card.Effects)
            {
                if (effect != null)
                {
                    combatSystem.ApplyEffect(playerStats.gameObject, effect);
                }
                else
                {
                    Debug.LogWarning($"Card {card.CardName} has a null effect in its list.");
                }
            }

            // Remove card from active hand and try to draw a new one
            _activeHand.Remove(card);
            PopulateActiveHand();
            OnActiveHandChanged?.Invoke(_activeHand);

            // If the activated card was the currently selected one, select the next available.
            if (_currentlySelectedCard == card)
            {
                TacticalCardSwap(0); // This will re-select the current (if it wasn't activated) or the first card
            }

            OnCardActivated?.Invoke(card);
        }
        else
        {
            Debug.LogWarning($"Failed to consume flux for card {card.CardName}. This should have been caught by CanActivateCard.");
        }
    }

    /// <summary>
    /// Checks if a card can be activated (e.g., enough flux, card is in hand).
    /// </summary>
    /// <param name="card">The CardData to check.</param>
    /// <returns>True if the card can be activated, false otherwise.</returns>
    public bool CanActivateCard(CardData card)
    {
        if (card == null) return false;
        return _activeHand.Contains(card) && actionFluxGenerator.GetCurrentFlux() >= card.FluxCost;
    }

    /// <summary>
    /// Sets the player's active deck for the current run. This updates weapon modifiers.
    /// Also triggers repopulation of the active hand.
    /// </summary>
    /// <param name="newDeck">The list of CardData to set as the active deck.</param>
    public void SetActiveDeck(List<CardData> newDeck)
    {
        if (newDeck == null)
        {
            Debug.LogError("Attempted to set active deck to null.");
            return;
        }

        _activeDeck = newDeck;
        Debug.Log($"Active deck set with {_activeDeck.Count} cards.");
        weaponManager?.UpdateWeaponModifiers(_activeDeck); // Notify weapon manager
        OnDeckChanged?.Invoke(_activeDeck);

        PopulateActiveHand(); // Ensure hand is consistent with new deck
    }

    /// <summary>
    /// Fills the active hand from the active deck, respecting MaxActiveHandSize.
    /// This method ensures unique cards are drawn and the hand is replenished.
    /// </summary>
    private void PopulateActiveHand()
    {
        // Remove any cards from hand that are no longer in the active deck
        _activeHand.RemoveAll(card => !_activeDeck.Contains(card));

        // Draw new cards until hand is full or deck is exhausted
        while (_activeHand.Count < maxActiveHandSize)
        {
            List<CardData> drawableCards = _activeDeck.Except(_activeHand).ToList();
            if (drawableCards.Count > 0)
            {
                CardData drawnCard = drawableCards[UnityEngine.Random.Range(0, drawableCards.Count)];
                _activeHand.Add(drawnCard);
                Debug.Log($"Drew card: {drawnCard.CardName}");
            }
            else
            {
                Debug.Log("No more unique cards to draw from deck into hand.");
                break; // No more unique cards to draw
            }
        }

        // If no card is selected, select the first one if available
        if (_currentlySelectedCard == null && _activeHand.Count > 0)
        {
            _currentlySelectedCard = _activeHand[0];
            OnSelectedCardChanged?.Invoke(_currentlySelectedCard);
        }
        // If the selected card is no longer in hand (e.g., activated), select the next available
        else if (_currentlySelectedCard != null && !_activeHand.Contains(_currentlySelectedCard))
        {
            TacticalCardSwap(0); // This will effectively re-select the current or next valid card
        }

        OnActiveHandChanged?.Invoke(_activeHand);
        playerUI?.UpdateActiveHand(_activeHand);
    }

    /// <summary>
    /// Allows rapid swapping between active cards in hand for quick selection.
    /// </summary>
    /// <param name="direction">1 for next, -1 for previous, 0 to re-select current or first if current is invalid.</param>
    public void TacticalCardSwap(int direction)
    {
        if (_activeHand.Count == 0)
        {
            _currentlySelectedCard = null;
            Debug.Log("No cards in hand to swap.");
            OnSelectedCardChanged?.Invoke(null);
            return;
        }

        int currentIndex = -1;
        if (_currentlySelectedCard != null)
        {
            currentIndex = _activeHand.IndexOf(_currentlySelectedCard);
        }

        int nextIndex;

        if (direction == 0) // Re-select current or first valid
        {
            // If current card is still valid and in hand, keep it. Otherwise, select the first card.
            nextIndex = (currentIndex != -1 && currentIndex < _activeHand.Count) ? currentIndex : 0;
        }
        else
        {
            nextIndex = currentIndex + direction;
            if (nextIndex >= _activeHand.Count)
            {
                nextIndex = 0; // Wrap around to start
            }
            else if (nextIndex < 0)
            {
                nextIndex = _activeHand.Count - 1; // Wrap around to end
            }
        }

        if (nextIndex >= 0 && nextIndex < _activeHand.Count)
        {
            _currentlySelectedCard = _activeHand[nextIndex];
            Debug.Log($"Currently selected card: {_currentlySelectedCard.CardName}");
            OnSelectedCardChanged?.Invoke(_currentlySelectedCard);
        }
        else
        {
            // This case should ideally not happen if _activeHand.Count > 0, but as a safeguard.
            _currentlySelectedCard = null;
            Debug.LogWarning("TacticalCardSwap: No valid card to select after attempting to swap.");
            OnSelectedCardChanged?.Invoke(null);
        }
    }

    /// <summary>
    /// Returns the card that is currently selected in the player's active hand.
    /// </summary>
    /// <returns>The currently selected CardData, or null if no card is selected.</returns>
    public CardData GetCurrentlySelectedCard()
    {
        return _currentlySelectedCard;
    }

    /// <summary>
    /// Returns the list of cards currently in the player's active hand.
    /// </summary>
    /// <returns>A List of CardData objects representing the active hand.</returns>
    public List<CardData> GetActiveHand()
    {
        return new List<CardData>(_activeHand); // Return a copy to prevent external modification
    }

    /// <summary>
    /// Returns the list of cards currently in the player's active deck.
    /// </summary>
    /// <returns>A List of CardData objects representing the active deck.</returns>
    public List<CardData> GetActiveDeck()
    {
        return new List<CardData>(_activeDeck); // Return a copy
    }

    /// <summary>
    /// Returns the player's full collection of cards with their upgrade levels.
    /// </summary>
    /// <returns>A Dictionary mapping CardData to its upgrade level.</returns>
    public Dictionary<CardData, int> GetPlayerCollectedCards()
    {
        return new Dictionary<CardData, int>(_playerCollectedCards); // Return a copy
    }

    private void HandleFluxChanged(int currentFlux)
    {
        // This handler can be used to visually update the UI regarding card activation availability
        // or trigger any logic dependent on flux thresholds.
        // The PlayerUI is directly subscribed to OnFluxChanged, so this might be redundant for basic UI.
        // However, if CardManager needs to react internally to flux changes, this is the place.
        Debug.Log($"CardManager received flux change: {currentFlux}");
    }
}


// Interfaces for dependency classes if not already globally available
// (Assuming these are defined in a shared or pre-compiled assembly)

/// <summary>
/// This interface is for CardData or other ScriptableObjects that can provide AffixData to weapons.
/// This allows WeaponManager to query cards for their weapon-modifying properties.
/// </summary>
public interface IWeaponModifierProvider
{
    List<AffixData> GetWeaponAffixes();
}

/// <summary>
/// This interface is for CardData or other ScriptableObjects that can provide CardEffect instances.
/// </summary>
public interface ICardEffectProvider
{
    List<CardEffect> GetEffects();
}

[Serializable]
public enum CardRarity
{
    Common,
    Uncommon,
    Rare,
    Epic,
    Legendary
}

// Dummy CardData class, replace with actual implementation if different
[CreateAssetMenu(fileName = "NewCardData", menuName = "Game Data/Card Data")]
public class CardData : ScriptableObject, IWeaponModifierProvider, ICardEffectProvider
{
    public string CardName;
    [TextArea] public string Description;
    public Sprite Icon;
    public CardRarity Rarity;
    public float FluxCost; // Cost to activate this card

    // Effects this card triggers upon activation
    public List<CardEffect> Effects = new List<CardEffect>();

    // Affix this card grants to the equipped weapon while in the active deck
    public AffixData WeaponAffixToGrant; // Can be null if card doesn't grant weapon affix

    public List<AffixData> GetWeaponAffixes()
    {
        List<AffixData> affixes = new List<AffixData>();
        if (WeaponAffixToGrant != null)
        {
            affixes.Add(WeaponAffixToGrant);
        }
        return affixes;
    }

    public List<CardEffect> GetEffects()
    {
        return Effects;
    }
}