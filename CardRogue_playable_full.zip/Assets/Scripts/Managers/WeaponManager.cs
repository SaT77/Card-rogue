using UnityEngine;
using System.Collections.Generic;
using System;
using System.Collections;
using System.Linq;

public class WeaponManager : MonoBehaviour
{
    [SerializeField] private WeaponData equippedWeapon;
    [SerializeField] private PlayerStats playerStats; // For potential use in complex damage calculations or stat scaling
    [SerializeField] private PlayerAnimationController playerAnimationController; // To handle weapon-specific animations

    // The cards currently in the player's active deck.
    // This list is updated by the CardManager.
    private List<CardData> _activeDeckCards = new List<CardData>();

    // A list of combo abilities currently unlocked by active cards.
    // These are temporary and typically activated via CardEffect.
    private List<ComboAbilityType> _activeComboAbilities = new List<ComboAbilityType>();

    // Public property to access the currently equipped weapon.
    public WeaponData EquippedWeapon => equippedWeapon;

    private void Awake()
    {
        if (playerStats == null) Debug.LogError("PlayerStats not assigned to WeaponManager.", this);
        if (playerAnimationController == null) Debug.LogError("PlayerAnimationController not assigned to WeaponManager.", this);
        if (equippedWeapon == null) Debug.LogWarning("No weapon assigned to EquippedWeapon slot on Awake. Please assign a default weapon or equip one programmatically.", this);
    }

    /// <summary>
    /// Updates the list of active cards in the player's deck.
    /// This method is expected to be called by the CardManager whenever the active deck changes.
    /// Upon update, it triggers a recalculation of deck-bound weapon modifiers.
    /// </summary>
    /// <param name="activeDeck">The current list of CardData objects in the player's active deck.</param>
    public void UpdateWeaponModifiers(List<CardData> activeDeck)
    {
        _activeDeckCards = activeDeck;
        ApplyDeckBoundModifiers();
    }

    /// <summary>
    /// Equips a new weapon for the player. This will clear any existing card-based modifiers
    /// from the old weapon (if any) and apply relevant modifiers from the current active deck
    /// to the new weapon. It also updates the animation controller.
    /// </summary>
    /// <param name="newWeapon">The WeaponData ScriptableObject representing the weapon to equip.</param>
    public void EquipWeapon(WeaponData newWeapon)
    {
        if (newWeapon == null)
        {
            Debug.LogError("Attempted to equip a null weapon.");
            return;
        }

        // Clear modifiers from the previously equipped weapon to prevent lingering effects.
        if (equippedWeapon != null)
        {
            equippedWeapon.ClearCardModifiers();
            Debug.Log($"Unequipped {equippedWeapon.WeaponName}. Cleared its modifiers.");
            // Potentially trigger unequip animations or visual changes.
        }

        equippedWeapon = newWeapon;
        if (equippedWeapon != null)
        {
            ApplyDeckBoundModifiers(); // Apply current deck's modifiers to the newly equipped weapon.
            Debug.Log($"Equipped weapon: {equippedWeapon.WeaponName}.");
            // Update the player's animation controller to use the new weapon's animations.
            // Assuming PlayerAnimationController has a method to set the weapon type for animation logic.
            // playerAnimationController.SetWeaponType(equippedWeapon.WeaponType); // Example placeholder
        }
        else
        {
            // This case should ideally be handled by the 'if (newWeapon == null)' check,
            // but included for clarity if `equippedWeapon` somehow becomes null internally.
            Debug.Log("No weapon equipped.");
            // playerAnimationController.SetWeaponType(WeaponType.None); // Example placeholder
        }
    }

    /// <summary>
    /// Retrieves the data for the weapon currently equipped by the player.
    /// </summary>
    /// <returns>The WeaponData ScriptableObject of the equipped weapon, or null if no weapon is equipped.</returns>
    public WeaponData GetEquippedWeapon()
    {
        return equippedWeapon;
    }

    /// <summary>
    /// Applies dynamic modifiers to the currently equipped weapon based on the cards in the active deck.
    /// This method clears all previous card-based modifiers and reapplies them, ensuring the weapon's state
    /// is always in sync with the current active deck.
    /// </summary>
    private void ApplyDeckBoundModifiers()
    {
        if (equippedWeapon == null)
        {
            Debug.LogWarning("Cannot apply deck-bound modifiers: No weapon equipped.");
            return;
        }

        equippedWeapon.ClearCardModifiers(); // Remove all old card-based modifiers

        // Iterate through each card in the active deck to find and apply relevant weapon modifiers.
        foreach (CardData card in _activeDeckCards)
        {
            // Cards that provide weapon modifiers should implement an interface like IWeaponModifierProvider.
            // This allows for a clean way to extract relevant AffixData from CardData.
            if (card is IWeaponModifierProvider modifierProvider)
            {
                foreach (AffixData affix in modifierProvider.GetWeaponAffixes())
                {
                    if (affix != null)
                    {
                        equippedWeapon.AddCardModifier(affix);
                    }
                    else
                    {
                        Debug.LogWarning($"Card '{card.name}' provided a null AffixData through IWeaponModifierProvider.");
                    }
                }
            }
            // For card types that might directly define a single affix, an alternative check:
            else if (card.WeaponAffixToGrant != null) // Assuming CardData has a public property `WeaponAffixToGrant`
            {
                equippedWeapon.AddCardModifier(card.WeaponAffixToGrant);
            }
        }
        Debug.Log($"Applied deck-bound modifiers to {equippedWeapon.WeaponName} based on {_activeDeckCards.Count} active cards.");
    }

    /// <summary>
    /// Activates a specific combo ability for the equipped weapon. This method is typically
    /// called by the CombatSystem when a `ComboUnlockEffect` card is activated.
    /// The combo ability will remain active for the specified duration.
    /// </summary>
    /// <param name="comboType">The type of combo ability to activate (e.g., Shockwave, RapidFire).</param>
    /// <param name="duration">The duration in seconds for which the combo ability should be active.</param>
    public void ActivateComboAbility(ComboAbilityType comboType, float duration)
    {
        if (!_activeComboAbilities.Contains(comboType))
        {
            _activeComboAbilities.Add(comboType);
            Debug.Log($"Activated combo ability: {comboType} for {duration} seconds.");
            StartCoroutine(DeactivateComboAbilityAfterDuration(comboType, duration));
            // Trigger animation or visual effect for combo activation.
            // playerAnimationController.TriggerComboAnimation(comboType); // Example placeholder
        }
        else
        {
            Debug.Log($"Combo ability {comboType} is already active. Re-applying duration (extending if previous duration was shorter).");
            // If the combo is already active, we stop the old coroutine and start a new one to extend/refresh the duration.
            // This requires tracking active coroutines per combo type. For simplicity, just restarting for now.
            StopCoroutine(DeactivateComboAbilityAfterDuration(comboType, 0)); // Stop any existing coroutine for this combo type
            StartCoroutine(DeactivateComboAbilityAfterDuration(comboType, duration));
        }
    }

    /// <summary>
    /// Coroutine to deactivate a combo ability after a specified duration.
    /// </summary>
    /// <param name="comboType">The type of combo ability to deactivate.</param>
    /// <param name="duration">The time in seconds to wait before deactivating.</param>
    private IEnumerator DeactivateComboAbilityAfterDuration(ComboAbilityType comboType, float duration)
    {
        yield return new WaitForSeconds(duration);
        _activeComboAbilities.Remove(comboType);
        Debug.Log($"Deactivated combo ability: {comboType}.");
    }

    /// <summary>
    /// Checks if a specific combo ability is currently active. This can be used by
    /// PlayerController or CombatSystem to enable special attacks or modified behaviors.
    /// </summary>
    /// <param name="comboType">The type of combo ability to check.</param>
    /// <returns>True if the combo ability is currently active, false otherwise.</returns>
    public bool IsComboAbilityActive(ComboAbilityType comboType)
    {
        return _activeComboAbilities.Contains(comboType);
    }
}


// --- Dependency Interfaces and Classes (Re-declare if not available globally) ---

/// <summary>
/// An interface for CardData or other ScriptableObjects that can provide AffixData to weapons.
/// This allows WeaponManager to query cards for their weapon-modifying properties.
/// </summary>
public interface IWeaponModifierProvider
{
    List<AffixData> GetWeaponAffixes();
}

// Dummy classes for dependencies to allow compilation if they are not defined elsewhere
// In a real project, these would be fully implemented ScriptableObjects or components.

// This is a minimal CardData definition needed by WeaponManager.
// The actual CardData should likely extend ScriptableObject and contain more fields.
public class CardData : ScriptableObject
{
    // A placeholder for a specific affix this card might grant directly to a weapon.
    // This is an alternative to implementing IWeaponModifierProvider for simpler cards.
    public AffixData WeaponAffixToGrant;

    // A placeholder for a list of effects this card might have, if it's not a modifier provider.
    // This is primarily for CardManager, but included here for completeness of CardData.
    public List<CardEffect> Effects;
}