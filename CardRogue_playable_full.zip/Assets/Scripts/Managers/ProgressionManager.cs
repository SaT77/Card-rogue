using UnityEngine;
using UnityEngine.SceneManagement;
using System;
using System.Collections.Generic;
using System.Linq;

public class ProgressionManager : MonoBehaviour
{
    // Events for other systems to subscribe to for game state changes
    public static event Action OnRunStarted;
    public static event Action<bool> OnRunEnded; // bool: true for success, false for failure
    public static event Action OnRoomLoaded;
    public static event Action<GameState> OnGameStateChanged;

    [Header("Dependencies")]
    [SerializeField] private PlayerStats playerStats;
    [SerializeField] private ItemManager itemManager;
    [SerializeField] private CardManager cardManager;
    [SerializeField] private PlayerUI playerUI;
    [SerializeField] private RoomGenerator roomGenerator; // Assumed to exist for procedural generation

    [Header("Scene Management")]
    [Tooltip("The name of the main menu scene.")]
    [SerializeField] private string mainMenuSceneName = "MainMenu";
    [Tooltip("The name of the game scene where actual gameplay occurs (e.g., first room).")]
    [SerializeField] private string gameSceneName = "GameScene";

    [Header("Progression Settings")]
    [Tooltip("The initial deck of cards provided at the start of a new run.")]
    [SerializeField] private List<CardData> initialDeckCards;
    [Tooltip("The initial weapon provided at the start of a new run.")]
    [SerializeField] private ItemManager.WeaponData initialWeapon;
    [Tooltip("The initial equipment provided at the start of a new run.")]
    [SerializeField] private List<ItemManager.EquipmentData> initialEquipment;

    private GameState _currentGameState = GameState.MainMenu;
    private int _currentRoomIndex = -1; // -1 indicates not in a run or in Main Menu
    private List<string> _currentRunRoomSequence; // List of room IDs/names for the current run

    public enum GameState
    {
        MainMenu,
        InGame,
        Paused,
        GameOver,
        Victory
    }

    private void Awake()
    {
        if (playerStats == null) Debug.LogError("PlayerStats not assigned to ProgressionManager.", this);
        if (itemManager == null) Debug.LogError("ItemManager not assigned to ProgressionManager.", this);
        if (cardManager == null) Debug.LogError("CardManager not assigned to ProgressionManager.", this);
        if (playerUI == null) Debug.LogError("PlayerUI not assigned to ProgressionManager.", this);
        if (roomGenerator == null) Debug.LogError("RoomGenerator not assigned to ProgressionManager.", this);

        // Ensure ProgressionManager persists across scenes if it handles global game state
        DontDestroyOnLoad(gameObject);
    }

    private void OnEnable()
    {
        // Subscribe to PlayerStats for game over condition
        PlayerStats.OnHealthChanged += HandlePlayerHealthChanged;
        // Listen to scene loaded event to initialize game elements after scene load
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDisable()
    {
        PlayerStats.OnHealthChanged -= HandlePlayerHealthChanged;
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    /// <summary>
    /// Starts a new roguelike run. Resets player, items, cards, and loads the first room.
    /// </summary>
    public void StartNewRun()
    {
        if (_currentGameState == GameState.InGame)
        {
            Debug.LogWarning("Already in a run. Call EndRun first if you want to restart.");
            return;
        }

        Debug.Log("Starting new run...");
        SetGameState(GameState.InGame);

        // Reset player stats (e.g., full health, default stats)
        // This might involve re-enabling PlayerStats if it was disabled, or calling a specific reset method.
        // For PlayerStats, we assume a "Reset" might be called implicitly by other managers or on enabling.
        // A direct reset on PlayerStats might be preferable for a clean slate.
        if (playerStats != null)
        {
            // A more robust PlayerStats might have a ResetToDefaults() method
            // For now, assuming it resets on Awake/OnEnable of the new scene.
            // If PlayerStats is DontDestroyOnLoad, it needs an explicit reset:
            // playerStats.ResetStats();
        }

        // Clear and initialize inventory and equipment
        itemManager.UnequipItem(itemManager.GetEquippedWeaponInstance()); // Unequip current weapon
        foreach (ItemManager.EquipmentType type in Enum.GetValues(typeof(ItemManager.EquipmentType)))
        {
            itemManager.UnequipItem(itemManager.GetEquippedEquipmentInstance(type)); // Unequip all equipment
        }
        // Assuming ItemManager has a method to clear inventory for a new run
        // itemManager.ClearInventory();

        // Equip initial weapon and equipment
        if (initialWeapon != null)
        {
            ItemManager.ItemInstance weaponInstance = itemManager.GenerateRandomItem(ItemManager.ItemType.Weapon);
            if (weaponInstance != null && weaponInstance is ItemManager.WeaponInstance actualWeaponInstance)
            {
                itemManager.EquipItem(actualWeaponInstance);
            }
            else
            {
                Debug.LogWarning("Initial weapon data could not be converted to WeaponInstance, or was null after generation.");
            }
        }
        else
        {
            Debug.LogWarning("No initial weapon assigned in ProgressionManager.");
        }

        if (initialEquipment != null && initialEquipment.Any())
        {
            foreach (var eqData in initialEquipment)
            {
                ItemManager.ItemInstance eqInstance = itemManager.GenerateRandomItem(ItemManager.ItemType.Equipment);
                if (eqInstance != null && eqInstance is ItemManager.EquipmentInstance actualEqInstance)
                {
                    itemManager.EquipItem(actualEqInstance);
                }
                else
                {
                    Debug.LogWarning($"Initial equipment data '{eqData?.ItemName}' could not be converted to EquipmentInstance, or was null after generation.");
                }
            }
        }
        else
        {
            Debug.LogWarning("No initial equipment assigned in ProgressionManager.");
        }


        // Set up initial card deck
        if (initialDeckCards != null && initialDeckCards.Any())
        {
            cardManager.SetActiveDeck(new List<CardData>(initialDeckCards));
        }
        else
        {
            Debug.LogWarning("No initial deck cards assigned in ProgressionManager.");
        }

        // Generate the sequence of rooms for this run
        _currentRunRoomSequence = roomGenerator.GenerateRunRoomSequence();
        _currentRoomIndex = 0;

        OnRunStarted?.Invoke();
        LoadNextRoom(); // Load the first room
    }

    /// <summary>
    /// Ends the current run, either successfully or due to player death.
    /// </summary>
    /// <param name="success">True if the run ended in victory, false if it was a game over.</param>
    public void EndRun(bool success)
    {
        Debug.Log($"Run ended. Success: {success}");

        _currentRoomIndex = -1; // Reset room index
        _currentRunRoomSequence = null; // Clear room sequence

        SetGameState(success ? GameState.Victory : GameState.GameOver);
        OnRunEnded?.Invoke(success);

        // Optionally transition to a game over/victory screen or main menu
        LoadScene(mainMenuSceneName);
    }

    /// <summary>
    /// Loads the next room in the sequence or ends the run if no more rooms.
    /// This method is typically called by a "door" or "level exit" trigger.
    /// </summary>
    public void LoadNextRoom()
    {
        if (_currentRunRoomSequence == null || _currentRoomIndex >= _currentRunRoomSequence.Count)
        {
            Debug.Log("No more rooms in the sequence. Ending run (Victory).");
            EndRun(true); // Player completed all rooms
            return;
        }

        if (_currentRoomIndex < 0)
        {
            Debug.LogError("Current room index is invalid. Cannot load next room.", this);
            return;
        }

        string roomToLoad = _currentRunRoomSequence[_currentRoomIndex];
        Debug.Log($"Loading room: {roomToLoad} (Room {_currentRoomIndex + 1}/{_currentRunRoomSequence.Count})");

        // Assuming RoomGenerator can load/spawn a room by its identifier
        roomGenerator.LoadRoom(roomToLoad);

        // Increment room index for the next load
        _currentRoomIndex++;

        // Notify that a room has been loaded, allowing other systems to react
        OnRoomLoaded?.Invoke();
    }

    /// <summary>
    /// Generates a new random room (for single-room generation, or if the run sequence is dynamic).
    /// This might be redundant if `LoadNextRoom` already handles sequence based generation via `RoomGenerator.LoadRoom`.
    /// Used here to satisfy specified main_functions, assuming it's for spawning a standalone room.
    /// </summary>
    public void GenerateNewRoom()
    {
        if (roomGenerator == null)
        {
            Debug.LogError("RoomGenerator is not assigned to ProgressionManager, cannot generate new room.");
            return;
        }
        Debug.Log("Generating a new random room.");
        roomGenerator.GenerateRoom(); // Assuming this generates a room instance immediately
        OnRoomLoaded?.Invoke();
    }

    /// <summary>
    /// Handles the event when the player's health changes, checking for game over.
    /// </summary>
    /// <param name="currentHealth">The player's current health.</param>
    /// <param name="maxHealth">The player's maximum health.</param>
    private void HandlePlayerHealthChanged(float currentHealth, float maxHealth)
    {
        if (currentHealth <= 0 && _currentGameState == GameState.InGame)
        {
            Debug.Log("Player health reached zero. Game Over!");
            EndRun(false); // Player died
        }
    }

    /// <summary>
    /// Sets the current game state and invokes the OnGameStateChanged event.
    /// </summary>
    /// <param name="newState">The new game state to set.</param>
    public void SetGameState(GameState newState)
    {
        if (_currentGameState == newState) return; // No change

        Debug.Log($"Game State changed from {_currentGameState} to {newState}");
        _currentGameState = newState;
        OnGameStateChanged?.Invoke(_currentGameState);

        // Handle specific state transitions
        switch (_currentGameState)
        {
            case GameState.Paused:
                Time.timeScale = 0f;
                playerUI?.ShowPauseMenu(true);
                break;
            case GameState.InGame:
                Time.timeScale = 1f;
                playerUI?.ShowPauseMenu(false);
                break;
            case GameState.GameOver:
            case GameState.Victory:
                Time.timeScale = 0f; // Pause game logic on game over/victory
                playerUI?.ShowPauseMenu(false); // Hide pause menu, show game over screen (handled by other UI elements)
                break;
            case GameState.MainMenu:
                Time.timeScale = 1f;
                playerUI?.ShowPauseMenu(false);
                break;
        }
    }

    /// <summary>
    /// Gets the current game state.
    /// </summary>
    /// <returns>The current GameState enum value.</returns>
    public GameState GetCurrentGameState()
    {
        return _currentGameState;
    }

    /// <summary>
    /// Saves game progression (meta-progression outside of a single run).
    /// </summary>
    public void SaveProgression()
    {
        Debug.Log("Saving game progression (meta-progression and unlocks)...");
        // Example: Save unlocked cards, permanent upgrades, player stats that persist across runs.
        // This is where you'd use PlayerPrefs, JSON, or BinaryFormatter.
        // PlayerPrefs.SetInt("UnlockedCardCount", cardManager.GetPlayerCollectedCards().Count);
        // PlayerPrefs.Save();
    }

    /// <summary>
    /// Loads game progression (meta-progression outside of a single run).
    /// </summary>
    public void LoadProgression()
    {
        Debug.Log("Loading game progression (meta-progression and unlocks)...");
        // Example: Load unlocked cards, permanent upgrades, etc.
        // int unlockedCards = PlayerPrefs.GetInt("UnlockedCardCount", 0);
        // Debug.Log($"Loaded {unlockedCards} unlocked cards.");
    }

    /// <summary>
    /// Loads a scene by name.
    /// </summary>
    /// <param name="sceneName">The name of the scene to load.</param>
    private void LoadScene(string sceneName)
    {
        if (string.IsNullOrEmpty(sceneName))
        {
            Debug.LogError("Attempted to load a scene with a null or empty name.");
            return;
        }
        SceneManager.LoadScene(sceneName);
    }

    /// <summary>
    /// Callback for when a new scene is loaded.
    /// Used to initialize specific game elements that might be scene-dependent.
    /// </summary>
    /// <param name="scene">The loaded scene.</param>
    /// <param name="mode">The load scene mode.</param>
    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (scene.name == mainMenuSceneName)
        {
            SetGameState(GameState.MainMenu);
            // Additional setup for main menu scene if needed
        }
        else if (scene.name == gameSceneName)
        {
            // Ensure game state is InGame if we've explicitly loaded the game scene.
            // This might be redundant if StartNewRun already set it, but good for robustness.
            if (_currentGameState != GameState.InGame && _currentGameState != GameState.Paused)
            {
                SetGameState(GameState.InGame);
            }
        }
    }

    /// <summary>
    /// Pauses the game by setting the game state to Paused.
    /// </summary>
    public void PauseGame()
    {
        if (_currentGameState == GameState.InGame)
        {
            SetGameState(GameState.Paused);
        }
    }

    /// <summary>
    /// Resumes the game by setting the game state to InGame.
    /// </summary>
    public void ResumeGame()
    {
        if (_currentGameState == GameState.Paused)
        {
            SetGameState(GameState.InGame);
        }
    }
}