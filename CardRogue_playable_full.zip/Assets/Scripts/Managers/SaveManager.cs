using UnityEngine;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

public class SaveManager : MonoBehaviour
{
    [Header("Dependencies")]
    [SerializeField] private ProgressionManager progressionManager;
    [SerializeField] private PlayerStats playerStats;
    [SerializeField] private ItemManager itemManager;
    [SerializeField] private CardManager cardManager;
    [SerializeField] private WeaponManager weaponManager; // WeaponManager is implicitly handled by ItemManager.EquipWeapon and CardManager
    [SerializeField] private RoomGenerator roomGenerator;

    private string saveFilePath;

    /// <summary>
    /// Data structure to hold all serializable game state for a roguelike run.
    /// </summary>
    [Serializable]
    private class SaveData
    {
        // Player State
        public float currentHealth;
        public float maxHealth; // This is the calculated max health from PlayerStats
        public float playerPositionX;
        public float playerPositionY;
        public string currentSceneName; // Name of the scene the player is in

        // Progression State
        public ProgressionManager.GameState currentGameState; // Should be InGame when saving a run
        public int currentRoomIndex;
        public List<string> currentRunRoomSequence; // List of room identifiers

        // Inventory and Equipment
        public List<ItemInstanceSaveData> inventory;
        public WeaponInstanceSaveData equippedWeapon;
        public List<EquipmentInstanceSaveData> equippedEquipment;

        // Card Deck and Hand
        public List<CardSaveData> activeDeck;
        public List<CardSaveData> activeHand;

        [Serializable]
        public class ItemInstanceSaveData
        {
            public string baseItemId; // Reference to the ScriptableObject's name/ID
            public string instanceId; // Unique ID for this specific instance
            public List<string> appliedAffixIds; // References to AffixData ScriptableObject's name/ID
            public string itemType; // "Weapon" or "Equipment"
        }

        [Serializable]
        public class WeaponInstanceSaveData : ItemInstanceSaveData
        {
            // Add weapon-specific properties if any need to be saved beyond base item
            public WeaponInstanceSaveData() { itemType = "Weapon"; }
        }

        [Serializable]
        public class EquipmentInstanceSaveData : ItemInstanceSaveData
        {
            public string equipmentType; // EquipmentType enum name as string
            public EquipmentInstanceSaveData() { itemType = "Equipment"; }
        }

        [Serializable]
        public class CardSaveData
        {
            public string cardId; // Reference to the CardData ScriptableObject's name/ID
            // Card upgrade level is managed by CardManager's _playerCollectedCards
            // If cards had mutable runtime properties not covered by CardData SO, they'd go here.
        }
    }

    private void Awake()
    {
        saveFilePath = Path.Combine(Application.persistentDataPath, "roguelike_save.json");
        CheckDependencies();
    }

    private void CheckDependencies()
    {
        if (progressionManager == null) Debug.LogError("ProgressionManager is not assigned to SaveManager.", this);
        if (playerStats == null) Debug.LogError("PlayerStats is not assigned to SaveManager.", this);
        if (itemManager == null) Debug.LogError("ItemManager is not assigned to SaveManager.", this);
        if (cardManager == null) Debug.LogError("CardManager is not assigned to SaveManager.", this);
        if (roomGenerator == null) Debug.LogError("RoomGenerator is not assigned to SaveManager.", this);
    }

    /// <summary>
    /// Captures the current game state and serializes it to a file.
    /// </summary>
    public void SaveGame()
    {
        if (playerStats == null || itemManager == null || cardManager == null || progressionManager == null)
        {
            Debug.LogError("Cannot save game: One or more dependencies are null.", this);
            return;
        }

        SaveData saveData = new SaveData();

        // Player State
        saveData.currentHealth = playerStats.GetCurrentHealth();
        saveData.maxHealth = playerStats.GetStatValue(StatType.Health); // Get current calculated max health
        saveData.currentSceneName = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name;

        // Player Position (Assuming player has a Transform)
        GameObject playerGameObject = playerStats.gameObject;
        saveData.playerPositionX = playerGameObject.transform.position.x;
        saveData.playerPositionY = playerGameObject.transform.position.y;

        // Progression State
        saveData.currentGameState = progressionManager.GetCurrentGameState();
        saveData.currentRoomIndex = progressionManager.GetCurrentRoomIndex();
        saveData.currentRunRoomSequence = new List<string>(progressionManager.GetCurrentRunRoomSequence());

        // Inventory and Equipment
        saveData.inventory = itemManager.GetInventory().Select(ToItemInstanceSaveData).ToList();
        if (itemManager.GetEquippedWeaponInstance() != null)
        {
            saveData.equippedWeapon = ToWeaponInstanceSaveData(itemManager.GetEquippedWeaponInstance());
        }
        else
        {
            saveData.equippedWeapon = null;
        }

        saveData.equippedEquipment = new List<SaveData.EquipmentInstanceSaveData>();
        foreach (EquipmentType type in Enum.GetValues(typeof(EquipmentType)))
        {
            var equippedEq = itemManager.GetEquippedEquipmentInstance(type);
            if (equippedEq != null)
            {
                saveData.equippedEquipment.Add(ToEquipmentInstanceSaveData(equippedEq));
            }
        }

        // Card Deck and Hand
        saveData.activeDeck = cardManager.GetActiveDeck().Select(ToCardSaveData).ToList();
        saveData.activeHand = cardManager.GetActiveHand().Select(ToCardSaveData).ToList();

        try
        {
            string json = JsonUtility.ToJson(saveData, true); // Pretty print for readability
            File.WriteAllText(saveFilePath, json);
            Debug.Log($"Game saved successfully to: {saveFilePath}");
        }
        catch (Exception e)
        {
            Debug.LogError($"Failed to save game: {e.Message}", this);
        }
    }

    /// <summary>
    /// Deserializes game data from a file and applies it to the relevant game systems,
    /// restoring the player's run to a previously saved state.
    /// </summary>
    public void LoadGame()
    {
        if (!File.Exists(saveFilePath))
        {
            Debug.LogWarning("No save file found to load.", this);
            return;
        }

        if (playerStats == null || itemManager == null || cardManager == null || progressionManager == null || roomGenerator == null)
        {
            Debug.LogError("Cannot load game: One or more dependencies are null.", this);
            return;
        }

        try
        {
            string json = File.ReadAllText(saveFilePath);
            SaveData saveData = JsonUtility.FromJson<SaveData>(json);

            // Set game state and load scene first
            progressionManager.SetGameState(saveData.currentGameState);
            // This assumes the scene is already loaded or will be loaded externally (e.g., MainMenu loads GameScene)
            // If the scene needs to be loaded by SaveManager:
            // UnityEngine.SceneManagement.SceneManager.LoadScene(saveData.currentSceneName);
            // And then handle application of loaded data in OnSceneLoaded or similar.
            // For this implementation, we assume the game scene (GameScene) is already loaded.

            // Player State
            playerStats.SetCurrentHealth(saveData.currentHealth); // Assuming a public setter for current health
            playerStats.Heal(0); // Trigger health bar update

            // Player Position (Apply after scene and room are loaded)
            // This is usually handled by the scene loading process, e.g., Player object spawns at last saved position
            // For now, we store it for potential use by PlayerController/LevelManager
            // PlayerController would need to read this position and apply it.

            // Progression State
            progressionManager.SetCurrentRoomIndex(saveData.currentRoomIndex); // Assuming a public setter
            progressionManager.SetCurrentRunRoomSequence(saveData.currentRunRoomSequence); // Assuming a public setter
            roomGenerator.LoadRoom(saveData.currentRunRoomSequence[saveData.currentRoomIndex]); // Load the specific room content

            // Inventory and Equipment (Clear existing and re-equip)
            // This is a simplified approach. A robust system might track item instance IDs.
            itemManager.ClearAllItemsAndEquipment(); // Assuming this method exists and clears everything
            foreach (var itemSaveData in saveData.inventory)
            {
                ItemManager.ItemData baseItem = LoadBaseItemData(itemSaveData.baseItemId, itemSaveData.itemType);
                if (baseItem != null)
                {
                    List<AffixData> affixes = itemSaveData.appliedAffixIds.Select(LoadAffixData).Where(a => a != null).ToList();
                    ItemManager.ItemInstance itemInstance = CreateItemInstance(baseItem, affixes, itemSaveData.itemType);
                    if (itemInstance != null)
                    {
                        itemManager.AddItemToInventoryOnly(itemInstance); // Assumes method to add without generating new affixes
                    }
                }
            }

            if (saveData.equippedWeapon != null)
            {
                ItemManager.WeaponData baseWeapon = LoadBaseItemData(saveData.equippedWeapon.baseItemId, saveData.equippedWeapon.itemType) as ItemManager.WeaponData;
                if (baseWeapon != null)
                {
                    List<AffixData> affixes = saveData.equippedWeapon.appliedAffixIds.Select(LoadAffixData).Where(a => a != null).ToList();
                    ItemManager.WeaponInstance weaponInstance = new ItemManager.WeaponInstance(baseWeapon, affixes);
                    itemManager.EquipItem(weaponInstance); // This will handle setting weapon in WeaponManager too
                }
            }

            foreach (var eqSaveData in saveData.equippedEquipment)
            {
                ItemManager.EquipmentData baseEq = LoadBaseItemData(eqSaveData.baseItemId, eqSaveData.itemType) as ItemManager.EquipmentData;
                if (baseEq != null)
                {
                    List<AffixData> affixes = eqSaveData.appliedAffixIds.Select(LoadAffixData).Where(a => a != null).ToList();
                    ItemManager.EquipmentInstance equipmentInstance = new ItemManager.EquipmentInstance(baseEq, affixes);
                    itemManager.EquipItem(equipmentInstance);
                }
            }

            // Card Deck and Hand
            List<CardData> loadedDeck = saveData.activeDeck.Select(c => LoadCardData(c.cardId)).Where(c => c != null).ToList();
            cardManager.SetActiveDeck(loadedDeck); // This will also repopulate the hand

            // After all data is loaded and applied, handle player position
            GameObject player = playerStats.gameObject;
            if (player != null)
            {
                player.transform.position = new Vector2(saveData.playerPositionX, saveData.playerPositionY);
                Debug.Log($"Player position loaded to: {player.transform.position}");
            }
            else
            {
                Debug.LogWarning("Player GameObject not found to set position after loading save.");
            }

            Debug.Log("Game loaded successfully.");
        }
        catch (Exception e)
        {
            Debug.LogError($"Failed to load game: {e.Message}", this);
            ClearSaveGame(); // Consider clearing corrupted save
        }
    }

    /// <summary>
    /// Checks if a save file exists.
    /// </summary>
    /// <returns>True if a save file exists, false otherwise.</returns>
    public bool HasSaveGame()
    {
        return File.Exists(saveFilePath);
    }

    /// <summary>
    /// Deletes the existing save file.
    /// </summary>
    public void ClearSaveGame()
    {
        if (File.Exists(saveFilePath))
        {
            try
            {
                File.Delete(saveFilePath);
                Debug.Log("Save file deleted successfully.");
            }
            catch (Exception e)
            {
                Debug.LogError($"Failed to delete save file: {e.Message}", this);
            }
        }
    }

    /// <summary>
    /// Converts an ItemManager.ItemInstance to a serializable ItemInstanceSaveData.
    /// </summary>
    private SaveData.ItemInstanceSaveData ToItemInstanceSaveData(ItemManager.ItemInstance itemInstance)
    {
        if (itemInstance == null) return null;

        var saveData = new SaveData.ItemInstanceSaveData
        {
            baseItemId = itemInstance.BaseItemData.name, // Using name as ID for ScriptableObjects
            instanceId = itemInstance.InstanceId,
            appliedAffixIds = itemInstance.AppliedAffixes.Select(affix => affix.name).ToList()
        };

        if (itemInstance is ItemManager.WeaponInstance)
        {
            saveData.itemType = "Weapon";
        }
        else if (itemInstance is ItemManager.EquipmentInstance)
        {
            saveData.itemType = "Equipment";
        }
        else
        {
            Debug.LogError($"Unsupported ItemInstance type during save: {itemInstance.GetType().Name}");
            return null;
        }
        return saveData;
    }

    /// <summary>
    /// Converts an ItemManager.WeaponInstance to a serializable WeaponInstanceSaveData.
    /// </summary>
    private SaveData.WeaponInstanceSaveData ToWeaponInstanceSaveData(ItemManager.WeaponInstance weaponInstance)
    {
        if (weaponInstance == null) return null;

        return new SaveData.WeaponInstanceSaveData
        {
            baseItemId = weaponInstance.WeaponData.name,
            instanceId = weaponInstance.InstanceId,
            appliedAffixIds = weaponInstance.AppliedAffixes.Select(affix => affix.name).ToList()
        };
    }

    /// <summary>
    /// Converts an ItemManager.EquipmentInstance to a serializable EquipmentInstanceSaveData.
    /// </summary>
    private SaveData.EquipmentInstanceSaveData ToEquipmentInstanceSaveData(ItemManager.EquipmentInstance equipmentInstance)
    {
        if (equipmentInstance == null) return null;

        return new SaveData.EquipmentInstanceSaveData
        {
            baseItemId = equipmentInstance.EquipmentData.name,
            instanceId = equipmentInstance.InstanceId,
            appliedAffixIds = equipmentInstance.AppliedAffixes.Select(affix => affix.name).ToList(),
            equipmentType = equipmentInstance.EquipmentData.EquipmentType.ToString()
        };
    }

    /// <summary>
    /// Converts a CardData to a serializable CardSaveData.
    /// </summary>
    private SaveData.CardSaveData ToCardSaveData(CardData card)
    {
        if (card == null) return null;
        return new SaveData.CardSaveData { cardId = card.name }; // Using name as ID for ScriptableObjects
    }

    /// <summary>
    /// Loads a base ItemData ScriptableObject by its ID (name).
    /// This assumes all ItemData ScriptableObjects are loadable via Resources.Load or a similar asset loading system.
    /// </summary>
    private ItemManager.ItemData LoadBaseItemData(string itemId, string itemType)
    {
        if (string.IsNullOrEmpty(itemId)) return null;

        string path = "";
        if (itemType == "Weapon")
        {
            path = $"Items/Weapons/{itemId}"; // Example path in Resources folder
        }
        else if (itemType == "Equipment")
        {
            path = $"Items/Equipment/{itemId}"; // Example path in Resources folder
        }
        else
        {
            Debug.LogError($"Unknown item type '{itemType}' when loading base item data: {itemId}", this);
            return null;
        }

        ItemManager.ItemData itemData = Resources.Load<ItemManager.ItemData>(path);
        if (itemData == null)
        {
            Debug.LogError($"Failed to load ItemData with ID '{itemId}' from path '{path}'. Ensure it's in a Resources folder and its name matches the ID.", this);
        }
        return itemData;
    }

    /// <summary>
    /// Loads an AffixData ScriptableObject by its ID (name).
    /// Assumes all AffixData ScriptableObjects are loadable via Resources.Load.
    /// </summary>
    private AffixData LoadAffixData(string affixId)
    {
        if (string.IsNullOrEmpty(affixId)) return null;
        string path = $"Affixes/{affixId}"; // Example path in Resources folder
        AffixData affixData = Resources.Load<AffixData>(path);
        if (affixData == null)
        {
            Debug.LogError($"Failed to load AffixData with ID '{affixId}' from path '{path}'.", this);
        }
        return affixData;
    }

    /// <summary>
    /// Loads a CardData ScriptableObject by its ID (name).
    /// Assumes all CardData ScriptableObjects are loadable via Resources.Load.
    /// </summary>
    private CardData LoadCardData(string cardId)
    {
        if (string.IsNullOrEmpty(cardId)) return null;
        string path = $"Cards/{cardId}"; // Example path in Resources folder
        CardData cardData = Resources.Load<CardData>(path);
        if (cardData == null)
        {
            Debug.LogError($"Failed to load CardData with ID '{cardId}' from path '{path}'.", this);
        }
        return cardData;
    }

    /// <summary>
    /// Creates an ItemInstance (or subclass) from base ItemData and a list of AffixData.
    /// </summary>
    private ItemManager.ItemInstance CreateItemInstance(ItemManager.ItemData baseItem, List<AffixData> affixes, string itemType)
    {
        if (baseItem == null) return null;

        if (itemType == "Weapon" && baseItem is ItemManager.WeaponData weaponData)
        {
            return new ItemManager.WeaponInstance(weaponData, affixes);
        }
        else if (itemType == "Equipment" && baseItem is ItemManager.EquipmentData equipmentData)
        {
            return new ItemManager.EquipmentInstance(equipmentData, affixes);
        }
        else
        {
            Debug.LogError($"Cannot create item instance for type '{itemType}' with base item '{baseItem.name}'. Mismatch or unsupported type.", this);
            return null;
        }
    }
}