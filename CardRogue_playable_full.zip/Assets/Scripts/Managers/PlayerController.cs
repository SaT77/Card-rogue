// Required Packages:
// - com.unity.inputsystem

using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections.Generic;

public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float baseMoveSpeed = 5f;
    private Rigidbody2D rb;
    private Vector2 currentMovementInput;
    private float currentMoveSpeed;

    [Header("References")]
    [SerializeField] private CombatSystem combatSystem;
    [SerializeField] private CardManager cardManager;
    [SerializeField] private PlayerStats playerStats;
    [SerializeField] private PlayerAnimationController playerAnimationController; // Assuming this exists for animation
    [SerializeField] private ActionFluxGenerator actionFluxGenerator; // To inform about skillful actions

    // Input Actions
    private PlayerInput playerInput;
    private InputAction moveAction;
    private InputAction attackAction;
    private InputAction dodgeAction;
    private InputAction parryAction;
    private InputAction cardSwapLeftAction;
    private InputAction cardSwapRightAction;
    private InputAction activateCardAction;

    // Internal state
    private bool isDodging = false;
    private bool isParrying = false;

    private const float DodgeDuration = 0.3f; // Example duration for dodge
    private const float ParryDuration = 0.2f; // Example duration for parry

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        if (rb == null)
        {
            Debug.LogError("PlayerController requires a Rigidbody2D component.", this);
            enabled = false;
            return;
        }

        if (combatSystem == null) Debug.LogError("CombatSystem not assigned to PlayerController.", this);
        if (cardManager == null) Debug.LogError("CardManager not assigned to PlayerController.", this);
        if (playerStats == null) Debug.LogError("PlayerStats not assigned to PlayerController.", this);
        if (playerAnimationController == null) Debug.LogWarning("PlayerAnimationController not assigned to PlayerController. Animations will not play.", this);
        if (actionFluxGenerator == null) Debug.LogError("ActionFluxGenerator not assigned to PlayerController.", this);

        InitializeInput();
        currentMoveSpeed = baseMoveSpeed; // Initialize with base speed
    }

    private void OnEnable()
    {
        playerInput.Enable();
        playerStats.OnStatChanged += HandleStatChanged;

        // Subscribe to input actions
        moveAction.performed += ctx => currentMovementInput = ctx.ReadValue<Vector2>();
        moveAction.canceled += ctx => currentMovementInput = Vector2.zero;

        attackAction.performed += ctx => Attack();
        dodgeAction.performed += ctx => Dodge();
        parryAction.performed += ctx => Parry();
        cardSwapLeftAction.performed += ctx => cardManager.TacticalCardSwap(-1); // Swap left
        cardSwapRightAction.performed += ctx => cardManager.TacticalCardSwap(1); // Swap right
        activateCardAction.performed += ctx => cardManager.ActivateCurrentlySelectedCard();
    }

    private void OnDisable()
    {
        playerInput.Disable();
        if (playerStats != null) // Check for null in case script is destroyed before event unsubscription
        {
            playerStats.OnStatChanged -= HandleStatChanged;
        }

        // Unsubscribe from input actions
        moveAction.performed -= ctx => currentMovementInput = ctx.ReadValue<Vector2>();
        moveAction.canceled -= ctx => currentMovementInput = Vector2.zero;

        attackAction.performed -= ctx => Attack();
        dodgeAction.performed -= ctx => Dodge();
        parryAction.performed -= ctx => Parry();
        cardSwapLeftAction.performed -= ctx => cardManager.TacticalCardSwap(-1);
        cardSwapRightAction.performed -= ctx => cardManager.TacticalCardSwap(1);
        activateCardAction.performed -= ctx => cardManager.ActivateCurrentlySelectedCard();
    }

    private void InitializeInput()
    {
        playerInput = new PlayerInput(); // Assumes PlayerInput asset is generated

        // Get actions from the asset's default action map or a specific one if designed
        moveAction = playerInput.Player.Move;
        attackAction = playerInput.Player.Attack;
        dodgeAction = playerInput.Player.Dodge;
        parryAction = playerInput.Player.Parry;
        cardSwapLeftAction = playerInput.Player.CardSwapLeft;
        cardSwapRightAction = playerInput.Player.CardSwapRight;
        activateCardAction = playerInput.Player.ActivateCard;

        // Ensure actions are enabled
        moveAction.Enable();
        attackAction.Enable();
        dodgeAction.Enable();
        parryAction.Enable();
        cardSwapLeftAction.Enable();
        cardSwapRightAction.Enable();
        activateCardAction.Enable();
    }

    private void Update()
    {
        // Handle touch and gamepad input through the Unity Input System's event-driven approach
        // The currentMovementInput is updated directly by the `moveAction` callbacks.
    }

    private void FixedUpdate()
    {
        if (!isDodging && !isParrying) // Prevent movement during dodge/parry animation
        {
            Move(currentMovementInput);
        }
    }

    /// <summary>
    /// Handles player movement based on input direction.
    /// </summary>
    /// <param name="direction">Normalized input vector for movement.</param>
    public void Move(Vector2 direction)
    {
        if (direction.magnitude > 0.1f) // Apply movement only if there's significant input
        {
            Vector2 movement = direction.normalized * currentMoveSpeed * Time.fixedDeltaTime;
            rb.MovePosition(rb.position + movement);
            playerAnimationController?.SetMoveState(true, direction.x); // Assuming X for facing direction
        }
        else
        {
            playerAnimationController?.SetMoveState(false, 0);
        }
    }

    /// <summary>
    /// Initiates a player attack.
    /// </summary>
    public void Attack()
    {
        if (combatSystem == null) return;

        // Assuming playerAnimationController triggers an animation event for actual hit
        playerAnimationController?.TriggerAttack();
        combatSystem.OnPlayerAttack(new PlayerAttackEventData(gameObject, playerStats.GetStatValue(StatType.AttackDamage))); // Pass base damage from player stats
        Debug.Log("Player performs Attack!");
    }

    /// <summary>
    /// Initiates a player dodge.
    /// </summary>
    public void Dodge()
    {
        if (isDodging || combatSystem == null) return;

        isDodging = true;
        playerAnimationController?.TriggerDodge();
        // Grant temporary invulnerability
        combatSystem.SetPlayerInvulnerable(true, DodgeDuration);
        actionFluxGenerator?.OnSuccessfulDodge(gameObject); // Inform flux generator

        Debug.Log("Player performs Dodge!");
        Invoke(nameof(EndDodge), DodgeDuration);
    }

    private void EndDodge()
    {
        isDodging = false;
        Debug.Log("Player Dodge ended.");
    }

    /// <summary>
    /// Initiates a player parry.
    /// </summary>
    public void Parry()
    {
        if (isParrying || combatSystem == null) return;

        isParrying = true;
        playerAnimationController?.TriggerParry();
        // Activate parry window in combat system
        combatSystem.EnableParryWindow(ParryDuration);
        // ActionFluxGenerator will be notified by CombatSystem if parry is successful

        Debug.Log("Player performs Parry!");
        Invoke(nameof(EndParry), ParryDuration);
    }

    private void EndParry()
    {
        isParrying = false;
        Debug.Log("Player Parry ended.");
    }

    /// <summary>
    /// Callback for when a player stat changes.
    /// </summary>
    /// <param name="statType">The type of stat that changed.</param>
    /// <param name="newValue">The new value of the stat.</param>
    private void HandleStatChanged(StatType statType, float newValue)
    {
        if (statType == StatType.MovementSpeed)
        {
            currentMoveSpeed = newValue;
            Debug.Log($"Player movement speed updated to: {currentMoveSpeed}");
        }
    }
}

// PlayerInput class (partially generated, full version would be larger)
// This structure assumes Unity's new Input System generated an asset and a C# class for it.
public class PlayerInput : IInputActionCollection2, IDisposable
{
    public InputActionAsset asset { get; }
    public PlayerActions Player { get; }

    public PlayerInput()
    {
        asset = ScriptableObject.CreateInstance<InputActionAsset>();
        var playerActionMap = asset.AddActionMap("Player");

        Player = new PlayerActions(playerActionMap);

        // Example bindings - actual bindings would come from a .inputactions asset
        // and its generated code. This is a minimal example for compilation.
        Player.Move = playerActionMap.AddAction("Move", bindingGroup: "Keyboard&Mouse", type: InputActionType.Value, expectedControlType: "Vector2");
        Player.Move.AddBinding("<Gamepad>/leftStick");
        Player.Move.AddBinding("<Keyboard>/wasd");
        Player.Move.AddBinding("<Keyboard>/upArrow").WithParameter("stickX", "0").WithParameter("stickY", "1");
        Player.Move.AddBinding("<Keyboard>/downArrow").WithParameter("stickX", "0").WithParameter("stickY", "-1");
        Player.Move.AddBinding("<Keyboard>/leftArrow").WithParameter("stickX", "-1").WithParameter("stickY", "0");
        Player.Move.AddBinding("<Keyboard>/rightArrow").WithParameter("stickX", "1").WithParameter("stickY", "0");

        Player.Attack = playerActionMap.AddAction("Attack", bindingGroup: "Keyboard&Mouse", type: InputActionType.Button);
        Player.Attack.AddBinding("<Mouse>/leftButton");
        Player.Attack.AddBinding("<Gamepad>/rightTrigger");

        Player.Dodge = playerActionMap.AddAction("Dodge", bindingGroup: "Keyboard&Mouse", type: InputActionType.Button);
        Player.Dodge.AddBinding("<Keyboard>/space");
        Player.Dodge.AddBinding("<Gamepad>/leftShoulder");

        Player.Parry = playerActionMap.AddAction("Parry", bindingGroup: "Keyboard&Mouse", type: InputActionType.Button);
        Player.Parry.AddBinding("<Keyboard>/e");
        Player.Parry.AddBinding("<Gamepad>/rightShoulder");

        Player.CardSwapLeft = playerActionMap.AddAction("CardSwapLeft", bindingGroup: "Keyboard&Mouse", type: InputActionType.Button);
        Player.CardSwapLeft.AddBinding("<Keyboard>/q");
        Player.CardSwapLeft.AddBinding("<Gamepad>/dpad/left");

        Player.CardSwapRight = playerActionMap.AddAction("CardSwapRight", bindingGroup: "Keyboard&Mouse", type: InputActionType.Button);
        Player.CardSwapRight.AddBinding("<Keyboard>/r");
        Player.CardSwapRight.AddBinding("<Gamepad>/dpad/right");

        Player.ActivateCard = playerActionMap.AddAction("ActivateCard", bindingGroup: "Keyboard&Mouse", type: InputActionType.Button);
        Player.ActivateCard.AddBinding("<Keyboard>/f");
        Player.ActivateCard.AddBinding("<Gamepad>/buttonNorth"); // Example for a gamepad face button

        // For a real project, this asset would be loaded from a file or created in editor.
        // This manual creation is just to satisfy compilation requirements for this single script.
    }

    public void Dispose()
    {
        asset.Dispose();
    }

    public InputBinding? bindingMask
    {
        get => asset.bindingMask;
        set => asset.bindingMask = value;
    }

    public ReadOnlyArray<InputDevice>? devices
    {
        get => asset.devices;
        set => asset.devices = value;
    }

    public ReadOnlyArray<InputControlScheme> controlSchemes => asset.controlSchemes;

    public bool Contains(InputAction action)
    {
        return asset.Contains(action);
    }

    public IEnumerator<InputAction> GetEnumerator()
    {
        return asset.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }

    public void Enable()
    {
        asset.Enable();
    }

    public void Disable()
    {
        asset.Disable();
    }

    public IEnumerable<InputBinding> bindings => asset.bindings;

    public class PlayerActions : IInputActionCollection2, IDisposable
    {
        public InputActionAsset asset { get; }
        public PlayerActions(InputActionMap map)
        {
            asset = map.asset;
        }

        public InputAction Move { get; set; }
        public InputAction Attack { get; set; }
        public InputAction Dodge { get; set; }
        public InputAction Parry { get; set; }
        public InputAction CardSwapLeft { get; set; }
        public InputAction CardSwapRight { get; set; }
        public InputAction ActivateCard { get; set; }

        public void Dispose()
        {
            // No need to dispose actions individually as they are part of the map.
        }

        public InputBinding? bindingMask
        {
            get => asset.bindingMask;
            set => asset.bindingMask = value;
        }

        public ReadOnlyArray<InputDevice>? devices
        {
            get => asset.devices;
            set => asset.devices = value;
        }

        public ReadOnlyArray<InputControlScheme> controlSchemes => asset.controlSchemes;

        public bool Contains(InputAction action)
        {
            return asset.Contains(action);
        }

        public IEnumerator<InputAction> GetEnumerator()
        {
            return asset.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public void Enable()
        {
            foreach (var action in this.GetAllActions())
            {
                action.Enable();
            }
        }

        public void Disable()
        {
            foreach (var action in this.GetAllActions())
            {
                action.Disable();
            }
        }

        private IEnumerable<InputAction> GetAllActions()
        {
            if (Move != null) yield return Move;
            if (Attack != null) yield return Attack;
            if (Dodge != null) yield return Dodge;
            if (Parry != null) yield return Parry;
            if (CardSwapLeft != null) yield return CardSwapLeft;
            if (CardSwapRight != null) yield return CardSwapRight;
            if (ActivateCard != null) yield return ActivateCard;
        }
    }
}