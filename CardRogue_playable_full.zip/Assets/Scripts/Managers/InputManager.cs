// Required Packages:
// - com.unity.inputsystem

using UnityEngine;
using UnityEngine.InputSystem;
using System;
using System.Linq;
using System.Collections.Generic;

/// <summary>
/// Provides a unified interface for handling all player input, abstracting away the specifics
/// of touch controls vs. gamepad input. It allows for customizable key bindings and sensitivity.
/// Directly communicates input events to PlayerController through C# events.
/// </summary>
public class InputManager : MonoBehaviour
{
    // C# Events for input actions that PlayerController can subscribe to.
    public static event Action<Vector2> OnMoveInput;
    public static event Action OnAttackPressed;
    public static event Action OnDodgePressed;
    public static event Action OnParryPressed;
    public static event Action OnCardSwapLeftPressed;
    public static event Action OnCardSwapRightPressed;
    public static event Action OnActivateCardPressed;

    private PlayerInput playerInputActions; // Reference to the generated Input System asset C# class

    /// <summary>
    /// Enumeration for different types of input. Can be expanded if more granular sensitivity adjustments are needed.
    /// </summary>
    public enum InputType
    {
        Movement,
        Camera, // If camera movement was part of input
        UI,
        Generic
    }

    /// <summary>
    /// Awake is called when the script instance is being loaded.
    /// Initializes the Unity Input System actions.
    /// </summary>
    private void Awake()
    {
        InitializeInputSystem();
    }

    /// <summary>
    /// OnEnable is called when the object becomes enabled and active.
    /// Subscribes to input action events and enables the action map.
    /// </summary>
    private void OnEnable()
    {
        if (playerInputActions == null)
        {
            Debug.LogError("PlayerInputActions were not initialized in Awake. Input will not function.", this);
            return;
        }

        // Subscribe to input action events and emit custom C# events.
        playerInputActions.Player.Move.performed += ctx => OnMoveInput?.Invoke(ctx.ReadValue<Vector2>());
        playerInputActions.Player.Move.canceled += ctx => OnMoveInput?.Invoke(Vector2.zero); // Ensure movement stops on release

        playerInputActions.Player.Attack.performed += ctx => OnAttackPressed?.Invoke();
        playerInputActions.Player.Dodge.performed += ctx => OnDodgePressed?.Invoke();
        playerInputActions.Player.Parry.performed += ctx => OnParryPressed?.Invoke();
        playerInputActions.Player.CardSwapLeft.performed += ctx => OnCardSwapLeftPressed?.Invoke();
        playerInputActions.Player.CardSwapRight.performed += ctx => OnCardSwapRightPressed?.Invoke();
        playerInputActions.Player.ActivateCard.performed += ctx => OnActivateCardPressed?.Invoke();

        // Enable the action map
        playerInputActions.Enable();
    }

    /// <summary>
    /// OnDisable is called when the behaviour becomes disabled or inactive.
    /// Unsubscribes from input action events and disables the action map to prevent memory leaks.
    /// </summary>
    private void OnDisable()
    {
        if (playerInputActions == null) return;

        // Unsubscribe from input action events
        playerInputActions.Player.Move.performed -= ctx => OnMoveInput?.Invoke(ctx.ReadValue<Vector2>());
        playerInputActions.Player.Move.canceled -= ctx => OnMoveInput?.Invoke(Vector2.zero);

        playerInputActions.Player.Attack.performed -= ctx => OnAttackPressed?.Invoke();
        playerInputActions.Player.Dodge.performed -= ctx => OnDodgePressed?.Invoke();
        playerInputActions.Player.Parry.performed -= ctx => OnParryPressed?.Invoke();
        playerInputActions.Player.CardSwapLeft.performed -= ctx => OnCardSwapLeftPressed?.Invoke();
        playerInputActions.Player.CardSwapRight.performed -= ctx => OnCardSwapRightPressed?.Invoke();
        playerInputActions.Player.ActivateCard.performed -= ctx => OnActivateCardPressed?.Invoke();

        // Disable the action map
        playerInputActions.Disable();
    }

    /// <summary>
    /// Initializes the Unity Input System actions. This creates an instance of the
    /// generated PlayerInput class from the .inputactions asset.
    /// </summary>
    public void InitializeInputSystem()
    {
        if (playerInputActions == null)
        {
            try
            {
                playerInputActions = new PlayerInput();
                Debug.Log("InputManager: PlayerInput actions initialized successfully.");
            }
            catch (Exception ex)
            {
                Debug.LogError($"InputManager: Failed to initialize PlayerInput actions. Ensure 'PlayerInput' class is correctly generated from an .inputactions asset. Error: {ex.Message}", this);
            }
        }
    }

    /// <summary>
    /// Rebinds a specific input action to a new binding path.
    /// This allows for runtime control customization.
    /// </summary>
    /// <param name="actionName">The name of the action to rebind (e.g., "Player/Move").</param>
    /// <param name="newBindingPath">The new binding path (e.g., "<Keyboard>/w").</param>
    public void RebindAction(string actionName, string newBindingPath)
    {
        if (playerInputActions == null)
        {
            Debug.LogError("InputManager: PlayerInput actions not initialized. Cannot rebind action.", this);
            return;
        }

        // Find the action by name across all action maps
        InputAction action = playerInputActions.asset.FindAction(actionName);

        if (action != null)
        {
            // Remove existing bindings for the specified action to ensure a clean rebind
            action.RemoveAllBindingOverrides();

            // Add the new binding. Consider handling composite bindings or specific control schemes
            // more robustly if needed. For simplicity, we just add a new binding.
            action.AddBinding(newBindingPath);

            Debug.Log($"InputManager: Rebound action '{actionName}' to '{newBindingPath}'.");
        }
        else
        {
            Debug.LogWarning($"InputManager: Action '{actionName}' not found for rebinding.", this);
        }
    }

    /// <summary>
    /// Adjusts sensitivity for a specific input type. This typically affects how input values
    /// are scaled before being used (e.g., mouse look sensitivity).
    /// Note: The actual application of sensitivity would be in the consumer of the input (e.g., PlayerController),
    /// as Input System actions directly provide raw values. This method stores/configures a setting.
    /// </summary>
    /// <param name="type">The type of input to adjust (e.g., Movement, Camera).</param>
    /// <param name="sensitivity">The new sensitivity value.</param>
    public void AdjustSensitivity(InputType type, float sensitivity)
    {
        if (sensitivity < 0)
        {
            Debug.LogWarning($"InputManager: Sensitivity for {type} cannot be negative. Setting to 0 if provided value is negative.", this);
            sensitivity = Mathf.Max(0, sensitivity);
        }

        // This is a placeholder for how sensitivity might be stored or applied.
        // For example, you might have a dictionary for sensitivities:
        // private Dictionary<InputType, float> sensitivities = new Dictionary<InputType, float>();
        // sensitivities[type] = sensitivity;

        // For the purpose of this implementation, we'll just log it.
        Debug.Log($"InputManager: Adjusted sensitivity for {type} to {sensitivity}.");
        // The actual PlayerController or CameraController would then retrieve this sensitivity
        // from a PlayerPrefs or a configuration service.
    }

    /// <summary>
    /// Determines the currently active control scheme.
    /// </summary>
    /// <returns>The name of the active control scheme (e.g., "Gamepad", "Keyboard&Mouse", "Touch").</returns>
    public string GetActiveControlScheme()
    {
        if (playerInputActions == null || playerInputActions.controlSchemes.Count() == 0)
        {
            return "None";
        }

        // The Input System tracks which device is currently used.
        InputDevice currentDevice = InputSystem.devices.FirstOrDefault(d => d.wasUpdatedThisFrame);
        if (currentDevice != null)
        {
            foreach (var scheme in playerInputActions.controlSchemes)
            {
                if (scheme.SupportsDevice(currentDevice))
                {
                    return scheme.name;
                }
            }
        }
        
        // Fallback or if no device was active in current frame, check last used.
        if (playerInputActions.controlSchemes.Any(s => s.SupportsDevice(Gamepad.current)))
        {
            return "Gamepad";
        }
        if (playerInputActions.controlSchemes.Any(s => s.SupportsDevice(Keyboard.current) || s.SupportsDevice(Mouse.current)))
        {
            return "Keyboard&Mouse";
        }
        if (playerInputActions.controlSchemes.Any(s => s.SupportsDevice(Touchscreen.current)))
        {
            return "Touch";
        }

        return "Unknown";
    }
}