using UnityEngine;
using System;
using System.Collections.Generic;
using System.Linq;

public class ItemManager : MonoBehaviour
{
    // Events for other systems to subscribe to for inventory updates or item equip/unequip
    public static event Action<ItemInstance> OnItemAcquired;
    public static event Action<ItemInstance> OnItemEquipped;
    public static event Action<ItemInstance> OnItemUnequipped;
    public static event Action<List<ItemInstance>> OnInventoryChanged; // Pass the whole inventory for UI refresh

    [Header("Dependencies")]
    [SerializeField] private PlayerStats playerStats;
    [SerializeField] private WeaponManager weaponManager;
    [SerializeField] private PlayerUI playerUI; // To provide inventory data for display

    [Header("Item Data Pools")]
    // ScriptableObjects that contain all possible item/affix definitions
    [SerializeField] private List<WeaponData> allWeaponData;
    [SerializeField] private List<EquipmentData> allEquipmentData;
    [SerializeField] private List<AffixData> allAffixData;

    [Header("Affix Generation Settings")]
    [Tooltip("Minimum number of affixes an item can have.")]
    [SerializeField] private int minAffixesPerItem = 1;
    [Tooltip("Maximum number of affixes an item can have.")]
    [SerializeField] private int maxAffixesPerItem = 5;

    private List<ItemInstance> playerInventory = new List<ItemInstance>();
    private WeaponInstance equippedWeaponInstance;
    private Dictionary<EquipmentType, EquipmentInstance> equippedEquipmentInstances = new Dictionary<EquipmentType, EquipmentInstance>();

    // Private struct to hold an instance of an item with its dynamic affixes.
    // This allows unique combinations for each acquired item.
    [System.Serializable]
    public class ItemInstance
    {
        public ItemData BaseItemData;
        public List<AffixData> AppliedAffixes;
        public string InstanceId; // Unique identifier for this specific instance

        public ItemInstance(ItemData baseItemData, List<AffixData> appliedAffixes)
        {
            BaseItemData = baseItemData;
            AppliedAffixes = appliedAffixes ?? new List<AffixData>();
            InstanceId = Guid.NewGuid().ToString(); // Generate a unique ID for this instance
        }
    }

    // Specific instance types for clarity and potential future extension
    [System.Serializable]
    public class WeaponInstance : ItemInstance
    {
        public WeaponData WeaponData => BaseItemData as WeaponData;
        public WeaponInstance(WeaponData baseWeaponData, List<AffixData> appliedAffixes)
            : base(baseWeaponData, appliedAffixes) { }
    }

    [System.Serializable]
    public class EquipmentInstance : ItemInstance
    {
        public EquipmentData EquipmentData => BaseItemData as EquipmentData;
        public EquipmentInstance(EquipmentData baseEquipmentData, List<AffixData> appliedAffixes)
            : base(baseEquipmentData, appliedAffixes) { }
    }


    private void Awake()
    {
        InitializeEquipmentSlots();
        CheckDependencies();
    }

    /// <summary>
    /// Initializes the equipped equipment slots dictionary with all possible equipment types.
    /// </summary>
    private void InitializeEquipmentSlots()
    {
        foreach (EquipmentType type in Enum.GetValues(typeof(EquipmentType)))
        {
            equippedEquipmentInstances[type] = null; // Initialize all slots as empty
        }
    }

    /// <summary>
    /// Checks if all necessary dependencies are assigned in the inspector.
    /// </summary>
    private void CheckDependencies()
    {
        if (playerStats == null) Debug.LogError("PlayerStats is not assigned in ItemManager!", this);
        if (weaponManager == null) Debug.LogError("WeaponManager is not assigned in ItemManager!", this);
        if (playerUI == null) Debug.LogError("PlayerUI is not assigned in ItemManager!", this);

        if (allWeaponData == null || allWeaponData.Count == 0) Debug.LogWarning("No WeaponData assets assigned to ItemManager's 'allWeaponData'. Cannot generate weapons.", this);
        if (allEquipmentData == null || allEquipmentData.Count == 0) Debug.LogWarning("No EquipmentData assets assigned to ItemManager's 'allEquipmentData'. Cannot generate equipment.", this);
        if (allAffixData == null || allAffixData.Count == 0) Debug.LogWarning("No AffixData assets assigned to ItemManager's 'allAffixData'. Items will have no affixes.", this);
    }

    /// <summary>
    /// Adds an item instance to the player's inventory.
    /// </summary>
    /// <param name="item">The ItemData object to add. An instance will be created with random affixes.</param>
    public void AddItem(ItemData item)
    {
        if (item == null)
        {
            Debug.LogError("Attempted to add a null ItemData to inventory.", this);
            return;
        }

        ItemInstance newItemInstance;
        List<AffixData> generatedAffixes = GenerateRandomAffixes();

        if (item is WeaponData weaponData)
        {
            newItemInstance = new WeaponInstance(weaponData, generatedAffixes);
        }
        else if (item is EquipmentData equipmentData)
        {
            newItemInstance = new EquipmentInstance(equipmentData, generatedAffixes);
        }
        else
        {
            Debug.LogError($"Attempted to add an unsupported ItemData type: {item.GetType().Name}. Only WeaponData and EquipmentData are supported.", this);
            return;
        }

        playerInventory.Add(newItemInstance);
        Debug.Log($"Added {newItemInstance.BaseItemData.ItemName} with {newItemInstance.AppliedAffixes.Count} affixes to inventory. Instance ID: {newItemInstance.InstanceId}");

        OnItemAcquired?.Invoke(newItemInstance);
        OnInventoryChanged?.Invoke(playerInventory); // Notify UI
    }

    /// <summary>
    /// Equips an item from the player's inventory or a newly acquired item.
    /// Handles unequipping existing items in the same slot.
    /// </summary>
    /// <param name="itemToEquip">The ItemInstance to equip. Must be an item the player possesses or is newly acquired.</param>
    public void EquipItem(ItemInstance itemToEquip)
    {
        if (itemToEquip == null)
        {
            Debug.LogError("Attempted to equip a null item instance.", this);
            return;
        }

        // Remove from inventory if it's there (assuming equipping removes it, or it was just acquired)
        // If it's already in inventory, it will be moved from inventory to equipped slot.
        // If it's not in inventory (e.g., direct drop from enemy), it's just equipped.
        bool wasInInventory = playerInventory.Remove(itemToEquip);

        // Handle Weapons
        if (itemToEquip is WeaponInstance newWeaponInstance)
        {
            if (equippedWeaponInstance != null)
            {
                UnequipItem(equippedWeaponInstance); // Unequip current weapon
            }

            equippedWeaponInstance = newWeaponInstance;
            weaponManager.EquipWeapon(newWeaponInstance.WeaponData); // Notify WeaponManager about the new base weapon

            // Apply base weapon effects and its affixes
            ApplyItemEffects(newWeaponInstance, playerStats.gameObject);
            Debug.Log($"Equipped weapon: {newWeaponInstance.BaseItemData.ItemName}.");
        }
        // Handle Equipment
        else if (itemToEquip is EquipmentInstance newEquipmentInstance)
        {
            EquipmentType slotType = newEquipmentInstance.EquipmentData.EquipmentType;
            if (equippedEquipmentInstances.TryGetValue(slotType, out EquipmentInstance currentEquipment) && currentEquipment != null)
            {
                UnequipItem(currentEquipment); // Unequip current equipment in that slot
            }

            equippedEquipmentInstances[slotType] = newEquipmentInstance;

            // Apply base equipment effects and its affixes
            ApplyItemEffects(newEquipmentInstance, playerStats.gameObject);
            Debug.Log($"Equipped {slotType}: {newEquipmentInstance.BaseItemData.ItemName}.");
        }
        else
        {
            Debug.LogError($"Unsupported ItemInstance type for equipping: {itemToEquip.GetType().Name}.", this);
            if (wasInInventory) playerInventory.Add(itemToEquip); // Add it back if it was in inventory
            return;
        }

        OnItemEquipped?.Invoke(itemToEquip);
        OnInventoryChanged?.Invoke(playerInventory); // Notify UI about inventory change
    }

    /// <summary>
    /// Unequips an item instance. Removes its effects and adds it back to inventory.
    /// </summary>
    /// <param name="itemToUnequip">The ItemInstance to unequip.</param>
    public void UnequipItem(ItemInstance itemToUnequip)
    {
        if (itemToUnequip == null)
        {
            Debug.LogError("Attempted to unequip a null item instance.", this);
            return;
        }

        // Remove base item effects and its affixes
        RemoveItemEffects(itemToUnequip, playerStats.gameObject);

        // Handle Weapons
        if (itemToUnequip is WeaponInstance weaponInstance && equippedWeaponInstance == weaponInstance)
        {
            equippedWeaponInstance = null;
            weaponManager.EquipWeapon(null); // Notify WeaponManager that no weapon is equipped
            Debug.Log($"Unequipped weapon: {weaponInstance.BaseItemData.ItemName}.");
        }
        // Handle Equipment
        else if (itemToUnequip is EquipmentInstance equipmentInstance && equippedEquipmentInstances.ContainsValue(equipmentInstance))
        {
            EquipmentType slotType = equipmentInstance.EquipmentData.EquipmentType;
            if (equippedEquipmentInstances.ContainsKey(slotType) && equippedEquipmentInstances[slotType] == equipmentInstance)
            {
                equippedEquipmentInstances[slotType] = null;
                Debug.Log($"Unequipped {slotType}: {equipmentInstance.BaseItemData.ItemName}.");
            }
        }
        else
        {
            Debug.LogWarning($"Attempted to unequip an item that was not currently equipped or of an unknown type: {itemToUnequip.BaseItemData.ItemName}.", this);
            return;
        }

        // Add back to inventory (if inventory space allows, or handle overflow)
        playerInventory.Add(itemToUnequip);
        OnItemUnequipped?.Invoke(itemToUnequip);
        OnInventoryChanged?.Invoke(playerInventory); // Notify UI about inventory change
    }

    /// <summary>
    /// Gets the current player inventory as a list of ItemInstances.
    /// </summary>
    /// <returns>A list of ItemInstance objects in the player's inventory.</returns>
    public List<ItemInstance> GetInventory()
    {
        return new List<ItemInstance>(playerInventory); // Return a copy to prevent external modification
    }

    /// <summary>
    /// Gets the currently equipped weapon instance.
    /// </summary>
    /// <returns>The equipped WeaponInstance, or null if none is equipped.</returns>
    public WeaponInstance GetEquippedWeaponInstance()
    {
        return equippedWeaponInstance;
    }

    /// <summary>
    /// Gets the currently equipped equipment instance for a specific slot.
    /// </summary>
    /// <param name="type">The type of equipment slot.</param>
    /// <returns>The equipped EquipmentInstance for the slot, or null if none is equipped.</returns>
    public EquipmentInstance GetEquippedEquipmentInstance(EquipmentType type)
    {
        if (equippedEquipmentInstances.TryGetValue(type, out EquipmentInstance instance))
        {
            return instance;
        }
        return null;
    }

    /// <summary>
    /// Applies the effects of an item (base stats and affixes) to a target GameObject.
    /// Typically, the target will be the player's GameObject, affecting PlayerStats.
    /// </summary>
    /// <param name="itemInstance">The item instance whose effects are to be applied.</param>
    /// <param name="target">The GameObject to which the effects are applied.</param>
    public void ApplyItemEffects(ItemInstance itemInstance, GameObject target)
    {
        if (itemInstance == null || target == null) return;

        // Apply base item effects (e.g., from WeaponData or EquipmentData)
        // These are often stat changes, but can be special abilities.
        // Assuming ItemData has an ApplyEffects method or similar.
        // For stat changes, it would call PlayerStats.AddModifier.
        if (playerStats != null)
        {
            // Apply effects from the base item data
            foreach (var effect in itemInstance.BaseItemData.Effects)
            {
                if (effect is StatChangeEffect statEffect)
                {
                    playerStats.AddModifier(statEffect.StatType, statEffect.Value, statEffect.ModifierType, itemInstance);
                    Debug.Log($"Applied base item effect: {itemInstance.BaseItemData.ItemName} -> {statEffect.StatType} {statEffect.Value} {statEffect.ModifierType}");
                }
                // Handle other effect types as needed (e.g., unique abilities)
            }

            // Apply affix effects
            foreach (AffixData affix in itemInstance.AppliedAffixes)
            {
                if (affix == null) continue;
                foreach (var effect in affix.Effects)
                {
                    if (effect is StatChangeEffect statEffect)
                    {
                        playerStats.AddModifier(statEffect.StatType, statEffect.Value, statEffect.ModifierType, itemInstance); // Source is the item instance
                        Debug.Log($"Applied affix effect: {affix.AffixName} -> {statEffect.StatType} {statEffect.Value} {statEffect.ModifierType}");
                    }
                    // Handle other effect types from affixes (e.g., elemental damage bonus, special proc)
                    // These might directly interact with CombatSystem or other managers.
                    else if (effect is CombatEffect combatEffect)
                    {
                        // CombatSystem.RegisterCombatEffect or similar
                        Debug.LogWarning($"CombatEffect from affix {affix.AffixName} needs explicit handling by CombatSystem: {combatEffect.GetType().Name}");
                    }
                }
            }
        }
    }

    /// <summary>
    /// Removes the effects of an item (base stats and affixes) from a target GameObject.
    /// Typically, the target will be the player's GameObject, affecting PlayerStats.
    /// </summary>
    /// <param name="itemInstance">The item instance whose effects are to be removed.</param>
    /// <param name="target">The GameObject from which the effects are removed.</param>
    private void RemoveItemEffects(ItemInstance itemInstance, GameObject target)
    {
        if (itemInstance == null || target == null) return;

        if (playerStats != null)
        {
            // Remove effects from the base item data
            foreach (var effect in itemInstance.BaseItemData.Effects)
            {
                if (effect is StatChangeEffect statEffect)
                {
                    playerStats.RemoveModifier(statEffect.StatType, itemInstance); // Source is the item instance
                }
            }

            // Remove affix effects
            foreach (AffixData affix in itemInstance.AppliedAffixes)
            {
                if (affix == null) continue;
                foreach (var effect in affix.Effects)
                {
                    if (effect is StatChangeEffect statEffect)
                    {
                        playerStats.RemoveModifier(statEffect.StatType, itemInstance); // Source is the item instance
                    }
                }
            }
        }
    }

    /// <summary>
    /// Generates a random ItemInstance based on the specified item type.
    /// Affixes are randomized upon generation.
    /// </summary>
    /// <param name="type">The type of item to generate (Weapon or Equipment).</param>
    /// <returns>A new ItemInstance with randomized affixes, or null if no data is available for the type.</returns>
    public ItemInstance GenerateRandomItem(ItemType type)
    {
        ItemData baseItem = null;

        if (type == ItemType.Weapon && allWeaponData.Count > 0)
        {
            baseItem = allWeaponData[UnityEngine.Random.Range(0, allWeaponData.Count)];
        }
        else if (type == ItemType.Equipment && allEquipmentData.Count > 0)
        {
            baseItem = allEquipmentData[UnityEngine.Random.Range(0, allEquipmentData.Count)];
        }
        else
        {
            Debug.LogWarning($"Cannot generate random item of type {type}: No data available or unsupported type.", this);
            return null;
        }

        if (baseItem == null)
        {
            Debug.LogError($"Failed to select a base item for type {type}. Check your data pools.", this);
            return null;
        }

        List<AffixData> generatedAffixes = GenerateRandomAffixes();

        if (baseItem is WeaponData weaponData)
        {
            return new WeaponInstance(weaponData, generatedAffixes);
        }
        else if (baseItem is EquipmentData equipmentData)
        {
            return new EquipmentInstance(equipmentData, generatedAffixes);
        }
        else
        {
            Debug.LogError($"Generated base item is of an unexpected type: {baseItem.GetType().Name}. Expected WeaponData or EquipmentData.", this);
            return null;
        }
    }

    /// <summary>
    /// Generates a list of random affixes for an item based on settings.
    /// </summary>
    /// <returns>A list of randomly selected AffixData objects.</returns>
    private List<AffixData> GenerateRandomAffixes()
    {
        List<AffixData> affixes = new List<AffixData>();
        if (allAffixData == null || allAffixData.Count == 0)
        {
            Debug.LogWarning("No AffixData available to generate affixes.", this);
            return affixes;
        }

        int numAffixes = UnityEngine.Random.Range(minAffixesPerItem, maxAffixesPerItem + 1);

        // Ensure unique affixes for an item instance
        HashSet<AffixData> uniqueAffixes = new HashSet<AffixData>();
        for (int i = 0; i < numAffixes; i++)
        {
            AffixData randomAffix = allAffixData[UnityEngine.Random.Range(0, allAffixData.Count)];
            if (!uniqueAffixes.Contains(randomAffix))
            {
                uniqueAffixes.Add(randomAffix);
            }
            else
            {
                // If we picked a duplicate, try again or just move on if we hit too many tries.
                // For simplicity, this loop will just try until it fills up to `numAffixes` with unique ones,
                // or runs out of unique options.
                if (uniqueAffixes.Count == allAffixData.Count) // If all possible unique affixes have been added
                {
                    break;
                }
                i--; // Decrement i to try picking another affix
            }
        }
        affixes.AddRange(uniqueAffixes);
        return affixes;
    }

    // --- ScriptableObject Definitions (Simplified for this example) ---
    // In a full project, these would be separate files, but for the sake of
    // self-contained code submission, they are included here.

    public enum ItemType { Weapon, Equipment, Card } // Card is managed by CardManager, not ItemManager directly
    public enum EquipmentType { Head, Torso, Legs, Feet, Ring, Amulet }
    public enum StatType { Health, AttackDamage, Defense, MovementSpeed, CooldownReduction, CriticalChance, CriticalDamage, ActionFluxGeneration, MaxHealth }
    public enum ModifierType { Flat, PercentageAdd, Multiplier }
    public enum ComboAbilityType { None, Shockwave, RapidFire, ShadowDash } // Example combo abilities

    /// <summary>
    /// Base class for all Item ScriptableObjects.
    /// </summary>
    public abstract class ItemData : ScriptableObject
    {
        public string ItemName;
        [TextArea] public string Description;
        public Sprite Icon;
        public List<BaseEffect> Effects = new List<BaseEffect>(); // Base effects of the item itself
    }

    /// <summary>
    /// ScriptableObject for defining weapons.
    /// </summary>
    [CreateAssetMenu(fileName = "NewWeapon", menuName = "Game Data/Item/Weapon")]
    public class WeaponData : ItemData
    {
        public float BaseDamage;
        public float AttackSpeed;
        public WeaponType WeaponType; // e.g., Sword, Bow, Staff

        // Internal list to store temporary card-based modifiers
        private List<AffixData> _cardModifiers = new List<AffixData>();

        // Provides access to combined affixes (base item effects + card modifiers)
        // This is primarily for the CombatSystem to query the effective stats/effects of the weapon.
        public IEnumerable<BaseEffect> GetCombinedEffects()
        {
            foreach (var effect in Effects) yield return effect;
            foreach (var modifier in _cardModifiers)
            {
                foreach (var effect in modifier.Effects) yield return effect;
            }
        }

        public void AddCardModifier(AffixData affix)
        {
            if (affix != null && !_cardModifiers.Contains(affix))
            {
                _cardModifiers.Add(affix);
            }
        }

        public void ClearCardModifiers()
        {
            _cardModifiers.Clear();
        }
    }

    public enum WeaponType { None, Sword, Axe, Bow, Dagger, Staff }

    /// <summary>
    /// ScriptableObject for defining equipment.
    /// </summary>
    [CreateAssetMenu(fileName = "NewEquipment", menuName = "Game Data/Item/Equipment")]
    public class EquipmentData : ItemData
    {
        public EquipmentType EquipmentType;
        public int DefenseRating;
    }

    /// <summary>
    /// ScriptableObject for defining affixes.
    /// </summary>
    [CreateAssetMenu(fileName = "NewAffix", menuName = "Game Data/Item/Affix")]
    public class AffixData : ScriptableObject
    {
        public string AffixName;
        [TextArea] public string Description;
        public List<BaseEffect> Effects = new List<BaseEffect>(); // Effects granted by this affix
    }


    // --- Effect Definitions (These would also be separate ScriptableObjects typically) ---

    /// <summary>
    /// Base class for all effects that can be applied by items or cards.
    /// </summary>
    public abstract class BaseEffect : ScriptableObject
    {
        public string EffectName;
    }

    /// <summary>
    /// An effect that modifies a player statistic.
    /// </summary>
    [CreateAssetMenu(fileName = "NewStatChangeEffect", menuName = "Game Data/Effect/Stat Change")]
    public class StatChangeEffect : BaseEffect
    {
        public StatType StatType;
        public float Value;
        public ModifierType ModifierType;
    }

    /// <summary>
    /// An effect that triggers a combat-related action (e.g., apply a debuff, deal elemental damage).
    /// </summary>
    [CreateAssetMenu(fileName = "NewCombatEffect", menuName = "Game Data/Effect/Combat")]
    public class CombatEffect : BaseEffect
    {
        // Define properties relevant to combat effects
        public float DamageModifier;
        public DamageType DamageType; // e.g., Fire, Ice, Poison
        // Could also include StatusEffectData to apply status effects
    }

    public enum DamageType { Physical, Fire, Ice, Lightning, Poison, Arcane }


    // Interface for anything that has stats and can take damage.
    public interface IHasStats
    {
        GameObject GameObject { get; } // Reference to the GameObject this component is attached to
        float GetStatValue(StatType statType);
        void TakeDamage(float amount, GameObject source);
    }

    // Dummy class for CardData, as it's used by WeaponManager
    public class CardData : ScriptableObject, IWeaponModifierProvider
    {
        public string CardName;
        public Sprite Icon;
        public int FluxCost;
        public CardRarity Rarity;

        // An optional affix that this card can grant to weapons directly.
        public AffixData WeaponAffixToGrant;

        // Other effects of the card, handled by CardManager or CombatSystem
        public List<BaseEffect> Effects;

        // Implement IWeaponModifierProvider
        public List<AffixData> GetWeaponAffixes()
        {
            List<AffixData> affixes = new List<AffixData>();
            if (WeaponAffixToGrant != null)
            {
                affixes.Add(WeaponAffixToGrant);
            }
            // If card effects themselves can dynamically generate affixes, add that logic here.
            // For example, if a card's "Effect" is actually a specific affix to be applied.
            foreach (var effect in Effects)
            {
                if (effect is AffixEffect affixEffect) // Assuming an AffixEffect type exists
                {
                    affixes.Add(affixEffect.AffixToGrant);
                }
            }
            return affixes;
        }
    }

    // Example of an effect that specifically grants an AffixData
    [CreateAssetMenu(fileName = "NewAffixEffect", menuName = "Game Data/Effect/Affix Grant")]
    public class AffixEffect : BaseEffect
    {
        public AffixData AffixToGrant;
    }

    public enum CardRarity { Common, Uncommon, Rare, Epic, Legendary }
}