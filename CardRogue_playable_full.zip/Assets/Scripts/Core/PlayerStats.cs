using UnityEngine;
using System;
using System.Collections.Generic;
using System.Linq;

public class PlayerStats : MonoBehaviour, IHasStats
{
    // Events for other systems to subscribe to for UI updates or logic
    public static event Action<float, float> OnHealthChanged; // currentHealth, maxHealth
    public static event Action<StatType, float> OnStatChanged; // statType, newValue

    [Header("Base Player Stats")]
    [SerializeField] private float baseMaxHealth = 100f;
    [SerializeField] private float baseAttackDamage = 10f;
    [SerializeField] private float baseDefense = 0f;
    [SerializeField] private float baseMovementSpeed = 5f;
    [SerializeField] private float baseCooldownReduction = 0f;
    [SerializeField] private float baseCriticalChance = 0.05f; // 5% base crit chance
    [SerializeField] private float baseCriticalDamage = 1.5f; // 150% base crit damage multiplier
    [SerializeField] private float baseActionFluxGeneration = 1f; // 100% base flux generation rate

    private float currentHealth;
    private Dictionary<StatType, float> initialBaseStats; // Stores the truly immutable base values
    private Dictionary<StatType, List<StatModifier>> activeModifiers;

    // GameObject property for IDamageable interface
    public GameObject GameObject => gameObject;


    private void Awake()
    {
        InitializeBaseStats();
        currentHealth = initialBaseStats[StatType.Health]; // Set current health to initial max health

        activeModifiers = new Dictionary<StatType, List<StatModifier>>();
        foreach (StatType type in Enum.GetValues(typeof(StatType)))
        {
            activeModifiers[type] = new List<StatModifier>();
        }
    }

    private void OnEnable()
    {
        // Initial UI update for health
        OnHealthChanged?.Invoke(currentHealth, GetStatValue(StatType.Health));
        // Initial UI update for all stats (optional, for systems that listen on enable)
        foreach (StatType type in Enum.GetValues(typeof(StatType)))
        {
            OnStatChanged?.Invoke(type, GetStatValue(type));
        }
    }

    private void OnDisable()
    {
        // Clean up any lingering coroutines if necessary (though current implementation doesn't use them directly)
    }

    /// <summary>
    /// Initializes the dictionary of immutable base statistics.
    /// </summary>
    private void InitializeBaseStats()
    {
        initialBaseStats = new Dictionary<StatType, float>
        {
            { StatType.Health, baseMaxHealth }, // Max health is considered a base stat
            { StatType.AttackDamage, baseAttackDamage },
            { StatType.Defense, baseDefense },
            { StatType.MovementSpeed, baseMovementSpeed },
            { StatType.CooldownReduction, baseCooldownReduction },
            { StatType.CriticalChance, baseCriticalChance },
            { StatType.CriticalDamage, baseCriticalDamage },
            { StatType.ActionFluxGeneration, baseActionFluxGeneration }
        };
    }

    /// <summary>
    /// Calculates and returns the final effective value of a given statistic,
    /// taking into account all base values and active modifiers.
    /// </summary>
    /// <param name="statType">The type of statistic to retrieve.</param>
    /// <returns>The calculated effective value of the statistic.</returns>
    public float GetStatValue(StatType statType)
    {
        if (!initialBaseStats.TryGetValue(statType, out float baseValue))
        {
            Debug.LogError($"Attempted to get stat value for unknown StatType: {statType}. Returning 0.", this);
            return 0f;
        }

        float finalValue = baseValue;
        if (!activeModifiers.TryGetValue(statType, out List<StatModifier> modifiers))
        {
            // This should not happen if activeModifiers is initialized for all StatTypes
            Debug.LogWarning($"No modifier list found for StatType: {statType}. Returning base value.", this);
            return baseValue;
        }

        // Apply Flat modifiers first
        foreach (var mod in modifiers.Where(m => m.Type == ModifierType.Flat))
        {
            finalValue += mod.Value;
        }

        // Apply Percentage Add modifiers (e.g., +20% Movement Speed)
        // These add up to a single total percentage which is then applied.
        float percentageAdditiveBonus = 0f;
        foreach (var mod in modifiers.Where(m => m.Type == ModifierType.PercentageAdd))
        {
            percentageAdditiveBonus += mod.Value;
        }
        finalValue *= (1 + percentageAdditiveBonus); // Apply after flat, before multiplicative

        // Apply Multiplier modifiers
        foreach (var mod in modifiers.Where(m => m.Type == ModifierType.Multiplier))
        {
            finalValue *= mod.Value;
        }

        // Ensure certain stats don't go below zero if that's a game design constraint
        if (statType == StatType.AttackDamage || statType == StatType.Defense || statType == StatType.MovementSpeed)
        {
            finalValue = Mathf.Max(0, finalValue);
        }
        // Critical Chance is a percentage, usually capped at 1 (100%)
        if (statType == StatType.CriticalChance)
        {
            finalValue = Mathf.Min(1f, finalValue);
        }

        return finalValue;
    }

    /// <summary>
    /// Adds a stat modifier to the player. The modifier affects the calculated value of a stat.
    /// </summary>
    /// <param name="statType">The type of stat to modify.</param>
    /// <param name="value">The value of the modifier (e.g., +5 for flat, 0.2 for 20% multiplier).</param>
    /// <param name="type">The type of modification (Flat, Multiplier, PercentageAdd).</param>
    /// <param name="source">The object that applied the modifier, used for removal.</param>
    public void AddModifier(StatType statType, float value, ModifierType type, object source)
    {
        if (!activeModifiers.ContainsKey(statType))
        {
            Debug.LogError($"Cannot add modifier: StatType {statType} is not registered for modifiers. Initializing it now.", this);
            activeModifiers[statType] = new List<StatModifier>();
        }

        var modifier = new StatModifier { Value = value, Type = type, Source = source };
        activeModifiers[statType].Add(modifier);

        // Notify subscribers that a stat value might have changed
        OnStatChanged?.Invoke(statType, GetStatValue(statType));
        Debug.Log($"Added {type} modifier {value} to {statType} from {source?.GetType().Name ?? "Unknown"}. New {statType}: {GetStatValue(statType)}");
    }

    /// <summary>
    /// Removes stat modifiers previously applied by a specific source.
    /// </summary>
    /// <param name="statType">The type of stat from which to remove modifiers. If null, removes from all stats.</param>
    /// <param name="source">The object that applied the modifiers to be removed.</param>
    public void RemoveModifier(StatType statType, object source)
    {
        if (source == null)
        {
            Debug.LogWarning("Attempted to remove modifier with a null source. This may lead to unintended removals.", this);
            return;
        }

        bool changed = false;
        if (activeModifiers.TryGetValue(statType, out var modifiers))
        {
            int removedCount = modifiers.RemoveAll(m => m.Source == source);
            if (removedCount > 0)
            {
                changed = true;
                Debug.Log($"Removed {removedCount} modifiers of type {statType} from source {source.GetType().Name}.");
            }
        }
        else
        {
            Debug.LogWarning($"No modifier list found for StatType: {statType} when attempting to remove.", this);
        }

        if (changed)
        {
            OnStatChanged?.Invoke(statType, GetStatValue(statType));
        }
    }

    /// <summary>
    /// Reduces the player's current health.
    /// </summary>
    /// <param name="amount">The amount of damage to take.</param>
    /// <param name="source">The GameObject that inflicted the damage (required by IDamageable interface).</param>
    public void TakeDamage(float amount, GameObject source)
    {
        if (amount <= 0) return;

        currentHealth -= amount;
        currentHealth = Mathf.Max(0, currentHealth); // Health cannot go below zero

        OnHealthChanged?.Invoke(currentHealth, GetStatValue(StatType.Health));
        Debug.Log($"Player took {amount} damage from {source.name}. Current Health: {currentHealth}/{GetStatValue(StatType.Health)}");

        if (currentHealth <= 0)
        {
            Debug.Log("Player has died!");
            // Trigger game over logic here (e.g., via ProgressionManager or a GameState manager)
        }
    }

    /// <summary>
    /// Increases the player's current health.
    /// </summary>
    /// <param name="amount">The amount of health to restore.</param>
    public void Heal(float amount)
    {
        if (amount <= 0) return;

        currentHealth += amount;
        currentHealth = Mathf.Min(currentHealth, GetStatValue(StatType.Health)); // Cap at maximum health

        OnHealthChanged?.Invoke(currentHealth, GetStatValue(StatType.Health));
        Debug.Log($"Player healed for {amount}. Current Health: {currentHealth}/{GetStatValue(StatType.Health)}");
    }

    /// <summary>
    /// Event handler for when a card is activated. Can be used to apply temporary stat changes directly.
    /// Note: `CombatSystem.ApplyEffect` is the primary way card effects are applied.
    /// This method is mostly for compliance with the specified main_functions, but its direct use might be redundant.
    /// </summary>
    /// <param name="effect">The CardEffect that was activated.</param>
    public void OnCardActivated(CardEffect effect)
    {
        // CombatSystem.ApplyEffect is responsible for taking the CardEffect and applying it
        // to a target (which would often be this PlayerStats component's GameObject).
        // This method, as specified, would be a redundant layer if CombatSystem is handling it.
        // However, if there are direct stat changes from CardManager that bypass CombatSystem,
        // they would be handled here. For now, we'll log it as the CombatSystem pathway is preferred.
        // Example: If a card directly changed player's movement speed for 5 seconds without CombatSystem's intervention.
        if (effect is StatChangeEffect statEffect)
        {
            // In the current setup, CombatSystem already calls AddModifier on IHasStats.
            // If we called it here too, it would be double application.
            // So, this is merely an acknowledgment, or if CardManager had a direct way
            // to apply effects to PlayerStats without CombatSystem.
            Debug.Log($"PlayerStats: OnCardActivated received StatChangeEffect {statEffect.name}. " +
                      $"Assuming CombatSystem handles direct application to PlayerStats component.");
        }
        else
        {
            Debug.Log($"PlayerStats: OnCardActivated received {effect.GetType().Name}. No direct stat change logic implemented here.");
        }
    }

    /// <summary>
    /// Represents a modification to a player statistic.
    /// </summary>
    private class StatModifier
    {
        public float Value;
        public ModifierType Type;
        public object Source; // The object that applied the modifier (e.g., an ItemData, CardEffect instance)
    }
}