using UnityEngine;
using System;

public class ActionFluxGenerator : MonoBehaviour
{
    // Event to notify listeners (e.g., PlayerUI, CardManager) about flux changes
    public static event Action<int> OnFluxChanged;

    [Header("Current Flux")]
    [Tooltip("The current amount of Action Flux the player possesses.")]
    [SerializeField] private int currentFlux = 0;
    [Tooltip("The maximum amount of Action Flux the player can hold.")]
    [SerializeField] private int maxFlux = 100;

    [Header("Flux Generation Amounts")]
    [Tooltip("Amount of flux generated for a critical hit.")]
    [SerializeField] private int criticalHitFlux = 10;
    [Tooltip("Amount of flux generated for a successful dodge.")]
    [SerializeField] private int successfulDodgeFlux = 5;
    [Tooltip("Amount of flux generated for a successful parry.")]
    [SerializeField] private int successfulParryFlux = 15;

    // A reference to the CombatSystem, set in the Inspector.
    // This allows ActionFluxGenerator to subscribe to CombatSystem's events.
    [Header("Dependencies")]
    [Tooltip("Reference to the CombatSystem for subscribing to combat events.")]
    [SerializeField] private CombatSystem combatSystem;

    private void Awake()
    {
        // Validate dependencies
        if (combatSystem == null)
        {
            Debug.LogError("ActionFluxGenerator: CombatSystem reference is not set in the Inspector.", this);
        }

        // Initialize UI with current flux amount
        OnFluxChanged?.Invoke(currentFlux);
    }

    private void OnEnable()
    {
        // Subscribe to relevant events from CombatSystem
        if (combatSystem != null)
        {
            CombatSystem.OnDamageDealt += OnCriticalHit; // Handles critical hits from player
            CombatSystem.OnSuccessfulParry += OnSuccessfulParry;
        }
        else
        {
            Debug.LogWarning("ActionFluxGenerator: Cannot subscribe to CombatSystem events. CombatSystem reference is null.");
        }
        // Note: OnSuccessfulDodge is called directly by PlayerController, not via a global event, as per game description.
    }

    private void OnDisable()
    {
        // Unsubscribe from events to prevent memory leaks and errors when object is destroyed or disabled
        if (combatSystem != null)
        {
            CombatSystem.OnDamageDealt -= OnCriticalHit;
            CombatSystem.OnSuccessfulParry -= OnSuccessfulParry;
        }
    }

    /// <summary>
    /// Handles the CombatSystem.OnDamageDealt event to check for critical hits from the player.
    /// This method is designed to be a subscriber to the OnDamageDealt event.
    /// </summary>
    /// <param name="source">The GameObject that dealt the damage.</param>
    /// <param name="amount">The total damage amount dealt.</param>
    /// <param name="isCritical">True if the damage was a critical hit.</param>
    private void OnCriticalHit(GameObject source, float amount, bool isCritical)
    {
        // Only generate flux if the critical hit came from the player.
        // Assuming the player GameObject has the tag "Player".
        if (isCritical && source != null && source.CompareTag("Player"))
        {
            AddFlux(criticalHitFlux);
        }
    }

    /// <summary>
    /// Handles the CombatSystem.OnSuccessfulParry event to generate flux for a successful parry.
    /// This method is designed to be a subscriber to the OnSuccessfulParry event.
    /// </summary>
    /// <param name="player">The player GameObject that performed the parry.</param>
    public void OnSuccessfulParry(GameObject player)
    {
        // Ensure it's the player who successfully parried.
        if (player != null && player.CompareTag("Player"))
        {
            AddFlux(successfulParryFlux);
        }
    }

    /// <summary>
    /// Called by PlayerController when a player performs a successful dodge.
    /// This is a direct method call, not an event subscription.
    /// </summary>
    /// <param name="player">The player GameObject that performed the dodge.</param>
    public void OnSuccessfulDodge(GameObject player)
    {
        // Ensure it's the player who successfully dodged.
        if (player != null && player.CompareTag("Player"))
        {
            AddFlux(successfulDodgeFlux);
        }
    }

    /// <summary>
    /// Adds a specified amount of flux to the current flux pool.
    /// The flux amount is clamped by the maximum flux value.
    /// </summary>
    /// <param name="amount">The integer amount of flux to add. Must be non-negative.</param>
    public void AddFlux(int amount)
    {
        if (amount < 0)
        {
            Debug.LogWarning($"ActionFluxGenerator: Attempted to add negative flux ({amount}). Use ConsumeFlux instead.", this);
            return;
        }

        int previousFlux = currentFlux;
        currentFlux = Mathf.Min(maxFlux, currentFlux + amount);

        // Only invoke event if flux actually changed
        if (currentFlux != previousFlux)
        {
            Debug.Log($"ActionFluxGenerator: Added {amount} flux. Current Flux: {currentFlux}/{maxFlux}.");
            OnFluxChanged?.Invoke(currentFlux);
        }
        else if (amount > 0) // If tried to add but was already at max
        {
            Debug.Log($"ActionFluxGenerator: Tried to add {amount} flux, but already at max ({maxFlux}).");
        }
    }

    /// <summary>
    /// Attempts to consume a specified amount of flux from the current flux pool.
    /// </summary>
    /// <param name="amount">The integer amount of flux to consume. Must be non-negative.</param>
    /// <returns>True if the flux was successfully consumed, false if there was not enough flux.</returns>
    public bool ConsumeFlux(int amount)
    {
        if (amount < 0)
        {
            Debug.LogWarning($"ActionFluxGenerator: Attempted to consume negative flux ({amount}).", this);
            return false;
        }

        if (currentFlux >= amount)
        {
            int previousFlux = currentFlux;
            currentFlux -= amount;
            currentFlux = Mathf.Max(0, currentFlux); // Ensure flux doesn't go below zero

            if (currentFlux != previousFlux)
            {
                Debug.Log($"ActionFluxGenerator: Consumed {amount} flux. Current Flux: {currentFlux}/{maxFlux}.");
                OnFluxChanged?.Invoke(currentFlux);
            }
            return true;
        }
        else
        {
            Debug.Log($"ActionFluxGenerator: Not enough flux to consume {amount}. Current: {currentFlux}. Required: {amount}.");
            return false;
        }
    }

    /// <summary>
    /// Gets the current amount of Action Flux.
    /// </summary>
    /// <returns>The current integer value of Action Flux.</returns>
    public int GetCurrentFlux()
    {
        return currentFlux;
    }

    /// <summary>
    /// Gets the maximum amount of Action Flux that can be held.
    /// </summary>
    /// <returns>The maximum integer value of Action Flux.</returns>
    public int GetMaxFlux()
    {
        return maxFlux;
    }
}