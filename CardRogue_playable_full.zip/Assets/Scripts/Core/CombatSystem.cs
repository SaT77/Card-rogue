using UnityEngine;
using System.Collections.Generic;
using System;
using System.Collections;
using System.Linq;

public class CombatSystem : MonoBehaviour
{
    [Header("Dependencies")]
    [SerializeField] private WeaponManager weaponManager;
    [SerializeField] private PlayerStats playerStats;
    [SerializeField] private ActionFluxGenerator actionFluxGenerator;

    // Events
    public static event Action<GameObject, float, bool> OnDamageDealt; // Source, amount, isCritical
    public static event Action<GameObject, float> OnHealReceived; // Target, amount
    public static event Action<GameObject> OnSuccessfulParry; // Source of parry (player)

    private bool playerInvulnerable = false;
    private Coroutine invulnerabilityCoroutine;
    private bool parryWindowActive = false;
    private Coroutine parryWindowCoroutine;
    private GameObject currentParryAttacker = null; // Store who hit during parry window

    private const string PlayerTag = "Player";
    private const string EnemyTag = "Enemy";

    private void Awake()
    {
        if (weaponManager == null) Debug.LogError("WeaponManager not assigned to CombatSystem.", this);
        if (playerStats == null) Debug.LogError("PlayerStats not assigned to CombatSystem.", this);
        if (actionFluxGenerator == null) Debug.LogError("ActionFluxGenerator not assigned to CombatSystem.", this);
    }

    private void OnEnable()
    {
        // Subscribe to player attack events from PlayerController (indirectly, if PlayerController raises a global event or via a specific interface)
        // For simplicity, assuming PlayerController directly calls OnPlayerAttack for now or a global event system.
        // If PlayerController uses events like `PlayerAttackEventData`, it implies an event bus.
        // Since PlayerController directly calls `combatSystem.OnPlayerAttack(...)`, this subscription might not be needed
        // unless there's an intermediate event system. Let's assume a direct call for now.
    }

    private void OnDisable()
    {
        if (invulnerabilityCoroutine != null)
        {
            StopCoroutine(invulnerabilityCoroutine);
            invulnerabilityCoroutine = null;
        }
        if (parryWindowCoroutine != null)
        {
            StopCoroutine(parryWindowCoroutine);
            parryWindowCoroutine = null;
        }
    }

    /// <summary>
    /// Handles the player's attack action. This method is typically called by PlayerController.
    /// </summary>
    /// <param name="eventData">Data about the player's attack, e.g., the player GameObject and base damage.</param>
    public void OnPlayerAttack(PlayerAttackEventData eventData)
    {
        // This method can trigger animations or weapon swing detection, which then lead to DealDamage calls.
        // For now, let's assume this is a signal to prepare for potential hits (e.g., enable a hit collider).
        // Actual damage application will happen when a target enters the attack collider.
        Debug.Log($"Player attack initiated by {eventData.Attacker.name} with base damage: {eventData.BaseDamage}");
        // In a real game, this might activate a hitbox or raycast
    }

    /// <summary>
    /// Handles an enemy being hit by an attack. This is usually called by a hit detection mechanism (e.g., OnTriggerEnter2D).
    /// </summary>
    /// <param name="eventData">Data about the hit, including the target, source, and weapon/affix details.</param>
    public void OnEnemyHit(EnemyHitEventData eventData)
    {
        if (eventData.Target == null)
        {
            Debug.LogWarning("EnemyHitEventData target is null.");
            return;
        }
        if (eventData.Source == null)
        {
            Debug.LogWarning("EnemyHitEventData source is null.");
            return;
        }

        IDamageable damageableTarget = eventData.Target.GetComponent<IDamageable>();
        if (damageableTarget != null)
        {
            DealDamage(damageableTarget, eventData.BaseDamage, eventData.Source, eventData.Weapon, eventData.Affixes);
        }
        else
        {
            Debug.LogWarning($"Hit target {eventData.Target.name} does not implement IDamageable.");
        }
    }

    /// <summary>
    /// Calculates and applies damage to a target.
    /// </summary>
    /// <param name="target">The IDamageable component of the entity taking damage.</param>
    /// <param name="baseDamage">The base damage value from the source (e.g., weapon's base damage).</param>
    /// <param name="source">The GameObject that is dealing the damage (e.g., player, enemy).</param>
    /// <param name="weapon">The WeaponData if the damage is from a weapon, can be null.</param>
    /// <param name="affixes">A list of affixes applying to this damage instance, can be null.</param>
    public void DealDamage(IDamageable target, float baseDamage, GameObject source, WeaponData weapon, List<AffixData> affixes)
    {
        if (target == null || source == null)
        {
            Debug.LogError("DealDamage called with null target or source.");
            return;
        }

        // Handle invulnerability
        if (target.GameObject.CompareTag(PlayerTag) && playerInvulnerable)
        {
            Debug.Log($"Player is invulnerable. Damage blocked from {source.name}.");
            return;
        }

        float totalDamage = baseDamage;
        bool isCritical = false;

        // Apply weapon modifiers (e.g., from deck-bound weapon modifiers)
        if (weapon != null)
        {
            // The weaponManager handles dynamic modifiers, so we just use the weapon data it provides.
            // Damage calculation might happen here, or be part of the `WeaponData` itself based on current modifiers.
            // For simplicity, let's assume weapon.CalculateDamage() considers its current state.
            totalDamage = weapon.CalculateDamage(playerStats.GetStatValue(StatType.AttackDamage)); // Assuming player's attack damage is a base for weapon
        }

        // Apply affix effects to damage
        if (affixes != null)
        {
            foreach (var affix in affixes)
            {
                if (affix == null) continue;

                // Example: Modify damage based on affix type
                foreach (var effect in affix.Effects)
                {
                    if (effect is DamageModifierEffect damageModifier)
                    {
                        totalDamage *= damageModifier.Multiplier;
                        totalDamage += damageModifier.FlatBonus;
                    }
                    if (effect is CriticalHitEffect critEffect)
                    {
                        if (UnityEngine.Random.Range(0f, 1f) < critEffect.Chance)
                        {
                            totalDamage *= critEffect.Multiplier;
                            isCritical = true;
                            Debug.Log($"Critical hit! Damage: {totalDamage}");
                        }
                    }
                    // Add other affix effects that modify damage here
                }
            }
        }

        // Apply target defense (if IDamageable provides defense)
        if (target is IHasStats targetStats)
        {
            float defense = targetStats.GetStatValue(StatType.Defense); // Assuming Defense stat exists
            totalDamage = Mathf.Max(0, totalDamage - defense); // Simple defense reduction
        }

        // Handle Parry: If target is Player and parry window is active
        if (target.GameObject.CompareTag(PlayerTag) && parryWindowActive)
        {
            if (currentParryAttacker == source) // Only parry the specific attacker that triggered the window
            {
                Debug.Log($"Attack from {source.name} parried by Player!");
                // Prevent damage to player
                totalDamage = 0;
                actionFluxGenerator?.OnSuccessfulParry(target.GameObject);
                OnSuccessfulParry?.Invoke(target.GameObject);

                // Potentially stun the attacker or reflect damage
                if (source.TryGetComponent<EnemyAI>(out var enemyAI))
                {
                    enemyAI.Stun(1.0f); // Example: Stun enemy for 1 second
                }
                EndParryWindow(); // End the parry window after a successful parry
            }
        }

        // Actually apply damage
        target.TakeDamage(totalDamage, source);
        Debug.Log($"{source.name} dealt {totalDamage} damage to {target.GameObject.name}. Critical: {isCritical}");

        // Notify subscribers of damage dealt
        OnDamageDealt?.Invoke(source, totalDamage, isCritical);

        // Inform ActionFluxGenerator if it was a critical hit
        if (isCritical)
        {
            actionFluxGenerator?.OnCriticalHit(source, target.GameObject);
        }
    }

    /// <summary>
    /// Processes an entity taking damage directly. This is called by IDamageable implementations.
    /// </summary>
    /// <param name="damage">The amount of damage to take.</param>
    /// <param name="source">The GameObject that dealt the damage.</param>
    public void TakeDamage(float damage, GameObject source)
    {
        // This method is primarily for IDamageable implementations to call into their own stats system.
        // E.g., playerStats.TakeDamage(damage); or enemyStats.TakeDamage(damage);
        // This CombatSystem `TakeDamage` exists as per the main_functions, but its direct use here
        // is somewhat redundant if `DealDamage` handles the core logic and `IDamageable.TakeDamage`
        // is implemented by PlayerStats/EnemyStats.
        // It could be used for environmental damage or debuffs not originating from a "source" with a weapon/affix.
        Debug.LogWarning($"CombatSystem.TakeDamage(float, GameObject) called directly. " +
                         $"Consider using DealDamage(IDamageable, ...) for full combat logic. Damage: {damage} from {source?.name}.");
    }


    /// <summary>
    /// Applies a card effect to a target GameObject.
    /// </summary>
    /// <param name="target">The GameObject to which the effect is applied.</param>
    /// <param name="effect">The CardEffect to apply.</param>
    public void ApplyEffect(GameObject target, CardEffect effect)
    {
        if (target == null || effect == null)
        {
            Debug.LogError("ApplyEffect called with null target or effect.");
            return;
        }

        Debug.Log($"Applying effect '{effect.name}' to {target.name}");

        // Implement different effect types
        if (effect is StatChangeEffect statEffect)
        {
            if (target.TryGetComponent<IHasStats>(out var hasStats))
            {
                hasStats.AddModifier(statEffect.StatType, statEffect.Value, statEffect.ModifierType);
                StartCoroutine(RemoveStatModifierAfterDuration(hasStats, statEffect.StatType, target, statEffect.Duration));
            }
            else
            {
                Debug.LogWarning($"Target {target.name} does not implement IHasStats for StatChangeEffect.");
            }
        }
        else if (effect is DamageEffect damageEffect)
        {
            if (target.TryGetComponent<IDamageable>(out var damageable))
            {
                // Source for card damage can be the player if the card is player-activated
                GameObject source = playerStats != null ? playerStats.gameObject : null;
                DealDamage(damageable, damageEffect.DamageAmount, source, null, null); // No specific weapon/affixes for card damage
            }
            else
            {
                Debug.LogWarning($"Target {target.name} does not implement IDamageable for DamageEffect.");
            }
        }
        else if (effect is HealingEffect healingEffect)
        {
            if (target.TryGetComponent<IHasStats>(out var hasStats))
            {
                hasStats.Heal(healingEffect.HealAmount);
                OnHealReceived?.Invoke(target, healingEffect.HealAmount);
            }
            else
            {
                Debug.LogWarning($"Target {target.name} does not implement IHasStats for HealingEffect.");
            }
        }
        else if (effect is InvulnerabilityEffect invulEffect)
        {
            if (target.CompareTag(PlayerTag)) // Only applies to player for now
            {
                SetPlayerInvulnerable(true, invulEffect.Duration);
            }
            else
            {
                Debug.LogWarning($"InvulnerabilityEffect applied to non-player target {target.name}. Not supported currently.");
            }
        }
        // Add more effect types as defined in CardEffect.cs (e.g., TeleportEffect, StunEffect)
        else if (effect is TeleportEffect teleportEffect)
        {
            if (target.TryGetComponent<Rigidbody2D>(out var rb2d))
            {
                Vector2 targetPos = (Vector2)target.transform.position + teleportEffect.Direction.normalized * teleportEffect.Distance;
                // Add collision check for teleport to prevent teleporting into walls
                RaycastHit2D hit = Physics2D.Raycast(target.transform.position, teleportEffect.Direction, teleportEffect.Distance, teleportEffect.ObstacleLayers);
                if (hit.collider == null)
                {
                    rb2d.position = targetPos;
                    Debug.Log($"Teleported {target.name} to {targetPos}");
                }
                else
                {
                    Debug.Log($"Teleport blocked by obstacle at {hit.point}");
                }

                // If damage on arrival, check for enemies
                if (teleportEffect.DamageOnArrival > 0)
                {
                    Collider2D[] hitColliders = Physics2D.OverlapCircleAll(targetPos, teleportEffect.DamageRadius, teleportEffect.EnemyLayers);
                    foreach (var hitCollider in hitColliders)
                    {
                        if (hitCollider.TryGetComponent<IDamageable>(out var hitDamageable) && hitCollider.gameObject != target)
                        {
                            DealDamage(hitDamageable, teleportEffect.DamageOnArrival, target, null, null);
                        }
                    }
                }
            }
        }
        else if (effect is StunEffect stunEffect)
        {
            if (target.TryGetComponent<EnemyAI>(out var enemyAI))
            {
                enemyAI.Stun(stunEffect.Duration);
            }
            else if (target.CompareTag(PlayerTag))
            {
                // Consider how player stun would be handled (e.g., PlayerController.Stun())
                Debug.LogWarning($"StunEffect applied to player {target.name}. Player stun not yet implemented.");
            }
            else
            {
                Debug.LogWarning($"Target {target.name} does not have a Stun method (EnemyAI).");
            }
        }
        else if (effect is ComboUnlockEffect comboEffect)
        {
            if (target.CompareTag(PlayerTag) && weaponManager != null)
            {
                // This implies WeaponManager needs a way to receive active combo effects
                weaponManager.ActivateComboAbility(comboEffect.ComboAbilityType, comboEffect.Duration);
            }
        }
        else
        {
            Debug.LogWarning($"Attempted to apply unknown card effect type: {effect.GetType().Name}");
        }
    }

    /// <summary>
    /// Grants or removes temporary invulnerability to the player.
    /// </summary>
    /// <param name="isInvulnerable">True to grant invulnerability, false to remove.</param>
    /// <param name="duration">Duration of invulnerability if granting.</param>
    public void SetPlayerInvulnerable(bool isInvulnerable, float duration = 0f)
    {
        if (invulnerabilityCoroutine != null)
        {
            StopCoroutine(invulnerabilityCoroutine);
            invulnerabilityCoroutine = null;
        }

        playerInvulnerable = isInvulnerable;
        if (isInvulnerable && duration > 0)
        {
            invulnerabilityCoroutine = StartCoroutine(InvulnerabilityTimer(duration));
        }
        Debug.Log($"Player invulnerability set to: {playerInvulnerable}");
    }

    private IEnumerator InvulnerabilityTimer(float duration)
    {
        yield return new WaitForSeconds(duration);
        playerInvulnerable = false;
        invulnerabilityCoroutine = null;
        Debug.Log("Player invulnerability ended.");
    }

    /// <summary>
    /// Activates a parry window for the player. If an attack hits the player during this window, it's parried.
    /// </summary>
    /// <param name="duration">The duration of the parry window.</param>
    public void EnableParryWindow(float duration)
    {
        if (parryWindowCoroutine != null)
        {
            StopCoroutine(parryWindowCoroutine);
            parryWindowCoroutine = null;
        }

        parryWindowActive = true;
        currentParryAttacker = null; // Reset attacker for the new parry window
        parryWindowCoroutine = StartCoroutine(ParryWindowTimer(duration));
        Debug.Log($"Parry window enabled for {duration} seconds.");
    }

    private void EndParryWindow()
    {
        if (parryWindowCoroutine != null)
        {
            StopCoroutine(parryWindowCoroutine);
            parryWindowCoroutine = null;
        }
        parryWindowActive = false;
        currentParryAttacker = null;
        Debug.Log("Parry window ended.");
    }

    private IEnumerator ParryWindowTimer(float duration)
    {
        yield return new WaitForSeconds(duration);
        EndParryWindow();
    }

    /// <summary>
    /// Coroutine to remove a temporary stat modifier after its duration.
    /// </summary>
    private IEnumerator RemoveStatModifierAfterDuration(IHasStats targetStats, StatType statType, GameObject targetObject, float duration)
    {
        if (duration <= 0) yield break; // No duration, no need to remove

        yield return new WaitForSeconds(duration);

        // Ensure the target and its IHasStats component still exist
        if (targetObject != null && targetObject.TryGetComponent<IHasStats>(out var currentTargetStats) && currentTargetStats == targetStats)
        {
            // The source for the modifier removal would be the original effect itself or the card.
            // For simplicity, we use the target object as the source for removal.
            targetStats.RemoveModifier(statType, targetObject);
            Debug.Log($"Removed temporary {statType} modifier from {targetObject.name}.");
        }
    }
}

/// <summary>
/// Interface for any entity that can take damage.
/// </summary>
public interface IDamageable
{
    GameObject GameObject { get; }
    void TakeDamage(float damage, GameObject source);
}

/// <summary>
/// Interface for any entity that has stats (e.g., player, enemy).
/// </summary>
public interface IHasStats
{
    float GetStatValue(StatType statType);
    void AddModifier(StatType statType, float value, ModifierType modifierType);
    void RemoveModifier(StatType statType, object source);
    void Heal(float amount);
}

// Dummy classes for dependencies to allow compilation
// In a real project, these would be fully implemented ScriptableObjects or components.

[Serializable]
public enum StatType { Health, AttackDamage, Defense, MovementSpeed, CooldownReduction, CriticalChance, CriticalDamage, ActionFluxGeneration }

[Serializable]
public enum ModifierType { Flat, Multiplier, PercentageAdd }

[Serializable]
public class PlayerAttackEventData
{
    public GameObject Attacker { get; private set; }
    public float BaseDamage { get; private set; }

    public PlayerAttackEventData(GameObject attacker, float baseDamage)
    {
        Attacker = attacker;
        BaseDamage = baseDamage;
    }
}

[Serializable]
public class EnemyHitEventData
{
    public GameObject Target { get; private set; }
    public GameObject Source { get; private set; }
    public float BaseDamage { get; private set; }
    public WeaponData Weapon { get; private set; }
    public List<AffixData> Affixes { get; private set; }

    public EnemyHitEventData(GameObject target, GameObject source, float baseDamage, WeaponData weapon, List<AffixData> affixes)
    {
        Target = target;
        Source = source;
        BaseDamage = baseDamage;
        Weapon = weapon;
        Affixes = affixes ?? new List<AffixData>();
    }
}

// Base class for all card effects
public abstract class CardEffect : ScriptableObject
{
    public string EffectName => name;
    public float Duration = 0f; // Duration for temporary effects, 0 for instantaneous
}

[CreateAssetMenu(fileName = "NewStatChangeEffect", menuName = "Card Effects/Stat Change")]
public class StatChangeEffect : CardEffect
{
    public StatType StatType;
    public float Value;
    public ModifierType ModifierType;
}

[CreateAssetMenu(fileName = "NewDamageEffect", menuName = "Card Effects/Damage")]
public class DamageEffect : CardEffect
{
    public float DamageAmount;
}

[CreateAssetMenu(fileName = "NewHealingEffect", menuName = "Card Effects/Healing")]
public class HealingEffect : CardEffect
{
    public float HealAmount;
}

[CreateAssetMenu(fileName = "NewInvulnerabilityEffect", menuName = "Card Effects/Invulnerability")]
public class InvulnerabilityEffect : CardEffect
{
    // Duration handled by base CardEffect.Duration
}

[CreateAssetMenu(fileName = "NewTeleportEffect", menuName = "Card Effects/Teleport")]
public class TeleportEffect : CardEffect
{
    public Vector2 Direction;
    public float Distance;
    public LayerMask ObstacleLayers;
    public float DamageOnArrival;
    public float DamageRadius;
    public LayerMask EnemyLayers;
}

[CreateAssetMenu(fileName = "NewStunEffect", menuName = "Card Effects/Stun")]
public class StunEffect : CardEffect
{
    // Duration handled by base CardEffect.Duration
}

[Serializable]
public enum ComboAbilityType { Shockwave, RapidFire, DashAttack }

[CreateAssetMenu(fileName = "NewComboUnlockEffect", menuName = "Card Effects/Combo Unlock")]
public class ComboUnlockEffect : CardEffect
{
    public ComboAbilityType ComboAbilityType;
    // Duration is in base CardEffect
}


public class CardData : ScriptableObject { /* Placeholder */ }


public class PlayerStats : MonoBehaviour, IHasStats
{
    public event Action<StatType, float> OnStatChanged;
    public event Action<float, float> OnHealthChanged;

    [SerializeField] private float maxHealth = 100f;
    [SerializeField] private float currentHealth;
    [SerializeField] private float baseAttackDamage = 10f;
    [SerializeField] private float baseDefense = 0f;
    [SerializeField] private float baseMovementSpeed = 5f;

    private Dictionary<StatType, float> baseStats;
    private Dictionary<StatType, List<StatModifier>> activeModifiers;

    private void Awake()
    {
        currentHealth = maxHealth;
        InitializeBaseStats();
        activeModifiers = new Dictionary<StatType, List<StatModifier>>();
        foreach (StatType type in Enum.GetValues(typeof(StatType)))
        {
            activeModifiers[type] = new List<StatModifier>();
        }
    }

    private void InitializeBaseStats()
    {
        baseStats = new Dictionary<StatType, float>
        {
            { StatType.Health, maxHealth }, // Max health is considered a base stat
            { StatType.AttackDamage, baseAttackDamage },
            { StatType.Defense, baseDefense },
            { StatType.MovementSpeed, baseMovementSpeed },
            { StatType.CooldownReduction, 0f },
            { StatType.CriticalChance, 0f },
            { StatType.CriticalDamage, 1.5f },
            { StatType.ActionFluxGeneration, 1f } // Base flux generation rate
        };
    }

    public float GetStatValue(StatType statType)
    {
        if (!baseStats.TryGetValue(statType, out float value))
        {
            Debug.LogWarning($"StatType {statType} not found in base stats.");
            return 0f;
        }

        float finalValue = value;
        List<StatModifier> modifiers = activeModifiers[statType];

        // Apply flat modifiers first
        foreach (var mod in modifiers.Where(m => m.Type == ModifierType.Flat))
        {
            finalValue += mod.Value;
        }

        // Apply multiplier modifiers
        foreach (var mod in modifiers.Where(m => m.Type == ModifierType.Multiplier))
        {
            finalValue *= mod.Value;
        }

        // Apply percentage add modifiers (e.g., +20% movespeed)
        float percentageBonus = 0f;
        foreach (var mod in modifiers.Where(m => m.Type == ModifierType.PercentageAdd))
        {
            percentageBonus += mod.Value;
        }
        finalValue *= (1 + percentageBonus);


        // Special handling for health to ensure it doesn't exceed max health if max health itself is modified
        if (statType == StatType.Health)
        {
            // Max health is treated as a stat, but current health is capped by it.
            // If MaxHealth is modified, we might need to adjust current health proportionally or cap it.
            // For now, GetStatValue(Health) returns the *max* health value.
            return finalValue;
        }

        return finalValue;
    }

    public void AddModifier(StatType statType, float value, ModifierType type, object source = null)
    {
        var modifier = new StatModifier { Value = value, Type = type, Source = source };
        activeModifiers[statType].Add(modifier);
        Debug.Log($"Added {type} modifier {value} to {statType} from {source?.GetType().Name ?? "Unknown"}. Current {statType}: {GetStatValue(statType)}");
        OnStatChanged?.Invoke(statType, GetStatValue(statType));
    }

    public void RemoveModifier(StatType statType, object source)
    {
        if (activeModifiers.TryGetValue(statType, out var modifiers))
        {
            int removedCount = modifiers.RemoveAll(m => m.Source == source);
            if (removedCount > 0)
            {
                Debug.Log($"Removed {removedCount} modifiers of type {statType} from source {source?.GetType().Name ?? "Unknown"}.");
                OnStatChanged?.Invoke(statType, GetStatValue(statType));
            }
        }
    }

    public void TakeDamage(float amount)
    {
        if (amount <= 0) return;
        currentHealth -= amount;
        currentHealth = Mathf.Max(0, currentHealth);
        Debug.Log($"Player took {amount} damage. Current Health: {currentHealth}/{GetStatValue(StatType.Health)}");
        OnHealthChanged?.Invoke(currentHealth, GetStatValue(StatType.Health));
        if (currentHealth <= 0)
        {
            Debug.Log("Player has died!");
            // Trigger game over logic
        }
    }

    public void Heal(float amount)
    {
        if (amount <= 0) return;
        currentHealth += amount;
        currentHealth = Mathf.Min(currentHealth, GetStatValue(StatType.Health)); // Cap at max health
        Debug.Log($"Player healed for {amount}. Current Health: {currentHealth}/{GetStatValue(StatType.Health)}");
        OnHealthChanged?.Invoke(currentHealth, GetStatValue(StatType.Health));
    }
}

public class StatModifier
{
    public float Value;
    public ModifierType Type;
    public object Source; // To identify who added the modifier for removal purposes
}


public class WeaponData : ScriptableObject
{
    public string WeaponName;
    public float BaseDamage;
    // Add other weapon properties like attack speed, range, etc.

    // A list of dynamic modifiers applied by cards. Not serialized, but managed at runtime.
    [NonSerialized] private List<AffixData> activeCardModifiers = new List<AffixData>();

    public void AddCardModifier(AffixData affix)
    {
        if (!activeCardModifiers.Contains(affix))
        {
            activeCardModifiers.Add(affix);
            Debug.Log($"Added card modifier {affix.name} to {WeaponName}");
        }
    }

    public void RemoveCardModifier(AffixData affix)
    {
        if (activeCardModifiers.Remove(affix))
        {
            Debug.Log($"Removed card modifier {affix.name} from {WeaponName}");
        }
    }

    public void ClearCardModifiers()
    {
        activeCardModifiers.Clear();
        Debug.Log($"Cleared all card modifiers from {WeaponName}");
    }

    /// <summary>
    /// Calculates the effective damage of the weapon, considering base damage and all active card modifiers.
    /// </summary>
    /// <param name="playerBaseAttack">The player's base attack stat to factor into calculations.</param>
    /// <returns>The calculated damage.</returns>
    public float CalculateDamage(float playerBaseAttack)
    {
        float damage = BaseDamage + playerBaseAttack; // Combine weapon base with player's base attack

        // Apply modifiers from cards
        foreach (var affix in activeCardModifiers)
        {
            foreach (var effect in affix.Effects)
            {
                if (effect is DamageModifierEffect damageModifier)
                {
                    damage *= damageModifier.Multiplier;
                    damage += damageModifier.FlatBonus;
                }
                // Add other effect types that might modify weapon damage
            }
        }
        return damage;
    }
}

public class AffixData : ScriptableObject
{
    public string AffixName;
    public List<CardEffect> Effects; // Affixes use the same CardEffect base class for modularity
}

[CreateAssetMenu(fileName = "NewDamageModifierEffect", menuName = "Affix Effects/Damage Modifier")]
public class DamageModifierEffect : CardEffect
{
    public float Multiplier = 1f;
    public float FlatBonus = 0f;
}

[CreateAssetMenu(fileName = "NewCriticalHitEffect", menuName = "Affix Effects/Critical Hit")]
public class CriticalHitEffect : CardEffect
{
    public float Chance = 0.1f; // 10% chance
    public float Multiplier = 2.0f; // 2x damage
}


public class EnemyAI : MonoBehaviour, IDamageable, IHasStats
{
    public GameObject GameObject => gameObject;

    [SerializeField] private float maxHealth = 50f;
    private float currentHealth;
    [SerializeField] private float attackDamage = 5f;
    [SerializeField] private float defense = 0f;
    [SerializeField] private float movementSpeed = 2f;

    private Dictionary<StatType, float> baseStats;
    private Dictionary<StatType, List<StatModifier>> activeModifiers;

    private bool isStunned = false;
    private Coroutine stunCoroutine;

    private void Awake()
    {
        currentHealth = maxHealth;
        InitializeBaseStats();
        activeModifiers = new Dictionary<StatType, List<StatModifier>>();
        foreach (StatType type in Enum.GetValues(typeof(StatType)))
        {
            activeModifiers[type] = new List<StatModifier>();
        }
    }

    private void InitializeBaseStats()
    {
        baseStats = new Dictionary<StatType, float>
        {
            { StatType.Health, maxHealth },
            { StatType.AttackDamage, attackDamage },
            { StatType.Defense, defense },
            { StatType.MovementSpeed, movementSpeed }
        };
    }

    public float GetStatValue(StatType statType)
    {
        if (!baseStats.TryGetValue(statType, out float value))
        {
            Debug.LogWarning($"StatType {statType} not found in enemy base stats.");
            return 0f;
        }

        float finalValue = value;
        if (activeModifiers.TryGetValue(statType, out var modifiers))
        {
            foreach (var mod in modifiers.Where(m => m.Type == ModifierType.Flat))
            {
                finalValue += mod.Value;
            }
            foreach (var mod in modifiers.Where(m => m.Type == ModifierType.Multiplier))
            {
                finalValue *= mod.Value;
            }
            float percentageBonus = 0f;
            foreach (var mod in modifiers.Where(m => m.Type == ModifierType.PercentageAdd))
            {
                percentageBonus += mod.Value;
            }
            finalValue *= (1 + percentageBonus);
        }
        return finalValue;
    }

    public void AddModifier(StatType statType, float value, ModifierType type, object source = null)
    {
        var modifier = new StatModifier { Value = value, Type = type, Source = source };
        if (!activeModifiers.ContainsKey(statType)) activeModifiers[statType] = new List<StatModifier>();
        activeModifiers[statType].Add(modifier);
        Debug.Log($"Enemy: Added {type} modifier {value} to {statType}. Current {statType}: {GetStatValue(statType)}");
    }

    public void RemoveModifier(StatType statType, object source)
    {
        if (activeModifiers.TryGetValue(statType, out var modifiers))
        {
            modifiers.RemoveAll(m => m.Source == source);
            Debug.Log($"Enemy: Removed modifier of type {statType} from source {source?.GetType().Name ?? "Unknown"}.");
        }
    }

    public void TakeDamage(float damage, GameObject source)
    {
        if (damage <= 0) return;
        currentHealth -= damage;
        currentHealth = Mathf.Max(0, currentHealth);
        Debug.Log($"Enemy {gameObject.name} took {damage} damage from {source.name}. Current Health: {currentHealth}/{GetStatValue(StatType.Health)}");
        if (currentHealth <= 0)
        {
            Die();
        }
    }

    public void Heal(float amount)
    {
        if (amount <= 0) return;
        currentHealth += amount;
        currentHealth = Mathf.Min(currentHealth, GetStatValue(StatType.Health));
        Debug.Log($"Enemy {gameObject.name} healed for {amount}. Current Health: {currentHealth}/{GetStatValue(StatType.Health)}");
    }

    public void Stun(float duration)
    {
        if (isStunned) return;

        isStunned = true;
        // Stop movement, disable attacks, etc.
        Debug.Log($"Enemy {gameObject.name} stunned for {duration} seconds.");
        if (stunCoroutine != null) StopCoroutine(stunCoroutine);
        stunCoroutine = StartCoroutine(StunTimer(duration));
    }

    private IEnumerator StunTimer(float duration)
    {
        // Example: Disable AI behavior here
        yield return new WaitForSeconds(duration);
        isStunned = false;
        Debug.Log($"Enemy {gameObject.name} stun ended.");
        // Re-enable AI behavior
    }

    private void Die()
    {
        Debug.Log($"Enemy {gameObject.name} has been defeated!");
        Destroy(gameObject);
    }
}


public class ActionFluxGenerator : MonoBehaviour
{
    public event Action<int> OnFluxChanged;

    [SerializeField] private int currentFlux = 0;
    [SerializeField] private int maxFlux = 100;
    [SerializeField] private int criticalHitFlux = 10;
    [SerializeField] private int successfulDodgeFlux = 5;
    [SerializeField] private int successfulParryFlux = 15;

    private void Awake()
    {
        OnFluxChanged?.Invoke(currentFlux); // Initial UI update
    }

    private void OnEnable()
    {
        CombatSystem.OnDamageDealt += HandleDamageDealt;
        CombatSystem.OnSuccessfulParry += HandleSuccessfulParry;
        // Assuming PlayerController calls OnSuccessfulDodge directly for now
    }

    private void OnDisable()
    {
        CombatSystem.OnDamageDealt -= HandleDamageDealt;
        CombatSystem.OnSuccessfulParry -= HandleSuccessfulParry;
    }

    private void HandleDamageDealt(GameObject source, float amount, bool isCritical)
    {
        if (isCritical && source.CompareTag("Player"))
        {
            AddFlux(criticalHitFlux);
        }
    }

    private void HandleSuccessfulParry(GameObject player)
    {
        if (player.CompareTag("Player"))
        {
            AddFlux(successfulParryFlux);
        }
    }

    /// <summary>
    /// Called by PlayerController when a dodge is successfully performed.
    /// </summary>
    /// <param name="player">The player GameObject.</param>
    public void OnSuccessfulDodge(GameObject player)
    {
        if (player.CompareTag("Player"))
        {
            AddFlux(successfulDodgeFlux);
        }
    }

    /// <summary>
    /// Adds flux to the current pool.
    /// </summary>
    /// <param name="amount">The amount of flux to add.</param>
    public void AddFlux(int amount)
    {
        if (amount < 0)
        {
            Debug.LogWarning("Attempted to add negative flux. Use ConsumeFlux instead.");
            return;
        }

        currentFlux = Mathf.Min(maxFlux, currentFlux + amount);
        OnFluxChanged?.Invoke(currentFlux);
        Debug.Log($"Added {amount} flux. Current Flux: {currentFlux}/{maxFlux}");
    }

    /// <summary>
    /// Consumes flux from the current pool.
    /// </summary>
    /// <param name="amount">The amount of flux to consume.</param>
    /// <returns>True if flux was successfully consumed, false otherwise (not enough flux).</returns>
    public bool ConsumeFlux(int amount)
    {
        if (amount < 0)
        {
            Debug.LogWarning("Attempted to consume negative flux.");
            return false;
        }

        if (currentFlux >= amount)
        {
            currentFlux -= amount;
            OnFluxChanged?.Invoke(currentFlux);
            Debug.Log($"Consumed {amount} flux. Current Flux: {currentFlux}/{maxFlux}");
            return true;
        }
        Debug.Log($"Not enough flux to consume {amount}. Current: {currentFlux}.");
        return false;
    }

    /// <summary>
    /// Gets the current amount of Action Flux.
    /// </summary>
    public int GetCurrentFlux()
    {
        return currentFlux;
    }
}


public class WeaponManager : MonoBehaviour
{
    [SerializeField] private WeaponData equippedWeapon;
    [SerializeField] private PlayerStats playerStats; // To get player stats for weapon damage calculation

    private List<CardData> _activeDeckCards = new List<CardData>(); // The cards currently in the player's active deck
    private List<ComboAbilityType> _activeComboAbilities = new List<ComboAbilityType>(); // Currently unlocked combo abilities

    public WeaponData EquippedWeapon => equippedWeapon;

    private void Awake()
    {
        if (playerStats == null) Debug.LogError("PlayerStats not assigned to WeaponManager.", this);
        if (equippedWeapon == null) Debug.LogWarning("No weapon assigned to EquippedWeapon slot.", this);
    }

    // Called by CardManager when the active deck changes
    public void UpdateWeaponModifiers(List<CardData> activeDeck)
    {
        _activeDeckCards = activeDeck;
        ApplyDeckBoundModifiers();
    }

    /// <summary>
    /// Equips a new weapon and updates modifiers.
    /// </summary>
    /// <param name="newWeapon">The WeaponData for the new weapon.</param>
    public void EquipWeapon(WeaponData newWeapon)
    {
        if (equippedWeapon != null)
        {
            equippedWeapon.ClearCardModifiers(); // Clear modifiers from old weapon
            // Potentially reset any special states related to the old weapon
        }

        equippedWeapon = newWeapon;
        if (equippedWeapon != null)
        {
            ApplyDeckBoundModifiers(); // Apply modifiers to new weapon
            Debug.Log($"Equipped weapon: {equippedWeapon.WeaponName}");
        }
        else
        {
            Debug.Log("Unequipped weapon.");
        }
    }

    /// <summary>
    /// Gets the currently equipped weapon's data.
    /// </summary>
    /// <returns>The WeaponData of the equipped weapon.</returns>
    public WeaponData GetEquippedWeapon()
    {
        return equippedWeapon;
    }

    private void ApplyDeckBoundModifiers()
    {
        if (equippedWeapon == null) return;

        equippedWeapon.ClearCardModifiers(); // Start fresh

        // Iterate through active deck cards and apply relevant affixes as modifiers to the equipped weapon
        foreach (CardData card in _activeDeckCards)
        {
            // Assuming CardData has a way to expose its inherent weapon modifiers/affixes
            // For example, a CardData might have a list of AffixData it grants to weapons.
            // This is a hypothetical link, adjust based on actual CardData structure.
            if (card is IWeaponModifierProvider modifierProvider) // Hypothetical interface
            {
                foreach (AffixData affix in modifierProvider.GetWeaponAffixes())
                {
                    equippedWeapon.AddCardModifier(affix);
                }
            }
            // Or, if cards directly reference specific affixes:
            // if (card.GrantsWeaponAffix != null)
            // {
            //     equippedWeapon.AddCardModifier(card.GrantsWeaponAffix);
            // }
        }
        Debug.Log($"Applied deck-bound modifiers to {equippedWeapon.WeaponName}.");
    }

    /// <summary>
    /// Activates a special combo ability for the equipped weapon.
    /// This is typically called by CombatSystem when a ComboUnlockEffect card is played.
    /// </summary>
    /// <param name="comboType">The type of combo ability to activate.</param>
    /// <param name="duration">How long the combo ability is active.</param>
    public void ActivateComboAbility(ComboAbilityType comboType, float duration)
    {
        if (!_activeComboAbilities.Contains(comboType))
        {
            _activeComboAbilities.Add(comboType);
            Debug.Log($"Activated combo ability: {comboType} for {duration} seconds.");
            StartCoroutine(DeactivateComboAbilityAfterDuration(comboType, duration));
        }
        else
        {
            Debug.Log($"Combo ability {comboType} is already active, extending duration if applicable.");
            // Logic to extend duration if desired
        }
    }

    private IEnumerator DeactivateComboAbilityAfterDuration(ComboAbilityType comboType, float duration)
    {
        yield return new WaitForSeconds(duration);
        _activeComboAbilities.Remove(comboType);
        Debug.Log($"Deactivated combo ability: {comboType}.");
    }

    /// <summary>
    /// Checks if a specific combo ability is currently active.
    /// </summary>
    /// <param name="comboType">The type of combo ability to check.</param>
    /// <returns>True if the combo ability is active, false otherwise.</returns>
    public bool IsComboAbilityActive(ComboAbilityType comboType)
    {
        return _activeComboAbilities.Contains(comboType);
    }
}

// PlayerAnimationController placeholder
public class PlayerAnimationController : MonoBehaviour
{
    public void SetMoveState(bool isMoving, float xDirection) { Debug.Log($"Player {(isMoving ? "moving" : "idle")} x: {xDirection}"); }
    public void TriggerAttack() { Debug.Log("Player Attack Animation Triggered."); }
    public void TriggerDodge() { Debug.Log("Player Dodge Animation Triggered."); }
    public void TriggerParry() { Debug.Log("Player Parry Animation Triggered."); }
}

// CardManager placeholder, just enough for compilation
public class CardManager : MonoBehaviour
{
    [SerializeField] private ActionFluxGenerator actionFluxGenerator;
    [SerializeField] private CombatSystem combatSystem;
    [SerializeField] private WeaponManager weaponManager; // For weapon-card synergies
    [SerializeField] private PlayerStats playerStats; // For stats-based card effects

    private List<CardData> _playerCollectedCards = new List<CardData>();
    private List<CardData> _activeDeck = new List<CardData>();
    private List<CardData> _activeHand = new List<CardData>(); // Cards currently available for use
    private CardData _currentlySelectedCard; // For tactical hot-swapping

    public int MaxActiveHandSize = 3;
    public int CardActivationFluxCost = 20; // Example cost for activating a card

    private void Awake()
    {
        if (actionFluxGenerator == null) Debug.LogError("ActionFluxGenerator not assigned to CardManager.", this);
        if (combatSystem == null) Debug.LogError("CombatSystem not assigned to CardManager.", this);
        if (weaponManager == null) Debug.LogError("WeaponManager not assigned to CardManager.", this);
        if (playerStats == null) Debug.LogError("PlayerStats not assigned to CardManager.", this);

        // Example: Initialize with some dummy cards
        CardData dummyCard1 = ScriptableObject.CreateInstance<CardData>();
        dummyCard1.name = "Dummy Card 1";
        CardData dummyCard2 = ScriptableObject.CreateInstance<CardData>();
        dummyCard2.name = "Dummy Card 2";
        CardData dummyCard3 = ScriptableObject.CreateInstance<CardData>();
        dummyCard3.name = "Dummy Card 3";

        _activeDeck.Add(dummyCard1);
        _activeDeck.Add(dummyCard2);
        _activeDeck.Add(dummyCard3);
        _playerCollectedCards.AddRange(_activeDeck); // Add to collected as well

        PopulateActiveHand(); // Fill hand for initial use
        weaponManager?.UpdateWeaponModifiers(_activeDeck); // Notify weapon manager about initial deck
    }

    public void AddCard(CardData card)
    {
        if (!_playerCollectedCards.Contains(card))
        {
            _playerCollectedCards.Add(card);
            Debug.Log($"Added card: {card.name}");
        }
        else
        {
            Debug.LogWarning($"Card {card.name} already collected.");
        }
    }

    public void RemoveCard(CardData card)
    {
        _playerCollectedCards.Remove(card);
        _activeDeck.Remove(card); // Also remove from deck if it was there
        _activeHand.Remove(card); // Also remove from hand if it was there
        Debug.Log($"Removed card: {card.name}");
        weaponManager?.UpdateWeaponModifiers(_activeDeck); // Update weapon mods
    }

    public void UpgradeCard(CardData card)
    {
        // Placeholder for upgrading card effects/stats
        Debug.Log($"Upgraded card: {card.name}");
    }

    /// <summary>
    /// Attempts to activate the currently selected card.
    /// </summary>
    public void ActivateCurrentlySelectedCard()
    {
        if (_currentlySelectedCard == null)
        {
            Debug.Log("No card selected to activate.");
            return;
        }

        ActivateCard(_currentlySelectedCard);
    }


    /// <summary>
    /// Activates a specific card, consuming Action Flux and applying its effects.
    /// </summary>
    /// <param name="card">The CardData to activate.</param>
    public void ActivateCard(CardData card)
    {
        if (!CanActivateCard(card))
        {
            Debug.Log($"Cannot activate {card.name}: Not enough flux or card not in hand.");
            return;
        }

        if (actionFluxGenerator.ConsumeFlux(CardActivationFluxCost))
        {
            Debug.Log($"Activating card: {card.name}");

            // Apply card effects
            // Assuming CardData has a list of CardEffect ScriptableObjects
            if (card is ICardEffectProvider effectProvider) // Hypothetical interface for cards providing effects
            {
                foreach (CardEffect effect in effectProvider.GetEffects())
                {
                    combatSystem.ApplyEffect(playerStats.gameObject, effect); // Apply effects to player
                }
            }
            else
            {
                // Fallback for simple CardData, or if effects are hardcoded per card type
                Debug.LogWarning($"Card {card.name} does not implement ICardEffectProvider. No effects applied.");
            }

            // After activation, remove from active hand and potentially draw a new one
            _activeHand.Remove(card);
            PopulateActiveHand(); // Draw a new card if slot is empty
            if (_currentlySelectedCard == card)
            {
                // Select a new card if the activated one was the currently selected
                TacticalCardSwap(0); // This will re-select the first card or null if hand is empty
            }

            // Handle weapon-card synergies that are consumed
            // Example: If a card granted a temporary combo modifier, its activation might be linked to that.
        }
    }

    /// <summary>
    /// Checks if a card can be activated (e.g., enough flux, card is in hand).
    /// </summary>
    /// <param name="card">The CardData to check.</param>
    /// <returns>True if the card can be activated, false otherwise.</returns>
    public bool CanActivateCard(CardData card)
    {
        return _activeHand.Contains(card) && actionFluxGenerator.GetCurrentFlux() >= CardActivationFluxCost;
    }

    /// <summary>
    /// Sets the player's active hand. Typically called by ProgressionManager or GameState.
    /// </summary>
    /// <param name="newHand">The list of CardData to set as the active hand.</param>
    public void SetActiveHand(List<CardData> newHand)
    {
        _activeHand = newHand;
        // Ensure hand size limit
        while (_activeHand.Count > MaxActiveHandSize)
        {
            _activeHand.RemoveAt(_activeHand.Count - 1); // Or a more sophisticated removal
        }
        Debug.Log($"Active hand set. Current cards: {_activeHand.Count}");

        // Automatically select the first card if hand is not empty
        if (_activeHand.Count > 0)
        {
            _currentlySelectedCard = _activeHand[0];
        }
        else
        {
            _currentlySelectedCard = null;
        }
    }

    /// <summary>
    /// Populates the active hand from the active deck, respecting MaxActiveHandSize.
    /// </summary>
    private void PopulateActiveHand()
    {
        while (_activeHand.Count < MaxActiveHandSize && _activeDeck.Count > _activeHand.Count)
        {
            // Simple draw: pick a random card from the deck not already in hand
            List<CardData> drawableCards = _activeDeck.Except(_activeHand).ToList();
            if (drawableCards.Count > 0)
            {
                CardData drawnCard = drawableCards[UnityEngine.Random.Range(0, drawableCards.Count)];
                _activeHand.Add(drawnCard);
                Debug.Log($"Drew card: {drawnCard.name}");
            }
            else
            {
                Debug.Log("No more cards to draw from deck into hand.");
                break; // No more unique cards to draw
            }
        }

        // If no card is selected, select the first one if available
        if (_currentlySelectedCard == null && _activeHand.Count > 0)
        {
            _currentlySelectedCard = _activeHand[0];
        }
        // If the selected card is no longer in hand (e.g., activated), select the next available
        else if (_currentlySelectedCard != null && !_activeHand.Contains(_currentlySelectedCard))
        {
            TacticalCardSwap(0); // This will effectively re-select the current or next valid card
        }
    }

    /// <summary>
    /// Allows rapid swapping between active cards in hand.
    /// </summary>
    /// <param name="direction">1 for next, -1 for previous, 0 to re-select current or first.</param>
    public void TacticalCardSwap(int direction)
    {
        if (_activeHand.Count == 0)
        {
            _currentlySelectedCard = null;
            Debug.Log("No cards in hand to swap.");
            return;
        }

        int currentIndex = _currentlySelectedCard != null ? _activeHand.IndexOf(_currentlySelectedCard) : -1;
        int nextIndex;

        if (direction == 0) // Re-select current or first
        {
            nextIndex = (currentIndex != -1 && currentIndex < _activeHand.Count) ? currentIndex : 0;
        }
        else
        {
            nextIndex = currentIndex + direction;
            if (nextIndex >= _activeHand.Count)
            {
                nextIndex = 0; // Wrap around to start
            }
            else if (nextIndex < 0)
            {
                nextIndex = _activeHand.Count - 1; // Wrap around to end
            }
        }

        _currentlySelectedCard = _activeHand[nextIndex];
        Debug.Log($"Currently selected card: {_currentlySelectedCard.name}");
        // Inform UI about selected card
    }

    public CardData GetCurrentlySelectedCard()
    {
        return _currentlySelectedCard;
    }
}