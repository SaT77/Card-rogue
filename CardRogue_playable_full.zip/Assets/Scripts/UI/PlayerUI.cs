// Required Packages:
// - com.unity.ugui
// - com.demigiant.dotween

using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System;
using DG.Tweening; // Using DOTween for UI animations

public class PlayerUI : MonoBehaviour
{
    [Header("Dependencies")]
    [SerializeField] private PlayerStats playerStats;
    [SerializeField] private ActionFluxGenerator actionFluxGenerator;
    [SerializeField] private CardManager cardManager;
    [SerializeField] private ItemManager itemManager;

    [Header("UI Elements - Player Stats")]
    [SerializeField] private Slider healthBar;
    [SerializeField] private Text healthText;
    [SerializeField] private Slider actionFluxBar;
    [SerializeField] private Text actionFluxText;

    [Header("UI Elements - Active Hand")]
    [SerializeField] private RectTransform activeHandContainer;
    [SerializeField] private GameObject cardSlotPrefab;
    [SerializeField] private Color selectedCardColor = Color.yellow;
    [SerializeField] private Color deselectedCardColor = Color.white;
    [SerializeField] private Color lowFluxColor = Color.red; // Color for cards not activatable due to flux

    [Header("UI Elements - Inventory")]
    [SerializeField] private GameObject inventoryPanel;
    [SerializeField] private RectTransform inventoryContentContainer;
    [SerializeField] private GameObject inventoryItemPrefab;
    [SerializeField] private Button inventoryCloseButton;

    [Header("UI Elements - Pause Menu")]
    [SerializeField] private GameObject pauseMenuPanel;
    [SerializeField] private Button resumeButton;
    [SerializeField] private Button optionsButton;
    [SerializeField] private Button exitButton;

    // Internal tracking for active hand UI elements
    private List<GameObject> _activeCardSlots = new List<GameObject>();

    private void Awake()
    {
        InitializeDependencies();
        InitializeUI();
    }

    private void OnEnable()
    {
        SubscribeToEvents();
    }

    private void OnDisable()
    {
        UnsubscribeFromEvents();
    }

    /// <summary>
    /// Initializes references to required game systems and checks for nulls.
    /// </summary>
    private void InitializeDependencies()
    {
        if (playerStats == null) Debug.LogError("PlayerStats reference is not set in PlayerUI.", this);
        if (actionFluxGenerator == null) Debug.LogError("ActionFluxGenerator reference is not set in PlayerUI.", this);
        if (cardManager == null) Debug.LogError("CardManager reference is not set in PlayerUI.", this);
        if (itemManager == null) Debug.LogError("ItemManager reference is not set in PlayerUI.", this);

        if (cardSlotPrefab == null) Debug.LogError("Card Slot Prefab is not set in PlayerUI.", this);
        if (inventoryItemPrefab == null) Debug.LogError("Inventory Item Prefab is not set in PlayerUI.", this);
    }

    /// <summary>
    /// Sets initial UI states and populates static UI elements.
    /// </summary>
    private void InitializeUI()
    {
        // Hide panels initially
        if (inventoryPanel != null) inventoryPanel.SetActive(false);
        if (pauseMenuPanel != null) pauseMenuPanel.SetActive(false);

        // Set up button listeners
        if (inventoryCloseButton != null) inventoryCloseButton.onClick.AddListener(() => ShowInventory(new List<ItemData>())); // Close by passing empty list
        if (resumeButton != null) resumeButton.onClick.AddListener(OnResumeButtonClicked);
        if (optionsButton != null) optionsButton.onClick.AddListener(OnOptionsButtonClicked);
        if (exitButton != null) exitButton.onClick.AddListener(OnExitButtonClicked);

        // Initial update of all UI elements
        if (playerStats != null)
        {
            UpdateHealthBar(playerStats.GetStatValue(StatType.Health), playerStats.GetStatValue(StatType.MaxHealth));
        }
        if (actionFluxGenerator != null)
        {
            UpdateActionFlux(actionFluxGenerator.GetCurrentFlux());
        }
        if (cardManager != null)
        {
            UpdateActiveHand(cardManager.GetActiveHand());
        }
    }

    /// <summary>
    /// Subscribes to necessary events from other game systems.
    /// </summary>
    private void SubscribeToEvents()
    {
        if (playerStats != null)
        {
            PlayerStats.OnHealthChanged += UpdateHealthBar;
        }
        if (actionFluxGenerator != null)
        {
            ActionFluxGenerator.OnFluxChanged += UpdateActionFlux;
        }
        if (cardManager != null)
        {
            CardManager.OnActiveHandChanged += UpdateActiveHand;
            CardManager.OnSelectedCardChanged += UpdateSelectedCardVisual;
            CardManager.OnCardActivated += OnCardActivatedFeedback; // For visual feedback on activation
        }
    }

    /// <summary>
    /// Unsubscribes from events to prevent memory leaks and errors.
    /// </summary>
    private void UnsubscribeFromEvents()
    {
        if (playerStats != null)
        {
            PlayerStats.OnHealthChanged -= UpdateHealthBar;
        }
        if (actionFluxGenerator != null)
        {
            ActionFluxGenerator.OnFluxChanged -= UpdateActionFlux;
        }
        if (cardManager != null)
        {
            CardManager.OnActiveHandChanged -= UpdateActiveHand;
            CardManager.OnSelectedCardChanged -= UpdateSelectedCardVisual;
            CardManager.OnCardActivated -= OnCardActivatedFeedback;
        }

        // Clean up button listeners to avoid duplicate subscriptions if PlayerUI is re-enabled
        if (inventoryCloseButton != null) inventoryCloseButton.onClick.RemoveAllListeners();
        if (resumeButton != null) resumeButton.onClick.RemoveAllListeners();
        if (optionsButton != null) optionsButton.onClick.RemoveAllListeners();
        if (exitButton != null) exitButton.onClick.RemoveAllListeners();
    }

    /// <summary>
    /// Updates the player's health bar and text display.
    /// </summary>
    /// <param name="currentHealth">The current health value.</param>
    /// <param name="maxHealth">The maximum health value.</param>
    public void UpdateHealthBar(float currentHealth, float maxHealth)
    {
        if (healthBar != null)
        {
            healthBar.value = currentHealth / maxHealth;
            // Animate health bar change
            healthBar.DOValue(currentHealth / maxHealth, 0.2f);
        }
        if (healthText != null)
        {
            healthText.text = $"{Mathf.CeilToInt(currentHealth)} / {Mathf.CeilToInt(maxHealth)}";
        }
    }

    /// <summary>
    /// Updates the Action Flux bar and text display.
    /// </summary>
    /// <param name="currentFlux">The current Action Flux value.</param>
    public void UpdateActionFlux(int currentFlux)
    {
        if (actionFluxGenerator == null) return; // Guard against null dependency

        int maxFlux = actionFluxGenerator.GetMaxFlux();
        if (actionFluxBar != null)
        {
            actionFluxBar.value = (float)currentFlux / maxFlux;
            // Animate flux bar change
            actionFluxBar.DOValue((float)currentFlux / maxFlux, 0.2f);
        }
        if (actionFluxText != null)
        {
            actionFluxText.text = $"Flux: {currentFlux} / {maxFlux}";
        }

        // Also update the activatable state of cards in hand
        UpdateActiveHand(cardManager.GetActiveHand());
        UpdateSelectedCardVisual(cardManager.GetCurrentlySelectedCard());
    }

    /// <summary>
    /// Updates the visual representation of cards in the player's active hand.
    /// Destroys old slots and creates new ones, or reuses existing.
    /// </summary>
    /// <param name="activeCards">The list of cards currently in the active hand.</param>
    public void UpdateActiveHand(List<CardData> activeCards)
    {
        if (activeHandContainer == null || cardSlotPrefab == null)
        {
            Debug.LogError("Active Hand UI container or Card Slot Prefab is not assigned.");
            return;
        }

        // Clear existing slots first
        foreach (GameObject slot in _activeCardSlots)
        {
            Destroy(slot);
        }
        _activeCardSlots.Clear();

        // Create new slots for each card
        foreach (CardData card in activeCards)
        {
            GameObject cardSlotGO = Instantiate(cardSlotPrefab, activeHandContainer);
            _activeCardSlots.Add(cardSlotGO);

            // Populate card slot details
            // Assuming cardSlotPrefab has a structure like:
            // - CardSlot (GameObject)
            //   - Icon (Image)
            //   - Name (Text)
            //   - FluxCost (Text)
            //   - Background (Image or Panel for visual states)

            Image cardIcon = cardSlotGO.transform.Find("Icon")?.GetComponent<Image>();
            Text cardNameText = cardSlotGO.transform.Find("Name")?.GetComponent<Text>();
            Text fluxCostText = cardSlotGO.transform.Find("FluxCost")?.GetComponent<Text>();
            Image cardBackground = cardSlotGO.GetComponent<Image>(); // Or find a specific background panel

            if (cardIcon != null) cardIcon.sprite = card.Icon;
            if (cardNameText != null) cardNameText.text = card.CardName;
            if (fluxCostText != null) fluxCostText.text = card.FluxCost.ToString();

            // Set up button for card activation
            Button cardButton = cardSlotGO.GetComponent<Button>();
            if (cardButton != null)
            {
                cardButton.onClick.RemoveAllListeners(); // Clear previous listeners
                cardButton.onClick.AddListener(() => OnCardSlotClicked(card));
            }

            // Update card activatable status (color based on flux)
            UpdateCardActivatableVisual(card, cardSlotGO);
        }

        // Ensure the currently selected card visual is applied after hand update
        UpdateSelectedCardVisual(cardManager.GetCurrentlySelectedCard());
    }

    /// <summary>
    /// Visually highlights the currently selected card and unhighlights others.
    /// Also updates the "activatable" state based on current flux.
    /// </summary>
    /// <param name="selectedCard">The card that is currently selected.</param>
    private void UpdateSelectedCardVisual(CardData selectedCard)
    {
        if (_activeCardSlots.Count == 0 || activeHandContainer == null) return;

        for (int i = 0; i < _activeCardSlots.Count; i++)
        {
            GameObject cardSlotGO = _activeCardSlots[i];
            // Find the CardData associated with this slot if necessary, or pass it directly.
            // For simplicity, we can rely on the order if UpdateActiveHand always recreates.
            // A more robust solution might store CardData on the CardSlotGO itself.
            CardData cardInSlot = cardManager.GetActiveHand()[i]; // Assumes order matches

            Image cardBackground = cardSlotGO.GetComponent<Image>(); // Or find a specific background panel

            if (cardBackground != null)
            {
                if (cardInSlot == selectedCard)
                {
                    cardBackground.color = selectedCardColor;
                    cardBackground.transform.DOScale(1.1f, 0.15f).SetEase(Ease.OutBack); // Pop out effect
                }
                else
                {
                    cardBackground.color = deselectedCardColor;
                    cardBackground.transform.DOScale(1.0f, 0.15f).SetEase(Ease.OutBack); // Back to normal size
                }
            }
            UpdateCardActivatableVisual(cardInSlot, cardSlotGO); // Always update activatable state
        }
    }

    /// <summary>
    /// Updates the visual state of a single card slot based on whether it can be activated.
    /// </summary>
    /// <param name="card">The CardData for the slot.</param>
    /// <param name="cardSlotGO">The GameObject representing the card slot.</param>
    private void UpdateCardActivatableVisual(CardData card, GameObject cardSlotGO)
    {
        if (card == null || cardSlotGO == null || cardManager == null || actionFluxGenerator == null) return;

        Image cardBackground = cardSlotGO.GetComponent<Image>();
        Text fluxCostText = cardSlotGO.transform.Find("FluxCost")?.GetComponent<Text>();

        if (cardBackground != null)
        {
            // If the card is selected, its color is already set by UpdateSelectedCardVisual.
            // Otherwise, set to default deselected color.
            if (cardManager.GetCurrentlySelectedCard() != card)
            {
                cardBackground.color = deselectedCardColor;
            }
        }

        if (fluxCostText != null)
        {
            if (actionFluxGenerator.GetCurrentFlux() < card.FluxCost)
            {
                fluxCostText.color = lowFluxColor;
                if (cardBackground != null)
                {
                    // Optionally make the card visually less prominent if not activatable due to flux
                    cardBackground.DOColor(Color.grey, 0.1f);
                }
            }
            else
            {
                fluxCostText.color = Color.white; // Default color
                if (cardBackground != null && cardManager.GetCurrentlySelectedCard() != card)
                {
                    cardBackground.DOColor(deselectedCardColor, 0.1f);
                }
            }
        }
    }


    /// <summary>
    /// Displays or hides the inventory panel and populates it with items.
    /// Passing an empty list or null hides the panel.
    /// </summary>
    /// <param name="inventory">The list of items to display in the inventory.</param>
    public void ShowInventory(List<ItemData> inventory)
    {
        if (inventoryPanel == null || inventoryContentContainer == null || inventoryItemPrefab == null)
        {
            Debug.LogError("Inventory UI components are not assigned.");
            return;
        }

        if (inventory == null || inventory.Count == 0)
        {
            inventoryPanel.SetActive(false);
            return;
        }

        inventoryPanel.SetActive(true);

        // Clear existing items
        foreach (Transform child in inventoryContentContainer)
        {
            Destroy(child.gameObject);
        }

        // Populate with new items
        foreach (ItemData item in inventory)
        {
            GameObject itemGO = Instantiate(inventoryItemPrefab, inventoryContentContainer);

            // Populate item details (assuming inventoryItemPrefab has similar structure to card slot)
            Image itemIcon = itemGO.transform.Find("Icon")?.GetComponent<Image>();
            Text itemNameText = itemGO.transform.Find("Name")?.GetComponent<Text>();
            Text itemDescriptionText = itemGO.transform.Find("Description")?.GetComponent<Text>();

            if (itemIcon != null) itemIcon.sprite = item.Icon;
            if (itemNameText != null) itemNameText.text = item.ItemName;
            if (itemDescriptionText != null) itemDescriptionText.text = item.Description;

            // Optionally add button for interaction (equip, inspect, etc.)
            Button itemButton = itemGO.GetComponent<Button>();
            if (itemButton != null)
            {
                itemButton.onClick.RemoveAllListeners();
                itemButton.onClick.AddListener(() => OnInventoryItemClicked(item));
            }
        }
    }

    /// <summary>
    /// Shows or hides the pause menu.
    /// </summary>
    /// <param name="show">True to show, false to hide.</param>
    public void ShowPauseMenu(bool show)
    {
        if (pauseMenuPanel != null)
        {
            pauseMenuPanel.SetActive(show);
            // Optionally pause game time
            Time.timeScale = show ? 0f : 1f;
        }
    }

    // --- UI Interaction Callbacks ---

    private void OnCardSlotClicked(CardData card)
    {
        // When a card slot is clicked, attempt to activate it.
        // The CardManager will handle flux check and actual activation.
        if (cardManager != null)
        {
            cardManager.ActivateCard(card);
        }
    }

    private void OnInventoryItemClicked(ItemData item)
    {
        Debug.Log($"Clicked on inventory item: {item.ItemName}");
        // Here you might trigger an item inspection panel or equip logic
        // Example: itemManager.EquipItem(item);
    }

    private void OnResumeButtonClicked()
    {
        ShowPauseMenu(false); // Hide pause menu
    }

    private void OnOptionsButtonClicked()
    {
        Debug.Log("Options menu opened.");
        // Implement logic to show options menu
    }

    private void OnExitButtonClicked()
    {
        Debug.Log("Exiting game.");
        // Implement logic to return to main menu or quit application
        Application.Quit();
    }

    /// <summary>
    /// Provides visual feedback when a card is successfully activated.
    /// </summary>
    /// <param name="card">The card that was activated.</param>
    private void OnCardActivatedFeedback(CardData card)
    {
        // Find the activated card's slot in the UI and provide feedback (e.g., fade out, shrink)
        GameObject activatedSlot = null;
        for (int i = 0; i < _activeCardSlots.Count; i++)
        {
            // This is a simple lookup, assumes card order in UI matches active hand.
            // A more robust solution involves tagging/storing CardData on the UI prefab itself.
            if (cardManager.GetActiveHand().Contains(card)) // Check if it's still in the list
            {
                // If the card is still in the active hand (e.g., a card that doesn't consume itself)
                // then we don't want to play a "disappear" animation.
                // For now, let's assume cards are removed on activation.
                continue; // Skip if card is still in hand.
            }
            if (cardManager.GetActiveHand().Count <= i || cardManager.GetActiveHand()[i] != card)
            {
                // This means the card was likely just removed from the active hand and its slot needs feedback.
                activatedSlot = _activeCardSlots[i];
                break;
            }
        }

        if (activatedSlot != null)
        {
            // Example: Fade out and shrink
            activatedSlot.transform.DOScale(0f, 0.3f).SetEase(Ease.InBack);
            activatedSlot.GetComponent<CanvasGroup>()?.DOFade(0f, 0.3f).OnComplete(() => Destroy(activatedSlot));
            Debug.Log($"Playing activation feedback for {card.CardName}");
        }
    }
}