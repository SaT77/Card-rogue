using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections.Generic;

public class MainMenu : MonoBehaviour
{
    [Header("Dependencies")]
    [SerializeField] private ProgressionManager progressionManager;

    [Header("Main Menu Panels")]
    [SerializeField] private GameObject mainMenuPanel;
    [SerializeField] private GameObject settingsPanel;
    [SerializeField] private GameObject loadGamePanel; // For future load game functionality, currently placeholder

    [Header("Main Menu Buttons")]
    [SerializeField] private Button newGameButton;
    [SerializeField] private Button continueGameButton;
    [SerializeField] private Button settingsButton;
    [SerializeField] private Button quitButton;

    // Settings menu UI elements (placeholders for now)
    [Header("Settings Menu UI")]
    [SerializeField] private Button settingsBackButton;
    [SerializeField] private Slider graphicsQualitySlider;
    [SerializeField] private Toggle fullScreenToggle;
    [SerializeField] private Slider masterVolumeSlider;
    [SerializeField] private Button rebindControlsButton;

    // Load Game menu UI elements (placeholders for now)
    [Header("Load Game Menu UI")]
    [SerializeField] private Button loadGameBackButton;
    [SerializeField] private Button loadGameSlot1Button; // Example load slot
    [SerializeField] private Button loadGameSlot2Button; // Example load slot

    private const string GraphicsQualityPrefKey = "GraphicsQuality";
    private const string FullScreenPrefKey = "FullScreen";
    private const string MasterVolumePrefKey = "MasterVolume";

    private void Awake()
    {
        // Check dependencies
        if (progressionManager == null)
        {
            Debug.LogError("ProgressionManager is not assigned to MainMenu. Cannot operate without it.", this);
        }

        // Initialize UI states
        ShowPanel(mainMenuPanel);
        HidePanel(settingsPanel);
        HidePanel(loadGamePanel);

        // Add button listeners
        if (newGameButton != null) newGameButton.onClick.AddListener(StartNewGame);
        if (continueGameButton != null) continueGameButton.onClick.AddListener(ContinueGame);
        if (settingsButton != null) settingsButton.onClick.AddListener(OpenSettings);
        if (quitButton != null) quitButton.onClick.AddListener(QuitGame);

        // Settings menu button listeners
        if (settingsBackButton != null) settingsBackButton.onClick.AddListener(CloseSettings);
        if (graphicsQualitySlider != null) graphicsQualitySlider.onValueChanged.AddListener(SetGraphicsQuality);
        if (fullScreenToggle != null) fullScreenToggle.onValueChanged.AddListener(SetFullScreen);
        if (masterVolumeSlider != null) masterVolumeSlider.onValueChanged.AddListener(SetMasterVolume);
        if (rebindControlsButton != null) rebindControlsButton.onClick.AddListener(RebindControls);

        // Load Game menu button listeners
        if (loadGameBackButton != null) loadGameBackButton.onClick.AddListener(CloseLoadGameMenu);
        if (loadGameSlot1Button != null) loadGameSlot1Button.onClick.AddListener(() => LoadGameSlot(1));
        if (loadGameSlot2Button != null) loadGameSlot2Button.onClick.AddListener(() => LoadGameSlot(2));

        // Load saved settings on startup
        LoadSettings();
    }

    private void OnDisable()
    {
        // Remove all listeners to prevent memory leaks or errors when the object is destroyed
        if (newGameButton != null) newGameButton.onClick.RemoveAllListeners();
        if (continueGameButton != null) continueGameButton.onClick.RemoveAllListeners();
        if (settingsButton != null) settingsButton.onClick.RemoveAllListeners();
        if (quitButton != null) quitButton.onClick.RemoveAllListeners();

        if (settingsBackButton != null) settingsBackButton.onClick.RemoveAllListeners();
        if (graphicsQualitySlider != null) graphicsQualitySlider.onValueChanged.RemoveAllListeners();
        if (fullScreenToggle != null) fullScreenToggle.onValueChanged.RemoveAllListeners();
        if (masterVolumeSlider != null) masterVolumeSlider.onValueChanged.RemoveAllListeners();
        if (rebindControlsButton != null) rebindControlsButton.onClick.RemoveAllListeners();

        if (loadGameBackButton != null) loadGameBackButton.onClick.RemoveAllListeners();
        if (loadGameSlot1Button != null) loadGameSlot1Button.onClick.RemoveAllListeners();
        if (loadGameSlot2Button != null) loadGameSlot2Button.onClick.RemoveAllListeners();
    }

    /// <summary>
    /// Starts a new game run through the ProgressionManager.
    /// </summary>
    public void StartNewGame()
    {
        Debug.Log("Starting New Game...");
        if (progressionManager != null)
        {
            progressionManager.StartNewRun();
        }
    }

    /// <summary>
    /// Continues a saved game. Currently a placeholder for loading logic.
    /// </summary>
    public void ContinueGame()
    {
        Debug.Log("Attempting to Continue Game...");
        // In a full implementation, this would load a save file and then start the run.
        // For now, it just attempts to load progression and starts a new run.
        if (progressionManager != null)
        {
            progressionManager.LoadProgression(); // Load meta-progression
            // If there's a specific saved game state, load that. Otherwise, start new.
            // For now, assume this button would open a load game menu:
            OpenLoadGameMenu();
        }
    }

    /// <summary>
    /// Opens the settings menu panel.
    /// </summary>
    public void OpenSettings()
    {
        Debug.Log("Opening Settings Menu...");
        HidePanel(mainMenuPanel);
        ShowPanel(settingsPanel);
    }

    /// <summary>
    /// Closes the settings menu and returns to the main menu.
    /// Also saves any changed settings.
    /// </summary>
    public void CloseSettings()
    {
        Debug.Log("Closing Settings Menu and Saving...");
        SaveSettings();
        HidePanel(settingsPanel);
        ShowPanel(mainMenuPanel);
    }

    /// <summary>
    /// Opens the load game menu panel.
    /// </summary>
    public void OpenLoadGameMenu()
    {
        Debug.Log("Opening Load Game Menu...");
        HidePanel(mainMenuPanel);
        ShowPanel(loadGamePanel);
        // Populate load slots here based on save files
    }

    /// <summary>
    /// Closes the load game menu and returns to the main menu.
    /// </summary>
    public void CloseLoadGameMenu()
    {
        Debug.Log("Closing Load Game Menu...");
        HidePanel(loadGamePanel);
        ShowPanel(mainMenuPanel);
    }

    /// <summary>
    /// Loads a specific game save slot. Currently a placeholder.
    /// </summary>
    /// <param name="slotNumber">The number of the save slot to load.</param>
    public void LoadGameSlot(int slotNumber)
    {
        Debug.Log($"Loading game from slot {slotNumber} (placeholder)...");
        if (progressionManager != null)
        {
            // In a full implementation, this would involve loading a specific save file
            // and then instructing the progression manager to start the game from that state.
            progressionManager.LoadProgression(); // Load meta-progression
            progressionManager.StartNewRun(); // For now, just start a new run
        }
    }

    /// <summary>
    /// Quits the application. This only works in a built game.
    /// </summary>
    public void QuitGame()
    {
        Debug.Log("Quitting Game...");
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    /// <summary>
    /// Sets the graphics quality level based on slider value.
    /// </summary>
    /// <param name="value">The slider value (typically 0 to QualitySettings.names.Length - 1).</param>
    private void SetGraphicsQuality(float value)
    {
        int qualityLevel = Mathf.RoundToInt(value);
        QualitySettings.SetQualityLevel(qualityLevel, true);
        Debug.Log($"Setting graphics quality to: {QualitySettings.names[qualityLevel]}");
    }

    /// <summary>
    /// Sets the fullscreen mode based on toggle value.
    /// </summary>
    /// <param name="isFullScreen">True for fullscreen, false for windowed.</param>
    private void SetFullScreen(bool isFullScreen)
    {
        Screen.fullScreen = isFullScreen;
        Debug.Log($"Setting fullscreen to: {isFullScreen}");
    }

    /// <summary>
    /// Sets the master volume for audio.
    /// </summary>
    /// <param name="value">The slider value (0 to 1).</param>
    private void SetMasterVolume(float value)
    {
        AudioListener.volume = value;
        Debug.Log($"Setting master volume to: {value}");
    }

    /// <summary>
    /// Placeholder for remapping controls functionality.
    /// </summary>
    private void RebindControls()
    {
        Debug.Log("Rebind Controls functionality (not yet implemented).");
        // This would typically open another sub-panel for input remapping.
        // It would interact with an InputManager if one exists and exposes rebind methods.
    }

    /// <summary>
    /// Saves current settings to PlayerPrefs.
    /// </summary>
    private void SaveSettings()
    {
        if (graphicsQualitySlider != null) PlayerPrefs.SetInt(GraphicsQualityPrefKey, QualitySettings.GetQualityLevel());
        if (fullScreenToggle != null) PlayerPrefs.SetInt(FullScreenPrefKey, Screen.fullScreen ? 1 : 0);
        if (masterVolumeSlider != null) PlayerPrefs.SetFloat(MasterVolumePrefKey, AudioListener.volume);
        PlayerPrefs.Save();
        Debug.Log("Settings saved.");
    }

    /// <summary>
    /// Loads settings from PlayerPrefs and applies them to UI elements.
    /// </summary>
    private void LoadSettings()
    {
        if (graphicsQualitySlider != null)
        {
            int savedQuality = PlayerPrefs.GetInt(GraphicsQualityPrefKey, QualitySettings.GetQualityLevel());
            graphicsQualitySlider.value = savedQuality;
            QualitySettings.SetQualityLevel(savedQuality, true);
        }

        if (fullScreenToggle != null)
        {
            bool savedFullScreen = PlayerPrefs.GetInt(FullScreenPrefKey, Screen.fullScreen ? 1 : 0) == 1;
            fullScreenToggle.isOn = savedFullScreen;
            Screen.fullScreen = savedFullScreen;
        }

        if (masterVolumeSlider != null)
        {
            float savedVolume = PlayerPrefs.GetFloat(MasterVolumePrefKey, AudioListener.volume);
            masterVolumeSlider.value = savedVolume;
            AudioListener.volume = savedVolume;
        }
        Debug.Log("Settings loaded.");
    }

    /// <summary>
    /// Helper method to display a UI panel.
    /// </summary>
    /// <param name="panel">The GameObject panel to show.</param>
    private void ShowPanel(GameObject panel)
    {
        if (panel != null)
        {
            panel.SetActive(true);
        }
        else
        {
            Debug.LogError("Attempted to show a null UI panel.", this);
        }
    }

    /// <summary>
    /// Helper method to hide a UI panel.
    /// </summary>
    /// <param name="panel">The GameObject panel to hide.</param>
    private void HidePanel(GameObject panel)
    {
        if (panel != null)
        {
            panel.SetActive(false);
        }
        else
        {
            Debug.LogError("Attempted to hide a null UI panel.", this);
        }
    }
}