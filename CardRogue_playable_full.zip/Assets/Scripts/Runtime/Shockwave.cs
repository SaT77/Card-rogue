using UnityEngine;
public class Shockwave : MonoBehaviour
{
    float radius = 3f;
    int damage = 10;
    float duration = 0.3f;
    public void Initialize(float r, int d)
    {
        radius = r; damage = d;
        // apply damage immediately and destroy shortly
        var enemies = Object.FindObjectsOfType<Enemy>();
        foreach(var e in enemies)
        {
            if (Vector3.Distance(e.transform.position, transform.position) <= radius) e.TakeDamage(damage);
        }
        Destroy(gameObject, duration);
    }
}
