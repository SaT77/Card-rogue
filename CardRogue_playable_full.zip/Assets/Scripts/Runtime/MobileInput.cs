using UnityEngine;
using UnityEngine.UI;
public class MobileInput : MonoBehaviour
{
    public RectTransform leftButton, rightButton, jumpButton, attackButton;
    public PlayerController player;
    void Start()
    {
        if (player==null) player = FindObjectOfType<PlayerController>();
    }
    void Update()
    {
        // simple touch support: if leftButton pressed, move left; rightButton pressed, move right
        float move = 0f;
        if (IsPressed(leftButton)) move -= 1f;
        if (IsPressed(rightButton)) move += 1f;
        if (player!=null) player.transform.Translate(new Vector3(move * player.moveSpeed * Time.deltaTime, 0, 0));
    }

    bool IsPressed(RectTransform rt)
    {
        if (rt==null) return false;
        foreach(var t in Input.touches)
        {
            Vector2 pos = t.position;
            Vector2 local;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(rt, pos, null, out local);
            if (rt.rect.Contains(local)) return true;
        }
        return false;
    }
}
