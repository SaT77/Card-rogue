using UnityEngine;
using System.Collections;
using System.Linq;

public class GameBootstrap : MonoBehaviour
{
    void Awake()
    {
        // Ensure initial data exists in Resources - importer will create assets in Editor.
        // At runtime, load weapons and cards from Resources
        var weapons = Resources.LoadAll<WeaponData>("Data/Weapons");
        var cards = Resources.LoadAll<CardData>("Data/Cards");
        Debug.Log("Loaded weapons: " + weapons.Length + " cards: " + cards.Length);

        // Create a simple player
        var playerGO = new GameObject("Player");
        playerGO.AddComponent<PlayerController>();

        // Create UI manager
        var ui = new GameObject("UIManager");
        ui.AddComponent<UIManager>();

        // Create simple enemy spawner
        var spawner = new GameObject("EnemySpawner");
        var sp = spawner.AddComponent<EnemySpawner>();
        sp.SpawnCount = 3;
    }
}
