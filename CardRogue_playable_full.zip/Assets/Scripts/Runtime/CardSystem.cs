using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class CardSystem : MonoBehaviour
{
    public List<CardData> activeHand = new List<CardData>();
    public int maxHand = 4;
    PlayerController player;

    void Start()
    {
        player = FindObjectOfType<PlayerController>();
        var cards = Resources.LoadAll<CardData>("Data/Cards");
        for (int i=0;i<cards.Length && i<maxHand;i++) activeHand.Add(cards[i]);
    }

    public void ActivateCard(int index)
    {
        if (index <0 || index>=activeHand.Count) return;
        var card = activeHand[index];
        Debug.Log("Activating card: " + card.cardName);
        // Map card names to abilities
        string n = card.cardName.ToLower();
        if (n.Contains("blaze")) { ApplyIgnite(); return; }
        if (n.Contains("shadow")) { ApplyShadowDash(); return; }
        if (n.Contains("stone")) { ApplyStoneSkin(); return; }
        if (n.Contains("sharpshot")) { ApplySharpshot(); return; }
        if (n.Contains("shockwave")) { ApplyShockwave(); return; }
        if (n.Contains("rapid")) { ApplyRapidFire(); return; }
        if (n.Contains("toxic")) { ApplyToxicCloud(); return; }
        if (n.Contains("guardian")) { ApplyGuardian(); return; }
    }

    void ApplyIgnite()
    {
        // temporary add a fire damage buff to player for 10s
        if (player==null) return;
        player.StartCoroutine(player.TempDamageModifier(1.5f, 10f));
        Debug.Log("Ignite applied: +50% damage for 10s");
    }

    void ApplyShadowDash()
    {
        if (player==null) return;
        // teleport forward a short distance and damage nearby enemies
        Vector3 dir = Vector3.right * 3f;
        Vector3 targetPos = player.transform.position + dir;
        player.transform.position = targetPos;
        // damage enemies in radius
        var enemies = Object.FindObjectsOfType<Enemy>();
        foreach(var e in enemies)
        {
            if (Vector3.Distance(e.transform.position, player.transform.position) < 2.0f)
                e.TakeDamage(8);
        }
        Debug.Log("Shadow Dash executed");
    }

    void ApplyStoneSkin()
    {
        if (player==null) return;
        player.StartCoroutine(player.TempInvulnerability(3f));
        Debug.Log("Stone Skin: invulnerable for 3s");
    }

    void ApplySharpshot()
    {
        if (player==null) return;
        player.StartCoroutine(player.TempPiercing(8f));
        Debug.Log("Sharpshot: piercing arrows for 8s");
    }

    void ApplyShockwave()
    {
        if (player==null) return;
        // create shockwave object that stuns/damages enemies in front
        var go = new GameObject("Shockwave");
        go.transform.position = player.transform.position + Vector3.right * 1.5f;
        var sw = go.AddComponent<Shockwave>();
        sw.Initialize(3f, 10);
        Debug.Log("Shockwave created");
    }

    void ApplyRapidFire()
    {
        if (player==null) return;
        player.StartCoroutine(player.TempAttackSpeedMultiplier(1.5f, 8f));
        Debug.Log("Rapid Fire: attack speed up for 8s");
    }

    void ApplyToxicCloud()
    {
        if (player==null) return;
        // spawn a toxic cloud that damages enemies over time
        var go = new GameObject("ToxicCloud");
        go.transform.position = player.transform.position + Vector3.right * 1f;
        var tc = go.AddComponent<ToxicCloud>();
        tc.Initialize(5f, 3);
        Debug.Log("Toxic cloud spawned");
    }

    void ApplyGuardian()
    {
        if (player==null) return;
        player.StartCoroutine(player.TempShield(5f));
        Debug.Log("Guardian spirit: shield for 5s");
    }
}
