using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 4f;
    public int maxHealth = 100;
    public int currentHealth;
    public WeaponData equippedWeapon;

    void Start()
    {
        currentHealth = maxHealth;
        // default weapon load (first in Resources)
        var w = Resources.LoadAll<WeaponData>("Data/Weapons");
        if (w != null && w.Length>0) equippedWeapon = w[0];
    }

    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        transform.Translate(new Vector3(h * moveSpeed * Time.deltaTime, 0, 0));

        if (Input.GetButtonDown("Fire1"))
        {
            Attack();
        }
    }

    void Attack()
    {
        Debug.Log("Player attacking with " + (equippedWeapon!=null ? equippedWeapon.weaponName : "none"));
        // spawn a simple hit check: damage nearest enemy in front
        var enemies = FindObjectsOfType<Enemy>();
        if (enemies.Length==0) return;
        var target = enemies[0];
        int baseDmg = equippedWeapon != null ? equippedWeapon.baseDamage : 5;
        int finalDmg = Mathf.RoundToInt(baseDmg * attackMultiplier);
        if (hasPiercing)
        {
            // damage all enemies in a line
            foreach(var e in enemies) e.TakeDamage(finalDmg);
        }
        else
        {
            target.TakeDamage(finalDmg);
        }
    }
}


    // Temporary effect coroutines used by CardSystem
    public System.Collections.IEnumerator TempDamageModifier(float multiplier, float duration)
    {
        float original = 1f;
        if (equippedWeapon != null)
        {
            original = 1f; // not stored; for demo assume base multiplier
            // apply by storing a multiplier field
        }
        attackMultiplier = multiplier;
        yield return new WaitForSeconds(duration);
        attackMultiplier = 1f;
    }

    public System.Collections.IEnumerator TempInvulnerability(float duration)
    {
        invulnerable = true;
        yield return new WaitForSeconds(duration);
        invulnerable = false;
    }

    public System.Collections.IEnumerator TempPiercing(float duration)
    {
        hasPiercing = true;
        yield return new WaitForSeconds(duration);
        hasPiercing = false;
    }

    public System.Collections.IEnumerator TempAttackSpeedMultiplier(float mult, float duration)
    {
        attackSpeedMultiplier *= mult;
        yield return new WaitForSeconds(duration);
        attackSpeedMultiplier /= mult;
    }

    public System.Collections.IEnumerator TempShield(float duration)
    {
        shielded = true;
        yield return new WaitForSeconds(duration);
        shielded = false;
    }

    // fields for effects
    public bool invulnerable = false;
    public bool hasPiercing = false;
    public bool shielded = false;
    public float attackMultiplier = 1f;
    public float attackSpeedMultiplier = 1f;
