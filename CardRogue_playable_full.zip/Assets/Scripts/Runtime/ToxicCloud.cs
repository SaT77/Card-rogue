using UnityEngine;
using System.Collections;
public class ToxicCloud : MonoBehaviour
{
    float duration = 5f;
    int damagePerTick = 2;
    public void Initialize(float dur, int dpt)
    {
        duration = dur; damagePerTick = dpt;
        StartCoroutine(Run());
    }
    System.Collections.IEnumerator Run()
    {
        float t=0;
        while(t<duration)
        {
            var enemies = Object.FindObjectsOfType<Enemy>();
            foreach(var e in enemies)
            {
                if (Vector3.Distance(e.transform.position, transform.position) <= 2.5f) e.TakeDamage(damagePerTick);
            }
            t += 1f;
            yield return new WaitForSeconds(1f);
        }
        Destroy(gameObject);
    }
}
