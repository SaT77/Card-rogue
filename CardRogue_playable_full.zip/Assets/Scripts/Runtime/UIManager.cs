using UnityEngine;
using UnityEngine.UI;
using System.Linq;

public class UIManager : MonoBehaviour
{
    Canvas canvas;
        void Start()
    {
        var go = new GameObject("Canvas");
        canvas = go.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        go.AddComponent<CanvasScaler>();
        go.AddComponent<GraphicRaycaster>();
        DontDestroyOnLoad(go);

        // Show weapons list at left
        var weapons = Resources.LoadAll<WeaponData>("Data/Weapons");
        for (int i=0;i<weapons.Length;i++)
        {
            var t = CreateText(weapons[i].weaponName, new Vector2(10, -20 - i*20));
        }

        // Show cards at right with buttons
        var cards = Resources.LoadAll<CardData>("Data/Cards");
        var cardSys = gameObject.AddComponent<CardSystem>();
        for (int i=0;i<cards.Length;i++)
        {
            var t = CreateText(cards[i].cardName, new Vector2(200, -20 - i*20));
            // create button to activate card
            var b = CreateButton("Use_"+i.ToString(), new Vector2(360, -20 - i*30), "Use");
            int idx = i;
            b.onClick.AddListener(()=>{ cardSys.ActivateCard(idx); });
        }

        // Mobile controls: left/right/attack buttons
        var left = CreateButton("LeftBtn", new Vector2(40, -220), "<");
        var right = CreateButton("RightBtn", new Vector2(120, -220), ">");
        var attack = CreateButton("AttackBtn", new Vector2(300, -220), "A");
        // attach MobileInput
        var mi = gameObject.AddComponent<MobileInput>();
        // create invisible rects for left/right
        var leftRT = left.GetComponent<RectTransform>();
        var rightRT = right.GetComponent<RectTransform>();
        mi.leftButton = leftRT; mi.rightButton = rightRT;
    }

        var go = new GameObject("Canvas");
        canvas = go.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        go.AddComponent<CanvasScaler>();
        go.AddComponent<GraphicRaycaster>();

        // Show weapons list
        var weapons = Resources.LoadAll<WeaponData>("Data/Weapons");
        for (int i=0;i<weapons.Length;i++)
        {
            var t = CreateText(weapons[i].weaponName, new Vector2(10, -20 - i*20));
        }

        // Show cards
        var cards = Resources.LoadAll<CardData>("Data/Cards");
        for (int i=0;i<cards.Length;i++)
        {
            var t = CreateText(cards[i].cardName, new Vector2(200, -20 - i*20));
        }
    }

    Text CreateText(string txt, Vector2 anchoredPos)
    {
        var go = new GameObject("Text_"+txt);
        go.transform.SetParent(canvas.transform);
        var t = go.AddComponent<Text>();
        t.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        t.text = txt;
        t.fontSize = 14;
        var rt = go.GetComponent<RectTransform>();
        rt.anchorMin = new Vector2(0,1);
        rt.anchorMax = new Vector2(0,1);
        rt.pivot = new Vector2(0,1);
        rt.anchoredPosition = anchoredPos;
        rt.sizeDelta = new Vector2(180, 20);
        return t;
    }
}
