using UnityEngine;

public class Enemy : MonoBehaviour
{
    public int maxHealth = 30;
    public int currentHealth;
    public float moveSpeed = 1f;

    void Start()
    {
        currentHealth = maxHealth;
    }

    void Update()
    {
        // simple idle movement
    }

    public void TakeDamage(int dmg)
    {
        currentHealth -= dmg;
        Debug.Log(gameObject.name + " took " + dmg + " damage. HP=" + currentHealth);
        if (currentHealth <= 0) Die();
    }

    void Die()
    {
        Destroy(gameObject);
    }
}
