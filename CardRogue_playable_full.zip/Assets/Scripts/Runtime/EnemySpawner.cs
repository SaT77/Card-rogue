using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public int SpawnCount = 3;
    public float Spread = 5f;

    void Start()
    {
        for (int i=0;i<SpawnCount;i++)
        {
            var go = new GameObject("Enemy_"+i);
            go.transform.position = new Vector3(i * Spread, 0, 0);
            var e = go.AddComponent<Enemy>();
        }
    }
}
