# Card Rogue - Prepared Unity Project (with asset downloader)

This project contains your scripts plus helpers to fetch free assets (Kenney, OpenGameArt, Mixkit) and a GitHub Actions workflow to build an APK.

Run `ci_assets/download_assets.sh` in CI to download and unpack recommended assets into `Assets/ImportedAssets/` before the Unity build runs.
