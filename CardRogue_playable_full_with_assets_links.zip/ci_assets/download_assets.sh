#!/usr/bin/env bash
set -e
mkdir -p ci_assets/downloads
cd ci_assets/downloads || exit 1

echo "Attempting to download Kenney UI Pack (may require manual click)"
# Kenney direct download example (may expire/change). If this fails, download manually and place zip here.
KENNEY_UI_URL="https://kenney.nl/media/pages/assets/ui-pack/4f6e3f3/ui-pack.zip"
curl -L -o kenney_ui.zip "$KENNEY_UI_URL" || echo "Kenney UI download failed; please download from https://kenney.nl/assets/ui-pack and upload to ci_assets/downloads/"

echo "Attempting to download Kenney Game Icons (example)"
KENNEY_ICONS_URL="https://kenney.nl/media/pages/assets/game-icons/6d9f2ef/game-icons.zip"
curl -L -o kenney_icons.zip "$KENNEY_ICONS_URL" || echo "Kenney icons download failed; please download from https://kenney.nl/assets/game-icons and upload to ci_assets/downloads/"

echo "Attempting to download OpenGameArt minimal UI pack (may require manual download)"
OGA_UI_URL="https://opengameart.org/sites/default/files/ui_minimal_pack.zip"
curl -L -o oga_ui.zip "$OGA_UI_URL" || echo "OpenGameArt download failed; please download from https://opengameart.org and upload to ci_assets/downloads/"

echo "Note: Mixkit music & SFX require selecting individual tracks; please manually download preferred tracks from Mixkit pages and place them into ci_assets/downloads/ if automatic download isn't possible."
echo "Mixkit music page: https://mixkit.co/free-stock-music/tag/video-game/"
echo "Mixkit sfx page: https://mixkit.co/free-sound-effects/game/"

# Unpack any downloaded zips into Assets/ImportedAssets/
mkdir -p ../../../Assets/ImportedAssets/Downloaded
for f in *.zip; do
  if [ -f "$f" ]; then
    echo "Unpacking $f into Assets/ImportedAssets/Downloaded/"
    unzip -o "$f" -d ../../../Assets/ImportedAssets/Downloaded/ || echo "Failed to unzip $f"
  fi
done

echo "Download script finished. Inspect ci_assets/downloads/ for files to be included in the project."
