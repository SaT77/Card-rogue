# ASSET SOURCES & LICENSES (selected minimalistic assets)

I selected permissive/minimalist assets to populate the project. The CI script will try to download these packs into `ci_assets/downloads/` and unpack them into `Assets/ImportedAssets/`.

Primary sources chosen (direct links attempted in `ci_assets/download_assets.sh`):
- **Kenney — UI Pack / Game Icons** — permissive (CC0-like). Source pages: Kenney UI Pack and Game Icons. citeturn0search1turn0search0
  - example page: https://kenney.nl/assets/ui-pack
- **OpenGameArt — Minimalist UI / CC0 UI packs** — CC0 collections useful for minimal UI. citeturn0search3turn0search11
  - example page: https://opengameart.org/content/assets-ui-minimalism-scifi
- **Mixkit — Free music & SFX** — royalty free for commercial use under Mixkit License. Suggested pages for music and SFX. citeturn0search6turn0search10
  - music page: https://mixkit.co/free-stock-music/tag/video-game/
  - sfx page: https://mixkit.co/free-sound-effects/game/
- **OpenGameArt — RPG / Icons pack** — good set of ability/item icons (CC0). citeturn0search15

Notes:
- Some providers (Kenney, Mixkit) show asset pages that require clicking a "download" button — CI will attempt direct download URLs but may need manual upload into `ci_assets/downloads/` if direct links fail.
- I will include placeholder minimalist icons directly in `Assets/ImportedAssets/Icons/` so the project is usable even if CI download fails.
