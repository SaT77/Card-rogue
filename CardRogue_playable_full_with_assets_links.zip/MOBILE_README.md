Mobile instructions:
1. Create a GitHub repo and upload this project (upload folder contents or zip).
2. In Actions, run 'Unity Android Build' workflow or push to main.
3. If download step fails, manually place downloaded asset zips into ci_assets/downloads/ (on phone) and re-run workflow.
4. After build, download CardRogue-APK artifact to your phone.
