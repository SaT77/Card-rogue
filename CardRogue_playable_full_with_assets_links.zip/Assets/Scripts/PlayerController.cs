using UnityEngine;
public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 4f;
    public int maxHealth = 100;
    public int currentHealth;
    public WeaponData equippedWeapon;

    void Start()
    {
        currentHealth = maxHealth;
        var ws = Resources.LoadAll<WeaponData>("Data/Weapons"); if(ws.Length>0) equippedWeapon = ws[0];
    }

    void Update()
    {
        float h = Input.GetAxis("Horizontal"); transform.Translate(new Vector3(h*moveSpeed*Time.deltaTime,0,0));
        if(Input.GetButtonDown("Fire1")) Attack();
    }

    public void Attack(){ var enemies = FindObjectsOfType<Enemy>(); if(enemies.Length==0) return; enemies[0].TakeDamage(equippedWeapon!=null?equippedWeapon.baseDamage:5); }
}
