using UnityEngine; using System.Collections.Generic;
public class CardSystem : MonoBehaviour
{
    public List<CardData> activeHand = new List<CardData>(); public int maxHand = 4; PlayerController player;
    void Start(){ player = FindObjectOfType<PlayerController>(); var cards = Resources.LoadAll<CardData>("Data/Cards"); for(int i=0;i<cards.Length && i<maxHand;i++) activeHand.Add(cards[i]); }
    public void ActivateCard(int idx){ if(idx<0||idx>=activeHand.Count) return; var c = activeHand[idx]; Debug.Log("Activate: "+c.cardName); if(c.cardName.ToLower().Contains("blaze")){ player.StartCoroutine(player.TempInvulnerability(0.5f)); } if(c.cardName.ToLower().Contains("shadow")){ player.transform.position += Vector3.right*3f; } }
}
