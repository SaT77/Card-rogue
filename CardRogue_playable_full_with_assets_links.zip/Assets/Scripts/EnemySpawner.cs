using UnityEngine;
public class Enemy : MonoBehaviour{ public int maxHealth=20; int currentHealth; void Start(){ currentHealth=maxHealth; } public void TakeDamage(int d){ currentHealth-=d; if(currentHealth<=0) Destroy(gameObject);} }
public class EnemySpawner : MonoBehaviour { public int SpawnCount=1; void Start(){ for(int i=0;i<SpawnCount;i++){ var go=new GameObject("Enemy_"+i); go.transform.position=new Vector3(i*2+2,0,0); go.AddComponent<Enemy>(); } } }
