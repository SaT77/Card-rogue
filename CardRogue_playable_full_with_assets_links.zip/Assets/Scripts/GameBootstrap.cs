using UnityEngine;
public class GameBootstrap : MonoBehaviour
{
    void Awake()
    {
        var p = new GameObject("Player"); p.AddComponent<PlayerController>();
        var ui = new GameObject("UI"); ui.AddComponent<UIManager>();
        var cs = new GameObject("CardSystem"); cs.AddComponent<CardSystem>();
        var sp = new GameObject("Spawner"); sp.AddComponent<EnemySpawner>().SpawnCount = 3;
    }
}
