using UnityEngine; using UnityEngine.UI;
public class UIManager : MonoBehaviour
{
    Canvas canvas;
    void Start()
    {
        var go = new GameObject("Canvas"); canvas = go.AddComponent<Canvas>(); canvas.renderMode = RenderMode.ScreenSpaceOverlay; go.AddComponent<CanvasScaler>(); go.AddComponent<GraphicRaycaster>();
        var t = CreateText("CardRogue - Demo", new Vector2(10,-10));
    }
    Text CreateText(string s, Vector2 pos){ var go = new GameObject("Text"); go.transform.SetParent(canvas.transform); var t = go.AddComponent<Text>(); t.font = Resources.GetBuiltinResource<Font>("Arial.ttf"); t.text = s; t.fontSize=18; var rt = go.GetComponent<RectTransform>(); rt.anchorMin=new Vector2(0,1); rt.anchorMax=new Vector2(0,1); rt.pivot=new Vector2(0,1); rt.anchoredPosition=pos; rt.sizeDelta=new Vector2(300,30); return t; }
}
