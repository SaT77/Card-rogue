#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEditor.SceneManagement;
using System.IO;

public class AutoBuilder
{
    const string SCENE_PATH = "Assets/Scenes/GeneratedScene.unity";
    const string OUTPUT_APK = "Builds/CardRogue.apk";

    [MenuItem("Tools/AutoBuild/Generate Scene And Data")]
    public static void GenerateSceneAndData()
    {
        if (!Directory.Exists("Assets/Scenes")) Directory.CreateDirectory("Assets/Scenes");
        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        var go = new GameObject("GameBootstrap"); go.AddComponent<GameBootstrap>();
        EditorSceneManager.SaveScene(scene, SCENE_PATH);
        InitialDataImporter.ImportJsonData();
        AssetDatabase.SaveAssets(); AssetDatabase.Refresh();
        Debug.Log("Scene and data generated.");
    }

    [MenuItem("Tools/AutoBuild/Build APK")]
    public static void BuildAndroidAPK()
    {
        GenerateSceneAndData();
        EditorUserBuildSettings.buildAppBundle = false;
        string[] scenes = { SCENE_PATH };
        var opts = new BuildPlayerOptions { scenes = scenes, locationPathName = OUTPUT_APK, target = BuildTarget.Android };
        var report = BuildPipeline.BuildPlayer(opts);
        Debug.Log("Build finished.");
    }
}
#endif
