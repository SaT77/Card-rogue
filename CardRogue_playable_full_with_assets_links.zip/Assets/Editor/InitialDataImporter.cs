#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using System.IO;

public class InitialDataImporter
{
    [MenuItem("Tools/InitialData/Import JSON Data")]
    public static void ImportJsonData()
    {
        string path = "Assets/Resources/Data/InitialGameData.json";
        if (!File.Exists(path))
        {
            Debug.LogError("InitialGameData.json not found at Assets/Resources/Data/");
            return;
        }
        var txt = File.ReadAllText(path);
        var root = JsonUtility.FromJson<Wrapper>(txt);

        string weaponsPath = "Assets/Resources/Data/Weapons";
        string cardsPath = "Assets/Resources/Data/Cards";
        string affixPath = "Assets/Resources/Data/Affixes";
        if (!AssetDatabase.IsValidFolder(weaponsPath)) AssetDatabase.CreateFolder("Assets/Resources/Data","Weapons");
        if (!AssetDatabase.IsValidFolder(cardsPath)) AssetDatabase.CreateFolder("Assets/Resources/Data","Cards");
        if (!AssetDatabase.IsValidFolder(affixPath)) AssetDatabase.CreateFolder("Assets/Resources/Data","Affixes");

        foreach(var a in root.affixes)
        {
            var inst = ScriptableObject.CreateInstance<AffixData>();
            inst.affixName = a.affixName;
            inst.effectDescription = a.effectDescription;
            inst.value = a.value;
            AssetDatabase.CreateAsset(inst, affixPath + "/" + a.id + ".asset");
        }

        foreach(var w in root.weapons)
        {
            var inst = ScriptableObject.CreateInstance<WeaponData>();
            inst.weaponName = w.weaponName;
            inst.baseDamage = w.baseDamage;
            inst.attackSpeed = w.attackSpeed;
            string icon = FindIcon(w.icon_keyword);
            if (!string.IsNullOrEmpty(icon)) inst.icon = AssetDatabase.LoadAssetAtPath<Sprite>(icon);
            AssetDatabase.CreateAsset(inst, weaponsPath + "/" + w.id + ".asset");
        }

        foreach(var c in root.cards)
        {
            var inst = ScriptableObject.CreateInstance<CardData>();
            inst.cardName = c.cardName;
            inst.description = c.description;
            inst.rarity = c.rarity;
            string icon = FindIcon(c.icon_keyword);
            if (!string.IsNullOrEmpty(icon)) inst.icon = AssetDatabase.LoadAssetAtPath<Sprite>(icon);
            AssetDatabase.CreateAsset(inst, cardsPath + "/" + c.id + ".asset");
        }

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("Imported initial game data.");
    }

    static string FindIcon(string keyword)
    {
        if (string.IsNullOrEmpty(keyword)) return null;
        var guids = AssetDatabase.FindAssets(keyword + " t:Texture", new[] {"Assets/ImportedAssets/Icons","Assets/ImportedAssets/Downloaded"});
        if (guids != null && guids.Length>0) return AssetDatabase.GUIDToAssetPath(guids[0]);
        return null;
    }

    [System.Serializable] class Wrapper { public WeaponJson[] weapons; public CardJson[] cards; public AffixJson[] affixes; }
    [System.Serializable] class WeaponJson { public string id; public string weaponName; public int baseDamage; public float attackSpeed; public string icon_keyword; }
    [System.Serializable] class CardJson { public string id; public string cardName; public string description; public int rarity; public string icon_keyword; public string instantAbility; }
    [System.Serializable] class AffixJson { public string id; public string affixName; public string effectDescription; public int value; }
}
#endif
